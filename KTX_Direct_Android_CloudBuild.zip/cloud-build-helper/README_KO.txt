휴대폰만으로 APK 빌드하기 (GitHub Actions)

준비물: GitHub 계정, 이 안내 파일, KTX_Direct_Android.zip
주의: 이 방식은 GitHub 클라우드에서 APK를 빌드합니다. ChatGPT가 직접 APK를 생성한 것은 아닙니다.

1) 휴대폰 브라우저에서 https://github.com/new 을 열고 새 저장소를 만듭니다. 예: ktx-android-build
   가능하면 Private(비공개)로 설정합니다.
2) 저장소 화면에서 Add file > Upload files를 눌러 원본 KTX_Direct_Android.zip 파일을 업로드하고 Commit changes를 누릅니다.
3) 저장소에서 Add file > Create new file을 누릅니다.
4) 파일 이름 칸에 .github/workflows/android-apk.yml 을 입력합니다.
5) 이 패키지의 android-apk.yml 파일 내용을 전부 복사해 붙여 넣고 Commit changes를 누릅니다.
6) 저장소의 Actions 탭을 엽니다. Build Android APK 워크플로를 선택하고 Run workflow를 누릅니다.
7) 작업이 초록색 체크로 완료되면 실행 기록을 열고 아래 Artifacts에서 Jaribom-Android-APK를 다운로드합니다.
8) 다운로드한 ZIP을 휴대폰에서 압축 해제하면 APK 파일이 있습니다. Android가 설치를 차단하면 해당 파일 관리자에 '알 수 없는 앱 설치 허용'을 켜야 할 수 있습니다.

중요:
- 빌드에는 GitHub 클라우드가 사용됩니다. 실패하면 Actions 로그의 오류를 확인해야 합니다.
- 임시 서명 키를 사용하므로 이 APK는 기존 설치 앱의 업데이트용이 아닙니다. 기존 앱을 삭제해야 설치될 수 있으며, 앱 데이터도 사라질 수 있습니다.
- 서명 키는 빌드 중 임시 생성되며 보관되지 않습니다. 이 APK를 계속 업데이트하려면 별도 고정 서명 키 관리가 필요합니다.
- 앱 기능, 서버 연동, 경진대회 규정 및 서비스 이용 약관 적합성은 별도 검증이 필요합니다.
