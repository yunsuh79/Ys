#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
: "${ANDROID_SDK_ROOT:?Set ANDROID_SDK_ROOT to your Android SDK directory}"
BT="$ANDROID_SDK_ROOT/build-tools/35.0.0"
ANDROID_JAR="$ANDROID_SDK_ROOT/platforms/android-35/android.jar"
rm -rf build/gen build/classes build/dex
mkdir -p build/gen build/classes build/dex build/private signing
chmod 700 build/private
R8_JAR="${JARIBOM_R8_JAR:-$ANDROID_SDK_ROOT/cmdline-tools/latest/lib/r8.jar}"
[[ -f "$R8_JAR" ]] || { echo "R8 jar missing; refusing an unobfuscated release" >&2; exit 1; }
# Android Gradle Plugin uses namespace; standalone aapt2 needs a manifest package.
python3 - <<'PY'
from pathlib import Path
s=Path('app/src/main/AndroidManifest.xml').read_text()
s=s.replace('<manifest ', '<manifest package="kr.personal.ktxmate" ',1)
Path('build/AndroidManifest.xml').write_text(s)
PY
"$BT/aapt2" compile --dir app/src/main/res -o build/res.zip
"$BT/aapt2" link -o build/unsigned.apk --manifest build/AndroidManifest.xml -I "$ANDROID_JAR" --java build/gen --min-sdk-version 26 --target-sdk-version 35 --version-code 53 --version-name 1.3.10 build/res.zip
java com.sun.tools.javac.Main --release 8 -encoding UTF-8 -classpath "$ANDROID_JAR" -d build/classes build/gen/kr/personal/ktxmate/R.java app/src/main/java/kr/personal/ktxmate/*.java
python3 - <<'PY2'
from pathlib import Path
import zipfile
root=Path('build/classes')
with zipfile.ZipFile('build/program.jar','w',zipfile.ZIP_DEFLATED) as z:
 for f in root.rglob('*.class'):z.write(f,f.relative_to(root))
PY2
java -cp "$R8_JAR" com.android.tools.r8.R8 --release --lib "$ANDROID_JAR" --min-api 26 --pg-conf app/proguard-rules.pro --pg-map-output build/private/mapping.txt --output build/dex build/program.jar
chmod 600 build/private/mapping.txt
python3 tests/check_release_dex.py build/dex/classes.dex build/private/mapping.txt
python3 - <<'PY'
import zipfile
with zipfile.ZipFile('build/unsigned.apk','a',zipfile.ZIP_DEFLATED) as z:z.write('build/dex/classes.dex','classes.dex')
PY
"$BT/zipalign" -f -p 4 build/unsigned.apk build/aligned.apk
if [[ ! -f signing/jaribom-release.p12 ]]; then
 echo 'Missing private signing key. Restore the existing update signer; do not generate a replacement.' >&2
 exit 1
fi
: "${JARIBOM_STORE_PASS:?Set the existing signing keystore password privately}"
export JARIBOM_STORE_PASS
export JARIBOM_KEY_PASS="${JARIBOM_KEY_PASS:-$JARIBOM_STORE_PASS}"
"$BT/apksigner" sign --ks signing/jaribom-release.p12 --ks-key-alias jaribomrelease --ks-pass env:JARIBOM_STORE_PASS --key-pass env:JARIBOM_KEY_PASS --out Jaribom_Android_v1.3.10.apk build/aligned.apk
"$BT/apksigner" verify --verbose Jaribom_Android_v1.3.10.apk
