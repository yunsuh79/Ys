# First hardened release: shrink and rename, defer aggressive rewrites until device QA.
-dontoptimize
-repackageclasses 'j'
-renamesourcefileattribute Source
-keepattributes SourceFile,LineNumberTable,Exceptions,InnerClasses,EnclosingMethod,Signature

# Android framework loads manifest components by their stable names.
-keep class kr.personal.ktxmate.MainActivity { public <init>(); }
-keep class kr.personal.ktxmate.LicenseActivity { public <init>(); }
-keep class kr.personal.ktxmate.MonitorService { public <init>(); }
# Framework-overridden methods are recognized using android.jar; no blanket package keep.
# No reflection/JNI/JS bridge or class names in XML in the current app.
