package kr.personal.ktxmate;
import android.graphics.*;
import android.graphics.drawable.Drawable;
import android.os.SystemClock;
/** A moving color ring; drawing does not trigger controller or network work. */
final class WatchBorder extends Drawable {
 final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);final float width,radius;final Runnable frame=()->invalidateSelf();
 WatchBorder(float density){width=5*density;radius=14*density;paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(width);}
 @Override public void draw(Canvas canvas){Rect b=getBounds();float inset=width/2;SweepGradient shader=new SweepGradient(b.exactCenterX(),b.exactCenterY(),new int[]{0xfff3b444,0xffed795e,0xff91ca4d,0xfff8dc69,0xff46b37e,0xfff3b444},null);Matrix matrix=new Matrix();matrix.setRotate((SystemClock.uptimeMillis()%4000)*360f/4000,b.exactCenterX(),b.exactCenterY());shader.setLocalMatrix(matrix);paint.setShader(shader);canvas.drawRoundRect(new RectF(b.left+inset,b.top+inset,b.right-inset,b.bottom-inset),radius,radius,paint);if(isVisible())scheduleSelf(frame,SystemClock.uptimeMillis()+50);}
 @Override public boolean setVisible(boolean visible,boolean restart){if(!visible)unscheduleSelf(frame);return super.setVisible(visible,restart);}
 @Override public void setAlpha(int alpha){paint.setAlpha(alpha);invalidateSelf();}
 @Override public void setColorFilter(ColorFilter filter){paint.setColorFilter(filter);invalidateSelf();}
 @Override public int getOpacity(){return PixelFormat.TRANSLUCENT;}
}
