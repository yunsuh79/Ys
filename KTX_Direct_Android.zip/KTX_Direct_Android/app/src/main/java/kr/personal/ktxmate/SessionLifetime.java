package kr.personal.ktxmate;
/** Monotonic local session policy; persisted credentials are separate from session cookies. */
final class SessionLifetime {
 static final long MAX_AGE=24L*60*60*1000,IDLE_BACKGROUND=30L*60*1000;
 private long issued,background;private boolean valid,away;
 static long now(){return System.nanoTime()/1000000;}
 synchronized void authenticated(long now){issued=now;valid=true;away=false;}
 synchronized boolean expired(long now){return valid&&now-issued>=MAX_AGE;}
 synchronized void background(long now){if(!away){background=now;away=true;}}
 synchronized boolean foreground(long now,boolean active){boolean expire=expired(now)||(!active&&valid&&away&&now-background>=IDLE_BACKGROUND);away=false;return expire;}
 synchronized void clear(){issued=background=0;valid=away=false;}
}
