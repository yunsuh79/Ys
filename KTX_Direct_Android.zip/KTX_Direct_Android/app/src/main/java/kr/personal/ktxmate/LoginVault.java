package kr.personal.ktxmate;
import android.content.*;
import android.security.keystore.*;
import java.security.KeyStore;
import javax.crypto.*;
import org.json.JSONObject;
final class LoginVault {
 private static final String ALIAS="jaribom.remember.v1";
 private final SharedPreferences prefs;private final Keys keys;
 interface Keys{SecretKey get(boolean create)throws Exception;void delete()throws Exception;}
 LoginVault(Context c){this(c.getSharedPreferences("remembered_login",0),new Keys(){public SecretKey get(boolean create)throws Exception{return androidKey(create);}public void delete()throws Exception{KeyStore ks=KeyStore.getInstance("AndroidKeyStore");ks.load(null);ks.deleteEntry(ALIAS);}});}
 LoginVault(SharedPreferences prefs,Keys keys){this.prefs=prefs;this.keys=keys;}
 boolean has(){try{return !prefs.getString("blob","").isEmpty();}catch(RuntimeException e){clear();return false;}}
 private static SecretKey androidKey(boolean create)throws Exception{KeyStore ks=KeyStore.getInstance("AndroidKeyStore");ks.load(null);if(ks.containsAlias(ALIAS))return (SecretKey)ks.getKey(ALIAS,null);if(!create)throw new java.io.IOException("자동 로그인 키가 없습니다");KeyGenerator gen=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");gen.init(new KeyGenParameterSpec.Builder(ALIAS,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).setKeySize(256).setRandomizedEncryptionRequired(true).build());return gen.generateKey();}
 void save(String id,String password)throws Exception{if(id==null||password==null||id.isEmpty()||password.isEmpty()||id.length()>256||password.length()>4096)throw new java.io.IOException("로그인 정보 길이를 확인해주세요");String encrypted=SecretBox.seal(keys.get(true),new JSONObject().put("id",id).put("password",password).toString());if(!prefs.edit().putString("blob",encrypted).commit())throw new java.io.IOException("자동 로그인 정보를 저장하지 못했습니다");}
 String[] read()throws Exception{try{JSONObject r=new JSONObject(SecretBox.open(keys.get(false),prefs.getString("blob","")));String id=r.getString("id"),pw=r.getString("password");if(id.isEmpty()||pw.isEmpty())throw new java.io.IOException("자동 로그인 정보가 비어 있습니다");return new String[]{id,pw};}catch(Exception e){clear();throw new java.io.IOException("저장한 로그인 정보를 확인하지 못했습니다. 직접 다시 로그인해주세요.");}}
 void clear(){prefs.edit().remove("blob").commit();try{keys.delete();}catch(Exception ignored){}}
}
