package kr.personal.ktxmate;
import android.content.Context;
import java.security.KeyStore;
/** Local-only removal of the discontinued token integration. Never reads or transmits secrets. */
final class RetiredIntegration {
 interface KeyEraser {void erase()throws Exception;}
 static boolean clear(Context c){return clear(c,()->{KeyStore ks=KeyStore.getInstance("AndroidKeyStore");ks.load(null);if(ks.containsAlias("jaribom.kakao.v1"))ks.deleteEntry("jaribom.kakao.v1");});}
 static boolean clear(Context c,KeyEraser eraser){
  boolean ok=true;for(String file:new String[]{"kakao_secure","kakao_alerts","kakao_delivery"}){try{if(!c.getSharedPreferences(file,0).edit().clear().commit())ok=false;}catch(Exception e){ok=false;}}
  try{eraser.erase();}catch(Exception e){ok=false;}return ok;
 }
}
