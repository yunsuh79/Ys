package kr.personal.ktxmate;

/** Process-wide recovery budget. Only read-only transport failures may retry. */
final class PollingPolicy {
 private int failures;
 synchronized long failedRead(Exception error){
  if(!(error instanceof KorailApi.ResponseFormat||error instanceof org.json.JSONException||error instanceof java.net.SocketTimeoutException||error instanceof java.net.ConnectException||error instanceof java.net.UnknownHostException||error instanceof java.net.SocketException))return -1;
  failures++;
  if(failures>3)return -1;
  return new long[]{0,15000,30000,60000}[failures];
 }
 synchronized void succeeded(){if(failures>0)failures--;}
 synchronized long recoveryFloor(){return failures==0?0:failures==1?5000:15000;}
}
