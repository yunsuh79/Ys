package kr.personal.ktxmate;
import android.content.*;
import android.net.Uri;
import android.os.PowerManager;
import android.provider.Settings;

/** User-controlled settings only. No service relaunch or power-policy bypass. */
final class BackgroundGuide {
 static final String EXTRA="openBackgroundGuide";
 static final String STEPS="1. 앱 배터리 사용 설정에서 [배터리] → [제한 없음] 또는 [백그라운드 사용 허용]을 선택해주세요.\n\n2. 배터리 최적화 목록에서는 [모든 앱] → [자리봄] → [최적화하지 않음]을 확인해주세요.\n\n3. 삼성 기기는 [설정 → 배터리 → 백그라운드 앱 사용 제한]에서 자리봄이 절전·초절전 앱에 포함되어 있는지 확인해주세요. 메뉴 이름과 지원 항목은 기기마다 다릅니다.\n\n알림 권한과 모바일 데이터 연결도 필요합니다. 설정 변경은 선택 사항이며, 감시가 계속 실행되거나 알림이 즉시 전달된다고 보장하지 않습니다. Android 15 이상의 백그라운드 실행 시간 제한은 별도로 적용됩니다. 감시가 중지되면 예약 내역을 확인한 뒤 앱에서 직접 다시 시작해주세요.";
 static String status(Context ctx){try{PowerManager pm=ctx.getSystemService(PowerManager.class);if(pm==null)return "배터리 최적화 상태를 확인할 수 없습니다";return pm.isIgnoringBatteryOptimizations(ctx.getPackageName())?"배터리 최적화 예외 적용됨 · 다른 실행 제한은 별도":"배터리 최적화 적용 중 · 장시간 감시 설정을 확인해주세요";}catch(Exception e){return "배터리 최적화 상태를 확인할 수 없습니다";}}
 static boolean exempt(Context ctx){try{PowerManager pm=ctx.getSystemService(PowerManager.class);return pm!=null&&pm.isIgnoringBatteryOptimizations(ctx.getPackageName());}catch(Exception ignored){return false;}}
 static boolean requestExemption(Context ctx){if(exempt(ctx))return true;try{ctx.startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,Uri.parse("package:"+ctx.getPackageName())));return true;}catch(Exception ignored){return open(ctx,true);}}
 static Intent appSettings(Context ctx){return new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:"+ctx.getPackageName()));}
 static boolean open(Context ctx,boolean optimization){Intent[] options=optimization?new Intent[]{new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS),appSettings(ctx),new Intent(Settings.ACTION_SETTINGS)}:new Intent[]{appSettings(ctx),new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS),new Intent(Settings.ACTION_SETTINGS)};for(Intent intent:options)try{ctx.startActivity(intent);return true;}catch(Exception ignored){}return false;}
 static String startFailure(){return "Android가 감시 서비스 시작을 허용하지 않았거나 실행을 준비하지 못했습니다. 앱을 화면에 연 상태에서 배터리·알림 설정과 감시 상태를 확인한 뒤 직접 다시 시작해주세요. 자동으로 서비스를 재실행하지 않습니다.";}
 static String timeout(){return "Android의 백그라운드 실행 시간 제한으로 감시가 중지되었습니다. 코레일 앱에서 예약 내역을 확인한 뒤 자리봄을 열어 감시 상태를 확인해주세요. 배터리 최적화 예외와 별도로 적용되는 제한이며, 자동으로 다시 시작하지 않습니다.";}
}
