package kr.personal.ktxmate;
import org.json.*;
import java.util.*;
/** One conservative interpretation for both display and booking eligibility. */
final class SeatAvailability {
 enum State { AVAILABLE, SOLD_OUT, WAITING, UNAVAILABLE, UNKNOWN }
 static final long FRESH_FOR_MS=15000;
 static State state(JSONObject row,boolean general){String code=row.optString(general?"h_gen_rsv_cd":"h_spe_rsv_cd").trim();String name=row.optString(general?"h_gen_rsv_nm":"h_spe_rsv_nm").replaceAll("<[^>]*>","").replaceAll("\\s+","");
  if(name.equals("매진")||name.contains("잔여석없음")||name.contains("좌석없음"))return State.SOLD_OUT;
  if(name.contains("특실없음")||name.contains("운행없음")||name.contains("예약불가")||name.contains("예약불가능")||name.contains("발매불가"))return State.UNAVAILABLE;
  if(name.contains("예약대기")||name.contains("대기신청"))return State.WAITING;
  if(name.contains("입석")||name.contains("자유석"))return State.UNAVAILABLE;
  if("13".equals(code))return State.SOLD_OUT;
  // Remaining-count fields are optional metadata, not the cabin sale status.
  if("11".equals(code))return State.AVAILABLE;return State.UNKNOWN;
 }
 static boolean available(JSONObject row,boolean general){return state(row,general)==State.AVAILABLE;}
 static boolean fresh(JSONObject row,long now){long checked=row.optLong("_seatCheckedAt",0);return checked>0&&now>=checked&&now-checked<=FRESH_FOR_MS;}
 static String label(JSONObject row,boolean general,long now){switch(state(row,general)){case AVAILABLE:return "예약 가능";case SOLD_OUT:return "매진";case WAITING:return "예약대기";case UNAVAILABLE:return "좌석 확인 필요";default:return "확인 필요";}}
 static void stamp(JSONArray rows,long now)throws Exception{for(int i=0;i<rows.length();i++)rows.getJSONObject(i).put("_seatCheckedAt",now);}
 private static String identity(JSONObject r){StringBuilder key=new StringBuilder();for(String field:new String[]{"h_trn_no","h_run_dt","h_dpt_dt","h_dpt_tm","h_dpt_rs_stn_cd","h_arv_rs_stn_cd"}){String v=r.optString(field);if(v.isEmpty())return "";key.append(v).append('|');}return key.toString();}
 static JSONArray merge(JSONArray previous,JSONArray latest,long now)throws Exception{Map<String,JSONObject> updates=new HashMap<>();for(int i=0;i<latest.length();i++){JSONObject row=latest.getJSONObject(i);String key=identity(row);if(!key.isEmpty())updates.put(key,row);}JSONArray result=new JSONArray();for(int i=0;i<previous.length();i++){JSONObject old=previous.getJSONObject(i);if(!TimingPolicy.future(old.optString("h_dpt_dt"),old.optString("h_dpt_tm"),now))continue;JSONObject update=updates.get(identity(old));result.put(update==null?old:update);}return result;}
}
