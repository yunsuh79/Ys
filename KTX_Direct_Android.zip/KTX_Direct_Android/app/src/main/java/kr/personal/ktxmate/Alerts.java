package kr.personal.ktxmate;
import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.media.*;
import android.net.Uri;
import android.os.Build;
class Alerts {
    // Notification delivers vibration; CompletionSound separately plays a finite in-app sound.
    static final String COMPLETE="reservation_success_v3",RESULT="reservation_v1",RUNNING="monitor_v1",QUIET="quiet_results_v1";
    static final long[] PATTERN={0,450,180,450,250,700,300,450,180,450,250,900};
    static void setup(Context c){
        NotificationManager nm=c.getSystemService(NotificationManager.class);
        NotificationChannel success=new NotificationChannel(COMPLETE,"예약 완료 · 알림과 진동",NotificationManager.IMPORTANCE_HIGH);
        success.setDescription("예약 완료 및 테스트의 진동 알림. 완료음은 앱 설정에서 별도로 켜고 미디어 음량으로 조절합니다.");success.enableVibration(true);success.setVibrationPattern(PATTERN);
        success.setSound(null,null);success.setLockscreenVisibility(Notification.VISIBILITY_PRIVATE);nm.createNotificationChannel(success);
        NotificationChannel result=new NotificationChannel(RESULT,"예약 결과 및 확인 안내",NotificationManager.IMPORTANCE_HIGH);result.enableVibration(true);result.setVibrationPattern(new long[]{0,350,200,350});result.setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION),new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION).build());nm.createNotificationChannel(result);
        NotificationChannel quiet=new NotificationChannel(QUIET,"무음 시간대 · 소리와 진동 없음",NotificationManager.IMPORTANCE_LOW);quiet.setSound(null,null);quiet.enableVibration(false);quiet.setLockscreenVisibility(Notification.VISIBILITY_PRIVATE);nm.createNotificationChannel(quiet);
        NotificationChannel monitor=new NotificationChannel(RUNNING,"좌석 감시 상태",NotificationManager.IMPORTANCE_LOW);monitor.setSound(null,null);monitor.enableVibration(false);nm.createNotificationChannel(monitor);
    }
    static boolean allowed(Context c){return c.getSystemService(NotificationManager.class).areNotificationsEnabled()&&(Build.VERSION.SDK_INT<33||c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)==PackageManager.PERMISSION_GRANTED);}
    static PendingIntent open(Context c){return PendingIntent.getActivity(c,0,new Intent(c,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP|Intent.FLAG_ACTIVITY_CLEAR_TOP),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);}
    static String send(Context c,boolean test,String msg){setup(c);if(!allowed(c))return "알림 권한이 꺼져 있습니다";boolean success=test||msg.startsWith("예약번호");String title=test?"자리봄 예약 완료 알림 테스트":success?"자리봄 예약 완료 · 결제 필요":"자리봄 확인 필요";boolean quiet=AlertPreferences.quiet(c);Notification n=new Notification.Builder(c,quiet?QUIET:success?COMPLETE:RESULT).setSmallIcon(R.drawable.ic_status).setContentTitle(title).setContentText(msg).setStyle(new Notification.BigTextStyle().bigText(msg)).setContentIntent(open(c)).setCategory(success?Notification.CATEGORY_EVENT:Notification.CATEGORY_STATUS).setAutoCancel(true).setVisibility(Notification.VISIBILITY_PRIVATE).build();c.getSystemService(NotificationManager.class).notify(test?2:1,n);return quiet?"무음 시간대 · 소리·진동 없이 알림 표시":success?CompletionSound.play(c):"확인 알림을 보냈습니다";}
}
