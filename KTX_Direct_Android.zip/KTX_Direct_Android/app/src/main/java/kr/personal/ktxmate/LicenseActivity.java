package kr.personal.ktxmate;
import android.app.Activity;
import android.os.Bundle;
import android.content.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;
/** Local activation; no login credentials, hardware identifiers or network permission request. */
public class LicenseActivity extends Activity {
 final int GREEN=0xff20734f,INK=0xff203128;String registration="";TextView message;
 int dp(int n){return(int)(n*getResources().getDisplayMetrics().density+.5f);}
 TextView text(String s,int size){TextView v=new TextView(this);v.setText(s);v.setTextColor(INK);v.setTextSize(size);v.setPadding(0,dp(10),0,dp(10));return v;}
 Button button(String s,Runnable action){Button b=new Button(this);b.setText(s);b.setTextSize(16);b.setTextColor(Color.WHITE);b.setAllCaps(false);GradientDrawable bg=new GradientDrawable();bg.setColor(GREEN);bg.setCornerRadius(dp(14));b.setBackground(bg);b.setPadding(dp(12),dp(12),dp(12),dp(12));b.setOnClickListener(v->action.run());return b;}
 boolean enter(){try{startActivity(new Intent(this,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));finish();return true;}catch(RuntimeException e){if(message!=null)message.setText("앱 화면을 열지 못했습니다. 앱을 닫고 다시 실행해주세요.");else Toast.makeText(this,"앱을 닫고 다시 실행해주세요.",Toast.LENGTH_LONG).show();return false;}}
 @Override public void onCreate(Bundle state){super.onCreate(state);boolean authorized=DeviceLicense.allowed(this);if(!getIntent().getBooleanExtra("manage",false)&&authorized&&enter())return;
  getWindow().setStatusBarColor(0xfff8faf3);getWindow().setNavigationBarColor(Color.WHITE);getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR|View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
  ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setBackgroundColor(0xfff8faf3);LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(24),dp(32),dp(24),dp(24));scroll.addView(box);setContentView(scroll);scroll.setOnApplyWindowInsetsListener((v,i)->{v.setPadding(i.getSystemWindowInsetLeft(),i.getSystemWindowInsetTop(),i.getSystemWindowInsetRight(),i.getSystemWindowInsetBottom());return i;});scroll.post(()->scroll.requestApplyInsets());
  ImageView logo=new ImageView(this);logo.setImageResource(R.drawable.ic_brand_mark);logo.setColorFilter(GREEN);box.addView(logo,new LinearLayout.LayoutParams(dp(56),dp(56)));
  TextView title=text("자리봄 · 기기 등록",28);title.setTypeface(Typeface.create("sans-serif-medium",0));box.addView(title);
  box.addView(text(authorized?"영구 인증된 기기입니다. 사용기한은 없습니다.":"기기 인증을 확인할 수 없습니다. 인증코드를 입력해주세요. 저장 정보나 기기 키가 변경된 경우에는 발급자에게 새 코드를 요청해주세요.",15));
  box.addView(text("허용된 가족·지인만 이용할 수 있어요.\n등록코드를 발급자에게 전달한 뒤 받은 인증코드를 아래에 붙여넣어주세요.",16));
  box.addView(text("등록코드는 앱의 설치별 공개키를 요약한 값입니다. IMEI·MAC·전화번호를 읽지 않으며, 복사 버튼을 누를 때만 클립보드에 저장합니다. 발급자에게 직접 전달하면 등록 관리에 사용됩니다. 재설치·데이터 삭제·기기 변경 시 새 인증이 필요할 수 있습니다.",13));
  try{registration=DeviceLicense.registration(this);}catch(Exception e){registration="";}
  TextView request=text(registration.isEmpty()?"기기 키 또는 앱 서명을 확인할 수 없습니다. 공식 배포 파일인지 확인해주세요.":registration,14);request.setTextIsSelectable(true);box.addView(request);
  Button copy=button("등록코드 복사",()->{try{ClipboardManager clipboard=(ClipboardManager)getSystemService(CLIPBOARD_SERVICE);if(clipboard==null)throw new IllegalStateException();clipboard.setPrimaryClip(ClipData.newPlainText("자리봄 등록코드",registration));Toast.makeText(this,"등록코드를 복사했습니다",Toast.LENGTH_SHORT).show();}catch(RuntimeException e){if(message!=null)message.setText("복사하지 못했습니다. 위 등록코드를 길게 눌러 선택한 뒤 복사해주세요.");}});copy.setEnabled(!registration.isEmpty());box.addView(copy);
  box.addView(text("발급받은 인증코드",16));EditText input=new EditText(this);input.setHint("인증코드 붙여넣기");input.setTextSize(14);input.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);input.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.LengthFilter(2048)});box.addView(input);
  message=text("",14);message.setTextColor(0xffb5384c);message.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE);box.addView(message);Button activate=button("인증하고 시작하기",()->{try{DeviceLicense.activate(this,input.getText().toString());enter();}catch(Exception e){message.setText("인증에 실패했습니다. 이 기기에서 복사한 등록코드로 발급받은 코드인지 확인해주세요.");}});activate.setEnabled(!registration.isEmpty());box.addView(activate);
  box.addView(text("최초 한 번 인증하면 만료 없이 영구 사용할 수 있습니다. 앱 삭제·데이터 초기화·기기 변경 시에는 새 인증이 필요할 수 있습니다. 오프라인 인증이므로 발급 후 원격 즉시 회수는 지원하지 않습니다. 앱이 자동으로 등록코드를 서버에 전송하지 않습니다.",13));
  box.addView(text("기기 인증 확인 자체에는 인터넷 연결이 필요하지 않습니다. 앱 정책상 홈 화면은 인터넷 연결이 확인된 모바일 데이터(LTE/5G)에서만 이용할 수 있습니다.",13));
  box.addView(button("인증 상태 다시 확인",this::recreate));
  box.addView(button("앱 닫기",this::finishAffinity));
  box.addView(button("개인정보처리방침 보기",()->{TextView doc=text(LegalDocuments.PRIVACY,14);doc.setPadding(dp(20),dp(12),dp(20),dp(12));ScrollView legal=new ScrollView(this);legal.addView(doc);new android.app.AlertDialog.Builder(this).setTitle("개인정보처리방침").setView(legal).setPositiveButton("닫기",null).show();}));
  box.addView(text("자리봄 v1.3.10 · Developed by IU",12));
 }
}
