package kr.personal.ktxmate;
import java.util.*;
import org.json.*;
/** Local station choices and successful manual searches only; monitoring does not affect ranking. */
final class StationUsage {
 private final Map<String,long[]> values=new HashMap<>();
 private long sequence;
 static final String INITIALS="ㄱㄲㄴㄷㄸㄹㅁㅂㅃㅅㅆㅇㅈㅉㅊㅋㅌㅍㅎ";
 StationUsage(String json){try{JSONArray rows=new JSONArray(json);for(int i=0;i<rows.length();i++){JSONObject r=rows.optJSONObject(i);if(r==null)continue;String name=r.optString("name");long uses=r.optLong("uses",0),recent=r.optLong("recent",0);if(known(name)&&uses>0&&uses<=1000000&&recent>=0&&recent<=1000000000L){values.put(name,new long[]{uses,recent});sequence=Math.max(sequence,recent);}}}catch(Exception ignored){}}
 static boolean known(String name){return Arrays.asList(MajorStations.NAMES).contains(name);}
 void record(String name){if(!known(name))return;long[] old=values.get(name);values.put(name,new long[]{Math.min(1000000,old==null?1:old[0]+1),sequence=Math.min(1000000000L,sequence+1)});}
 void route(String from,String to){if(!FavoriteRoutes.valid(from,to))return;record(from);record(to);}
 long count(String name){long[] n=values.get(name);return n==null?0:n[0];}
 List<String> ordered(){ArrayList<String> result=new ArrayList<>(Arrays.asList(MajorStations.NAMES));result.sort((a,b)->{long[] x=values.getOrDefault(a,new long[2]),y=values.getOrDefault(b,new long[2]);int n=Long.compare(y[0],x[0]);return n!=0?n:Long.compare(y[1],x[1]);});return result;}
 List<String> frequent(int max){ArrayList<String> result=new ArrayList<>();for(String name:ordered()){if(count(name)>0&&result.size()<max)result.add(name);}return result;}
 String json(){JSONArray rows=new JSONArray();for(String name:ordered()){long[] value=values.get(name);if(value!=null)try{rows.put(new JSONObject().put("name",name).put("uses",value[0]).put("recent",value[1]));}catch(JSONException impossible){throw new IllegalStateException(impossible);}}return rows.toString();}
 static String normalize(String s){return s==null?"":s.replaceAll("\\s+","").toLowerCase(Locale.ROOT);}
 static String initials(String s){StringBuilder b=new StringBuilder();for(char c:s.toCharArray())b.append(c>=0xAC00&&c<=0xD7A3?INITIALS.charAt((c-0xAC00)/588):c);return b.toString();}
 static boolean matches(String name,String query){String q=normalize(query),n=normalize(name);return n.contains(q)||initials(n).contains(q);}
}
