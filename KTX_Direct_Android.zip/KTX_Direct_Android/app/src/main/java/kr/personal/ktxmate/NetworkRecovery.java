package kr.personal.ktxmate;

/** Tracks observed outages only; reconnect callbacks never perform server work. */
final class NetworkRecovery {
 private boolean disconnected;private long epoch;
 synchronized boolean observe(boolean ready){if(!ready){if(!disconnected)epoch++;disconnected=true;return false;}boolean recovered=disconnected;disconnected=false;return recovered;}
 synchronized long epoch(){return epoch;}
 static long settleMillis(long normalDelay){return Math.max(2000,normalDelay);}
}
