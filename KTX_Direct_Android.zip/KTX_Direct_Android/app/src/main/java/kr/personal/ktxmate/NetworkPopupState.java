package kr.personal.ktxmate;
/** Foreground notice state only. No server requests or monitoring state mutation. */
final class NetworkPopupState {
 static final int MOBILE=0,WIFI=1,UNAVAILABLE=2;
 private int observed=-1,presented=-1;
 void observe(boolean mobile,boolean wifi){int next=mobile?MOBILE:wifi?WIFI:UNAVAILABLE;if(observed<0)presented=next;observed=next;}
 boolean pending(){return observed>=0&&observed!=presented;}
 Notice consume(boolean watching,boolean held){if(!pending())return null;presented=observed;return notice(observed,watching,held);}
 static final class Notice {final int kind;final String title,message;Notice(int k,String t,String m){kind=k;title=t;message=m;}}
 static Notice entryNotice(boolean wifi){return wifi
  ?new Notice(WIFI,"Wi-Fi에서는 사용할 수 없습니다","앱 정책상 Wi-Fi 접속 시에는 자리봄을 사용할 수 없습니다.\n\nWi-Fi를 끄고 모바일 데이터(LTE/5G)로 전환해주세요. 모바일 데이터 연결이 확인되면 홈 화면으로 이동합니다.")
  :new Notice(UNAVAILABLE,"모바일 데이터 연결이 필요합니다","앱 정책상 인터넷 연결이 확인된 모바일 데이터(LTE/5G)에서만 자리봄을 사용할 수 있습니다.\n\n모바일 데이터를 켜고 Wi-Fi·VPN을 꺼주세요. 연결이 확인되면 홈 화면으로 이동합니다.");}
 static Notice notice(int kind,boolean watching,boolean held){
  if(kind==WIFI)return new Notice(kind,"Wi-Fi로 전환되었습니다",held?"Wi-Fi 연결로 조회와 감시를 일시 중지합니다.\n수동 확인이 필요한 작업은 연결 복구만으로 자동으로 재개하지 않습니다.":watching?"Wi-Fi 연결로 감시를 일시 중지합니다.\n모바일 데이터(LTE/5G)로 전환하면 연결을 확인한 뒤 이어집니다.":"Wi-Fi에서는 열차 조회와 감시를 이용할 수 없습니다.\n모바일 데이터(LTE/5G)로 전환해주세요.");
  if(kind==MOBILE)return new Notice(kind,"모바일 데이터 연결 완료",held?"모바일 데이터 연결을 확인했습니다.\n수동 확인이 필요한 작업은 자동으로 재개하지 않습니다. 기존 안내를 확인해주세요.":watching?"모바일 데이터 연결을 확인했습니다.\n네트워크 대기 중인 감시는 기존 대기 시간을 지킨 뒤 이어집니다.":"모바일 데이터 연결을 확인했습니다.\n열차 조회와 감시를 이용할 수 있습니다.");
  return new Notice(kind,"모바일 데이터 연결 대기",watching?"연결을 확인할 수 없어 감시를 일시 중지합니다.\n모바일 데이터(LTE/5G) 연결을 확인해주세요.":"모바일 데이터 연결을 확인할 수 없습니다.\nLTE/5G 연결이 확인되면 열차 조회와 감시를 이용할 수 있습니다.");
 }
}
