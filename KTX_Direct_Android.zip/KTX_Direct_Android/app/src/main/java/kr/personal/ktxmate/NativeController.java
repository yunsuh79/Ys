package kr.personal.ktxmate;
import android.content.*;
import android.os.*;
import org.json.*;
import java.lang.ref.WeakReference;
import java.util.concurrent.*;

class NativeController {
 static NativeController instance;static synchronized NativeController get(Context ctx){if(instance==null)instance=new NativeController(ctx.getApplicationContext());return instance;}
 interface Listener {void update();void alert(String title,String text);default void watchStarted(JSONObject train,String cabin){}}
 final DeviceSecurity.Result deviceSecurity=DeviceSecurity.inspect();boolean securityWarningShown=false;final Context app;final Handler main=new Handler(Looper.getMainLooper());final ScheduledThreadPoolExecutor io=new ScheduledThreadPoolExecutor(1);final KorailApi api;final LoginVault vault;final MobileNetwork network;volatile boolean networkPaused=false;int loginWidth=0,loginHeight=0;boolean autoLoginAttempted=false;String accountKey="";long historyCheckedAt=0;
 WeakReference<Listener> listener=new WeakReference<>(null);MonitorService service;volatile String interruptionNotice="";volatile String manualNotice="";volatile long blockedUntil=0;volatile int generation=0;volatile boolean busy=false,searching=false;String phase="idle",lastStatus="로그인 전 · 로그인 없이 조회 가능",from="서울",to="부산",date="",time=TimingPolicy.nowTime(System.currentTimeMillis()),seat="1";JSONArray trains=new JSONArray();JSONObject selected,observed;ScheduledFuture<?> job;int rateLimitHits=0;long checks=0,lastCheckedAt=0,nextDueElapsed=0,startedAt=0;
 static final class WatchTask {final JSONObject target;final String cabin,from,to,date;volatile JSONObject observed;volatile boolean live=true,booking=false;volatile long due,checked;ScheduledFuture<?> job;WatchTask(JSONObject target,String cabin,String from,String to,String date)throws Exception{this.target=new JSONObject(target.toString());this.cabin=cabin;this.from=from;this.to=to;this.date=date;}}
 String queryOutcome="initial",queryError="";int queryRevision=0;
 void invalidateSearch(){queryRevision++;trains=new JSONArray();selected=null;queryOutcome="draft";queryError="";say("조회 조건이 변경되었습니다 · 열차 조회를 눌러주세요");}
 final java.util.LinkedHashMap<String,TrainStops.Result> stopCache=new java.util.LinkedHashMap<>();String loadingStops="";long stopsRevision=0;
 void loadStops(JSONObject train){if(!network.ready()){alert("모바일 데이터 연결 필요",MobileNetworkPolicy.HELP);return;}if(busy){alert("처리 중","현재 요청이 끝난 뒤 다시 눌러주세요.");return;}if(!TermsConsent.accepted(app)||retryWaitSeconds()>0){alert("정차역 조회 불가","이용안내 동의와 서버 요청 제한 안내를 확인해주세요.");return;}final JSONObject snapshot;try{snapshot=new JSONObject(train.toString());}catch(Exception e){alert("정차역 조회 불가","열차를 다시 조회해주세요.");return;}final String key=TrainStops.key(snapshot);if(stopCache.containsKey(key))return;loadingStops=key;stopsRevision++;run("경유 정차역 조회 중",()->{TrainStops.Result result;try{result=TrainStops.segment(api.trainSchedule(snapshot),snapshot);}finally{deferNetwork(1000);}main.post(()->{cacheStops(key,result);stopsRevision++;update();});},true);}
 void cacheStops(String key,TrainStops.Result result){stopCache.put(key,result);long chars=0;for(TrainStops.Result v:stopCache.values())chars+=v.path.length()+v.summary.length();while(stopCache.size()>16||chars>32768){String first=stopCache.keySet().iterator().next();TrainStops.Result old=stopCache.remove(first);chars-=old.path.length()+old.summary.length();}}
 void trimTransientCaches(){sharedSearch.clear();stopCache.clear();clearHistoryCache();stopsRevision++;}
 final NetworkRecovery networkRecovery=new NetworkRecovery();final PollingPolicy polling=new PollingPolicy();final SharedSearch sharedSearch=new SharedSearch();
 long pollingDelay(){long now=System.currentTimeMillis(),delay=1000;for(WatchTask w:watches)if(w.live)delay=Math.max(delay,TimingPolicy.delayMillis(TimingPolicy.departureMillis(w.date,w.target.optString("h_dpt_tm")),now));return Math.max(delay,polling.recoveryFloor());}
 synchronized void deferNetwork(long millis){nextNetworkAt=Math.max(nextNetworkAt,SystemClock.elapsedRealtime()+millis);}
 JSONArray fetchSearch(String f,String t,String d,String h)throws Exception{final int revision=generation;final String owner=accountKey;final long networkVersion=networkRecovery.epoch();try{JSONArray rows=api.search(f,t,d,h);polling.succeeded();long received=System.currentTimeMillis();SeatAvailability.stamp(rows,received);deferNetwork(pollingDelay());if(revision==generation&&owner.equals(accountKey)&&network.ready()&&networkVersion==networkRecovery.epoch())sharedSearch.put(f,t,d,rows,received,nextNetworkAt);return rows;}catch(Exception e){sharedSearch.clear();deferNetwork(Math.max(1000,polling.recoveryFloor()));throw e;}}
 void awaitNetworkTurn()throws InterruptedException{long left;while((left=nextNetworkAt-SystemClock.elapsedRealtime())>0)Thread.sleep(Math.min(left,1000));}
 final CopyOnWriteArrayList<WatchTask> watches=new CopyOnWriteArrayList<>();volatile long nextNetworkAt=0;
 int watchCount(){return watches.size();}
 WatchTask watching(JSONObject train,String cabin){for(WatchTask w:watches)if(w.live&&w.cabin.equals(cabin)&&sameTrain(w.target,train))return w;return null;}
 JSONObject shownFor(JSONObject train){WatchTask latest=null;for(WatchTask w:watches)if(w.live&&sameTrain(w.target,train)&&w.observed!=null&&(latest==null||w.checked>latest.checked))latest=w;return latest==null?train:latest.observed;}
 String routeFrom(JSONObject train){String name=train.optString("h_dpt_rs_stn_nm");if(!name.isEmpty())return name;for(WatchTask w:watches)if(sameTrain(w.target,train))return w.from;return from;}
 String routeTo(JSONObject train){String name=train.optString("h_arv_rs_stn_nm");if(!name.isEmpty())return name;for(WatchTask w:watches)if(sameTrain(w.target,train))return w.to;return to;}
 boolean live(int g,WatchTask w){return g==generation&&w.live;}
 void updateNextDue(){nextDueElapsed=0;for(WatchTask w:watches)if(w.live&&w.due>0&&(nextDueElapsed==0||w.due<nextDueElapsed))nextDueElapsed=w.due;}
 void finishWatch(WatchTask w,String message){w.live=false;watches.remove(w);WatchJournal.running(app,watchCount());if(w.job!=null)w.job.cancel(false);phase=watches.isEmpty()?"idle":"watch";nextDueElapsed=0;for(WatchTask other:watches)if(other.due>0&&(nextDueElapsed==0||other.due<nextDueElapsed))nextDueElapsed=other.due;say(message);if(watches.isEmpty()&&service!=null)service.finishAfterAlerts();}
 void stopWatch(JSONObject train,String cabin){WatchTask w=watching(train,cabin);if(w==null)return;if(w.booking){alert("예약 요청 중","예약 응답을 확인한 뒤 이 항목을 정리할 수 있습니다.");return;}finishWatch(w,"선택한 객실의 감시를 중지했습니다 · "+watchCount()+"개 → "+(watchCount()-1)+"개");}
 NativeController(Context ctx){app=ctx;interruptionNotice=WatchJournal.recover(ctx);network=new MobileNetwork(ctx);RetiredIntegration.clear(ctx);vault=new LoginVault(ctx);if(!deviceSecurity.allowRemember)vault.clear();SharedPreferences lastRoute=ctx.getSharedPreferences("last_query",0);String savedFrom=lastRoute.getString("from","서울"),savedTo=lastRoute.getString("to","부산");if(!savedFrom.trim().isEmpty()&&!savedTo.trim().isEmpty()&&!savedFrom.equals(savedTo)){from=savedFrom;to=savedTo;}ctx.getSharedPreferences("settings",0).edit().remove("pollSeconds").remove("randomDefault08").apply();io.setRemoveOnCancelPolicy(true);SharedPreferences p=ctx.getSharedPreferences("device",0);String id=p.getString("id",null);if(id==null){id=java.util.UUID.randomUUID().toString().replace("-","").substring(0,16);p.edit().putString("id",id).apply();}api=new KorailApi(id,Build.VERSION.RELEASE,Build.MODEL,network);api.authorization=()->DeviceLicense.require(app);networkPaused=!network.ready();networkRecovery.observe(!networkPaused);network.start(()->main.post(this::networkChanged));}
 boolean observeNetwork(){boolean ready=network.ready();boolean recovered=networkRecovery.observe(ready);networkPaused=!ready;if(recovered&&active()){sharedSearch.clear();deferNetwork(NetworkRecovery.settleMillis(pollingDelay()));}return ready;}
 void networkChanged(){sharedSearch.clear();observeNetwork();if(active()){if(networkPaused)say(MobileNetworkPolicy.NOTICE);else if(manualNotice.isEmpty()&&retryWaitSeconds()==0&&!app.getSharedPreferences("runtime",0).getBoolean("pending",false))say("모바일 데이터 연결 복구 확인 · 다음 조회 주기를 기다립니다");else update();}else{update();if(!networkPaused&&listener.get()!=null&&TermsConsent.accepted(app)){if(loginWidth>0&&loginHeight>0)tryAutoLogin(loginWidth,loginHeight);}}}
 boolean pauseForNetwork(int g,WatchTask task,boolean direct){if(observeNetwork())return false;main.post(()->{if(!live(g,task))return;if(direct){finishWatch(task,"모바일 데이터 연결이 없어 예약 요청을 시작하지 않았습니다");alert("모바일 데이터 연결 필요",MobileNetworkPolicy.HELP);}else{say(MobileNetworkPolicy.NOTICE);schedule(g,task,MobileNetworkPolicy.LOCAL_RECHECK_MILLIS,false);}});return true;}

 boolean active(){return phase.equals("watch")||phase.equals("booking");}
 void update(){if(listener.get()!=null)listener.get().update();if(service!=null)service.update(lastStatus);}
 void say(String s){lastStatus=s;update();}
 void alert(String title,String s){if(listener.get()!=null)listener.get().alert(title,s);}
 volatile boolean localReauthPending=false;
 void checkSessionAge()throws KorailApi.LocalSessionExpired{if(api.loggedIn&&(localReauthPending||api.lifetime.expired(SessionLifetime.now())))throw new KorailApi.LocalSessionExpired();}
 void sessionBackground(){api.lifetime.background(SessionLifetime.now());}
 void sessionForeground(){boolean expired=api.lifetime.foreground(SessionLifetime.now(),active());if(!api.loggedIn||!expired)return;localReauthPending=true;io.execute(()->{if(api.loggedIn&&localReauthPending){KorailApi.LocalSessionExpired e=new KorailApi.LocalSessionExpired();recordBlocked(e);main.post(()->{if(active())stop("감시 중지: "+manualNotice);else say("재로그인이 필요합니다");alert("수동 확인 필요",manualNotice);});}});}
 interface Work {void run()throws Exception;}
 void run(String title,Work work){run(title,work,false);}
 void run(String title,Work work,boolean allowWatching){run(title,work,allowWatching,false);}
 void runAuth(String title,Work work){run(title,work,false,true);}
 void run(String title,Work work,boolean allowWatching,boolean authentication){if(!DeviceLicense.allowed(app)){searching=false;update();alert("기기 인증 필요",DeviceLicense.NOTICE);return;}if(!TermsConsent.accepted(app)){searching=false;update();alert("이용안내 동의 필요","앱을 다시 열어 이용안내에 동의해주세요.");return;}if(!network.ready()){networkPaused=true;if(searching&&"loading".equals(queryOutcome)){queryOutcome="network";queryError=MobileNetworkPolicy.HELP;}searching=false;update();alert("모바일 데이터 연결 필요",MobileNetworkPolicy.NOTICE+"\n\n"+MobileNetworkPolicy.HELP);return;}if(busy||(active()&&!allowWatching)){alert("작업 중","현재 작업을 완료하거나 감시를 중지하세요.");return;}if(retryWaitSeconds()>0){searching=false;update();alert("수동 확인 필요","서버 대기 시간이 "+retryWaitSeconds()+"초 남았습니다. 대기 후 코레일 앱에서 상태를 확인해주세요. 자동 재시도하지 않습니다.");return;}final boolean hadWatch=active();final int submittedGeneration=generation;busy=true;say(title);long delay=Math.max(0,nextNetworkAt-SystemClock.elapsedRealtime());io.schedule(()->{try{awaitNetworkTurn();DeviceLicense.require(app);if(!authentication)checkSessionAge();if(allowWatching&&hadWatch&&(submittedGeneration!=generation||!api.loggedIn))throw new Exception("감시 상태가 변경되어 조회를 중지했습니다. 상태를 확인한 뒤 다시 조회해주세요.");work.run();}catch(Exception e){if(e instanceof KorailApi.NetworkPaused){sharedSearch.clear();networkRecovery.observe(false);networkPaused=true;main.post(()->say(MobileNetworkPolicy.NOTICE));}else{boolean blocked=blocked(e);if(blocked)recordBlocked(e);main.post(()->{if(blocked&&active())stop("감시 중지: "+safe(e));else say("실패: "+safe(e));if(blocked){alert("수동 확인 필요",manualNotice);if(listener.get()==null)Alerts.send(app,false,manualNotice);}});}}finally{deferNetwork(1000);main.post(()->{if(searching&&"loading".equals(queryOutcome)){queryOutcome="error";queryError=lastStatus;}busy=false;searching=false;if(!loadingStops.isEmpty()){loadingStops="";stopsRevision++;}update();});}},delay,TimeUnit.MILLISECONDS);}

 static boolean blocked(Exception e){return e instanceof KorailApi.AccessCheck||e instanceof KorailApi.RateLimited;}
 long retryWaitSeconds(){long left=blockedUntil-SystemClock.elapsedRealtime();return left<=0?0:1+(left-1)/1000;}
 void recordBlocked(Exception e){localReauthPending=false;clearHistoryCache();sharedSearch.clear();vault.clear();api.clearSession();accountKey="";historyCheckedAt=0;autoLoginAttempted=true;
  if(e instanceof KorailApi.RateLimited){long now=SystemClock.elapsedRealtime(),seconds=Math.max(1,((KorailApi.RateLimited)e).seconds),room=Long.MAX_VALUE-now;blockedUntil=now+(seconds>room/1000?room:seconds*1000);}
  manualNotice=RecoveryGuide.message(e,app.getSharedPreferences("runtime",0).getBoolean("pending",false));
 }
 static String safe(Exception e){String msg=e.getMessage();return msg==null?e.getClass().getSimpleName():msg;}
 void login(String id,String pw,int width,int height){login(id,pw,width,height,true);}
 void login(String id,String pw,int width,int height,boolean remember){autoLoginAttempted=true;runAuth("로그인 중",()->{sharedSearch.clear();vault.clear();accountKey="";historyCheckedAt=0;try{api.login(id,pw,width,height,Build.VERSION.SDK_INT);}catch(Exception e){api.clearSession();throw e;}manualNotice="";accountKey=ReservationLedger.account(id);historyCheckedAt=0;String note="";localReauthPending=false;api.lifetime.authenticated(SessionLifetime.now());if(remember&&deviceSecurity.allowRemember)try{vault.save(id,pw);}catch(Exception e){note=" · 자동 로그인 저장 실패";}final String result="로그인 완료"+(remember&&deviceSecurity.allowRemember&&note.isEmpty()?" · 다음 실행 시 자동 로그인":note);main.post(()->say(result));});}
 void tryAutoLogin(int width,int height){loginWidth=width;loginHeight=height;if(!DeviceLicense.allowed(app)||!TermsConsent.accepted(app)||!network.ready())return;if(!deviceSecurity.allowRemember){vault.clear();autoLoginAttempted=true;return;}if(!interruptionNotice.isEmpty()||autoLoginAttempted||api.loggedIn||busy||active())return;autoLoginAttempted=true;if(!vault.has())return;runAuth("자동 로그인 중",()->{try{String[] saved=vault.read();try{api.login(saved[0],saved[1],width,height,Build.VERSION.SDK_INT);accountKey=ReservationLedger.account(saved[0]);localReauthPending=false;api.lifetime.authenticated(SessionLifetime.now());manualNotice="";}finally{java.util.Arrays.fill(saved,null);}main.post(()->say("자동 로그인 완료"));}catch(Exception e){vault.clear();api.clearSession();accountKey="";historyCheckedAt=0;if(blocked(e))recordBlocked(e);main.post(()->{say("자동 로그인 중단 · 다시 로그인해주세요 · "+safe(e));if(blocked(e))alert("수동 확인 필요",manualNotice);});}});}
 void logout(){if(busy||active()){alert("작업 중","감시나 현재 작업을 종료한 뒤 로그아웃해주세요.");return;}clearHistoryCache();sharedSearch.clear();vault.clear();autoLoginAttempted=true;api.clearSession();accountKey="";historyCheckedAt=0;say("로그아웃했습니다 · 저장한 자동 로그인 정보도 삭제했습니다");}
 JSONArray historyRows(){if(!api.loggedIn||accountKey.isEmpty())return new JSONArray();return readHistory(accountKey);}
 String cachedHistoryOwner="",cachedHistoryRaw="";JSONArray cachedHistory;
 synchronized void clearHistoryCache(){cachedHistoryOwner="";cachedHistoryRaw="";cachedHistory=null;}
 synchronized JSONArray readHistory(String owner){try{String raw=app.getSharedPreferences("reservation_history",0).getString(owner,"[]");if(cachedHistory!=null&&owner.equals(cachedHistoryOwner)&&raw.equals(cachedHistoryRaw))return cachedHistory;JSONArray rows=new JSONArray(raw);clearHistoryCache();if(raw.length()<=262144){cachedHistoryOwner=owner;cachedHistoryRaw=raw;cachedHistory=rows;}return rows;}catch(Exception e){clearHistoryCache();return new JSONArray();}}
 void saveHistory(String owner,JSONArray rows){clearHistoryCache();if(!owner.isEmpty())app.getSharedPreferences("reservation_history",0).edit().putString(owner,rows.toString()).commit();}
 boolean hasPaymentRecords(){JSONArray rows=historyRows();long now=System.currentTimeMillis();for(int i=0;i<rows.length();i++){JSONObject r=rows.optJSONObject(i);if(r!=null&&ReservationLedger.pendingPayment(r,r,r.optString("_bookedCabin"),now))return true;}return false;}
 int reconcileHistory(String owner)throws Exception{JSONArray incoming=api.reservationHistory(),merged=ReservationLedger.reconcilePayments(readHistory(owner),incoming,System.currentTimeMillis());saveHistory(owner,merged);historyCheckedAt=System.currentTimeMillis();return incoming.length();}
 void syncHistory(){if(!api.loggedIn||accountKey.isEmpty()){alert("로그인 필요","로그인한 뒤 예약 내역을 동기화해주세요.");return;}if(busy||active())return;final String owner=accountKey;searching=true;run("예약 내역을 동기화하고 있습니다",()->{int count=reconcileHistory(owner);main.post(()->say("예약 내역 "+count+"건 동기화 완료"));});}

 void hideHistory(String recordKey,boolean hidden){try{JSONArray rows=historyRows();for(int i=0;i<rows.length();i++){JSONObject r=rows.getJSONObject(i);if(ReservationLedger.key(r).equals(recordKey))r.put("hidden",hidden);}saveHistory(accountKey,rows);update();}catch(Exception e){alert("내역 정리","기록을 변경하지 못했습니다");}}
 void recordBooking(String owner,JSONObject target,String f,String t,String pnr,String deadline)throws Exception{recordBooking(owner,target,f,t,pnr,deadline,seat,0);}
 void recordBooking(String owner,JSONObject target,String f,String t,String pnr,String deadline,String cabin,long until)throws Exception{JSONObject r=new JSONObject();for(String k:new String[]{"h_trn_no","h_trn_clsf_nm","h_run_dt","h_dpt_dt","h_dpt_tm","h_arv_tm","h_dpt_rs_stn_cd","h_arv_rs_stn_cd"})r.put(k,target.optString(k));r.put("h_dpt_rs_stn_nm",f).put("h_arv_rs_stn_nm",t).put("h_pnr_no",pnr).put("deadline",deadline).put("source","local").put("_bookedCabin",cabin).put("_paymentPending",true).put("_paymentUntil",until);saveHistory(owner,ReservationLedger.merge(readHistory(owner),new JSONArray().put(r)));}
 JSONObject paymentFor(JSONObject train,String cabin){JSONArray rows=historyRows();long now=System.currentTimeMillis();for(int i=rows.length()-1;i>=0;i--){JSONObject record=rows.optJSONObject(i);if(record!=null&&ReservationLedger.pendingPayment(record,train,cabin,now))return record;}return null;}
 void search(String f,String t,String d,String h){
  if(busy){alert("작업 중","현재 조회를 마친 뒤 다시 눌러주세요.");return;}
  final int request=++queryRevision;from=f;to=t;date=d;time=h;trains=new JSONArray();selected=null;queryOutcome="loading";queryError="";searching=true;
  run("열차를 조회하고 있습니다",()->{
   try{
    if(api.loggedIn&&!accountKey.isEmpty()&&hasPaymentRecords())try{reconcileHistory(accountKey);}catch(Exception e){if(blocked(e))throw e;}
    String actual=TimingPolicy.searchTime(d,h,System.currentTimeMillis());JSONArray rows=fetchSearch(f,t,d,actual);
    JSONArray filtered=new JSONArray();long received=System.currentTimeMillis();for(int i=0;i<rows.length();i++){JSONObject row=rows.getJSONObject(i);if(TimingPolicy.future(row.optString("h_dpt_dt",d),row.optString("h_dpt_tm"),received))filtered.put(row);}
    main.post(()->{if(request!=queryRevision)return;app.getSharedPreferences("last_query",0).edit().putString("from",f).putString("to",t).commit();SharedPreferences usagePrefs=app.getSharedPreferences("station_usage",0);StationUsage usage=new StationUsage(usagePrefs.getString("items","[]"));usage.route(f,t);usagePrefs.edit().putString("items",usage.json()).commit();if(api.loggedIn)manualNotice="";from=f;to=t;date=d;time=actual;trains=filtered;selected=null;queryOutcome=filtered.length()==0?"empty":"success";queryError="";say(filtered.length()==0?"조회된 열차가 없습니다":filtered.length()+"편 조회 · "+actual.substring(0,2)+":"+actual.substring(2,4)+" 이후");});
   }catch(Exception e){main.post(()->{if(request==queryRevision){queryOutcome=e instanceof KorailApi.NetworkPaused?"network":"error";queryError=safe(e);update();}});throw e;}
  },true);
  if(!busy&&"loading".equals(queryOutcome)){searching=false;queryOutcome="error";queryError=manualNotice.isEmpty()?"현재 조회를 진행할 수 없습니다. 상단 안내를 확인해주세요.":manualNotice;update();}
 }
 void clearPendingAfterReview(){if(busy||active()||io.getActiveCount()>0)throw new IllegalStateException("현재 작업을 완료하거나 중지한 뒤 해제해주세요.");if(!app.getSharedPreferences("runtime",0).edit().putBoolean("pending",false).commit())throw new IllegalStateException("잠금 해제를 저장하지 못했습니다. 다시 시도해주세요.");say("이전 예약 확인 완료 · 잠금을 해제했습니다");}
 void stop(String msg){WatchJournal.stopped(app);sharedSearch.clear();generation++;for(WatchTask w:watches){w.live=false;if(w.job!=null)w.job.cancel(true);}watches.clear();phase="idle";nextDueElapsed=0;if(job!=null)job.cancel(true);api.cancel();say(msg);if(service!=null)service.finish();}
 void begin(){begin(false);}
 void begin(boolean direct){addWatch(selected,seat,from,to,date,direct);}
 synchronized void addWatch(JSONObject train,String cabin,String f,String t,String d,boolean direct){if(!DeviceLicense.allowed(app)){alert("기기 인증 필요",DeviceLicense.NOTICE);return;}if(!interruptionNotice.isEmpty()){alert("이전 감시 중단 확인",interruptionNotice);return;}if(!TermsConsent.accepted(app)){alert("이용안내 동의 필요","앱을 열어 이용안내에 동의해주세요.");return;}
  if(busy||phase.equals("booking")){alert("처리 중","현재 예약 요청이 끝난 뒤 추가해주세요.");return;}
  if(train==null||!api.loggedIn){say("열차 선택과 코레일 로그인이 필요합니다");return;}
  if(watching(train,cabin)!=null){say("이미 감시 중인 객실입니다");return;}
  if(watchCount()>=3){alert("감시 3개 사용 중","기존 감시를 하나 중지한 뒤 추가해주세요.");return;}
  if(paymentFor(train,cabin)!=null){say("이미 예약 성공한 객실입니다 · 공식 앱에서 예약 내역과 결제를 확인하세요");return;}
  if(app.getSharedPreferences("runtime",0).getBoolean("pending",false)){say("이전 예약 결과를 공식 앱에서 확인해주세요");return;}
  if(direct&&!network.ready()){alert("모바일 데이터 연결 필요",MobileNetworkPolicy.HELP);return;}
  if(direct&&!SeatAvailability.available(train,cabin.equals("1"))){say("예약 가능한 객실을 선택해주세요");return;}
  if(!TimingPolicy.future(d,train.optString("h_dpt_tm"),System.currentTimeMillis())){say("출발 시각이 지난 열차입니다. 다시 조회하세요");return;}
  try{if(watches.isEmpty()){generation++;checks=0;startedAt=System.currentTimeMillis();}WatchTask w=new WatchTask(train,cabin,f,t,d);watches.add(w);observed=null;phase=direct?"booking":"watch";networkPaused=!network.ready();say(direct?"예약 요청 중":networkPaused?MobileNetworkPolicy.NOTICE:"빈자리 감시 시작 · "+watchCount()+"/3개");if(!w.live)return;WatchJournal.running(app,watchCount());schedule(generation,w,0,direct);if(!direct)main.post(()->{Listener current=listener.get();if(current!=null)current.watchStarted(w.target,w.cabin);});}catch(Exception e){alert("감시 추가 실패",safe(e));}
 }
 void schedule(int g,WatchTask task,long delayMs,boolean direct){final JSONObject target=task.target;final String cabin=task.cabin,f=task.from,t=task.to,d=task.date;task.due=SystemClock.elapsedRealtime()+delayMs;updateNextDue();task.job=io.schedule(()->{
  boolean reservationAttempted=false;final String accountForRequest=accountKey;
  try{
   if(!live(g,task))return;
   if(!DeviceLicense.allowed(app)){main.post(()->{if(live(g,task))stop("감시 중지: 기기 인증을 확인해주세요");});return;}
   checkSessionAge();
   if(!api.loggedIn){main.post(()->{if(live(g,task))stop("감시 중지: 로그인 상태를 확인해주세요");});return;}
   if(!TimingPolicy.future(d,target.optString("h_dpt_tm"),System.currentTimeMillis())){main.post(()->{if(live(g,task))finishWatch(task,"출발 시각이 되어 해당 감시를 종료했습니다");});return;}
   if(pauseForNetwork(g,task,direct))return;
   JSONArray shared=direct?null:sharedSearch.forWatch(f,t,d,target,task.checked,SystemClock.elapsedRealtime());
   long defer=nextNetworkAt-SystemClock.elapsedRealtime();if(shared==null&&defer>0){schedule(g,task,defer,direct);return;}
   if(!direct&&shared==null){WatchTask turn=task;for(WatchTask other:watches)if(other.live&&!other.booking&&other.checked<turn.checked)turn=other;if(turn!=task){schedule(g,task,Math.max(50,turn.due-SystemClock.elapsedRealtime()),false);return;}}
   main.post(()->{if(live(g,task)){task.due=0;updateNextDue();say(direct?"예약 요청 중":"좌석을 확인하고 있습니다");}});
   if(!TimingPolicy.future(d,target.optString("h_dpt_tm"),System.currentTimeMillis())){main.post(()->{if(live(g,task))finishWatch(task,"출발 시각이 되어 해당 감시를 종료했습니다");});return;}
   final long inquiryNetworkEpoch=networkRecovery.epoch();JSONObject found=target;
   if(!direct){
   JSONArray rows=shared!=null?shared:fetchSearch(f,t,d,target.optString("h_dpt_tm"));found=null;
   for(int i=0;i<rows.length();i++){JSONObject row=rows.getJSONObject(i);if(sameTrain(target,row)){if(found!=null)throw new Exception("동일 열차가 중복되어 중지합니다");found=row;}}
   if(found==null)throw new Exception("선택 열차가 조회 결과에 없습니다. 날짜·시간을 다시 확인하세요");
   long received=found.optLong("_seatCheckedAt",System.currentTimeMillis());final JSONObject latest=found;main.post(()->{if(live(g,task)){task.observed=latest;task.checked=received;observed=latest;try{trains=SeatAvailability.merge(trains,rows,received);}catch(Exception ignored){}}});rateLimitHits=0;lastCheckedAt=received;if(shared==null)checks++;
   if(!SeatAvailability.available(found,cabin.equals("1"))){long wait=Math.max(1,nextNetworkAt-SystemClock.elapsedRealtime());if(live(g,task))main.post(()->{if(!live(g,task))return;say("빈자리 감시 중");schedule(g,task,wait,false);});return;}
   }
   if(!live(g,task)||Thread.currentThread().isInterrupted())return;
   if(!TimingPolicy.future(d,target.optString("h_dpt_tm"),System.currentTimeMillis())){main.post(()->{if(live(g,task))finishWatch(task,"출발 시각이 되어 해당 감시를 종료했습니다");});return;}
   if(pauseForNetwork(g,task,direct))return;
   if(!direct&&inquiryNetworkEpoch!=networkRecovery.epoch()){sharedSearch.clear();main.post(()->{if(live(g,task)){say("연결이 변경되어 다음 주기에 좌석을 다시 확인합니다");schedule(g,task,Math.max(1,nextNetworkAt-SystemClock.elapsedRealtime()),false);}});return;}
   checkSessionAge();
   // Persist uncertainty before mutation. Only explicit sold-out rejection can return to read-only monitoring.
   if(app.getSharedPreferences("runtime",0).getBoolean("pending",false))throw new Exception("이전 예약 결과를 확인해주세요");task.booking=true;if(!app.getSharedPreferences("runtime",0).edit().putBoolean("pending",true).commit())throw new Exception("예약 요청 전 상태를 저장하지 못했습니다");main.post(()->{if(live(g,task)){phase="booking";say(direct?"예약 요청 중":"빈자리 발견 · 예약 요청 중");}});
   sharedSearch.clear();reservationAttempted=true;JSONObject result;try{result=api.reserve(found,cabin);}finally{deferNetwork(1000);}String pnr=result.optString("h_pnr_no");
   if(!pnr.matches("[0-9]{6,20}"))throw new Exception("예약번호를 검증하지 못했습니다. 공식 예약 내역을 확인하세요");
   app.getSharedPreferences("runtime",0).edit().putBoolean("pending",false).putString("lastPNR",pnr).commit();
   String deadline=result.optString("h_pay_limit_msg",result.optString("h_ntisu_lmt",result.optString("h_ntisu_lmt_dt")+" "+result.optString("h_ntisu_lmt_tm")));
   try{recordBooking(accountForRequest,target,f,t,pnr,deadline,cabin,ReservationLedger.paymentUntil(result));}catch(Exception ignored){}
   // A confirmed booking must still notify if the user pressed Stop while the response was in flight.
   main.post(()->{if(live(g,task))finishWatch(task,"예약 성공 · 예약번호 "+pnr);String message="예약번호 "+pnr+"\n결제기한: "+deadline+"\n공식 앱 예약 내역에서 확인 후 직접 결제하세요.";Alerts.send(app,false,message);alert("예약 완료",message);});
  }catch(Exception e){
   // A definitive sold-out response says this request did not make a booking.
   // Never clear uncertainty for timeouts, unknown errors, or access restrictions.
   if(e instanceof KorailApi.SoldOut&&reservationAttempted)app.getSharedPreferences("runtime",0).edit().putBoolean("pending",false).commit();
   task.booking=false;
   if(e instanceof KorailApi.NetworkPaused&&!reservationAttempted){sharedSearch.clear();networkRecovery.observe(false);networkPaused=true;main.post(()->{if(live(g,task)){if(direct){finishWatch(task,"모바일 데이터 연결을 확인한 뒤 다시 예약해주세요");alert("모바일 데이터 연결 필요",MobileNetworkPolicy.HELP);}else{say(MobileNetworkPolicy.NOTICE);schedule(g,task,MobileNetworkPolicy.LOCAL_RECHECK_MILLIS,false);}}});return;}
   if(blocked(e))recordBlocked(e);
   if(!live(g,task))return;
   if(!direct&&!reservationAttempted){long recovery=polling.failedRead(e);if(recovery>=0){sharedSearch.clear();deferNetwork(recovery);main.post(()->{if(live(g,task)){say(e instanceof KorailApi.ResponseFormat||e instanceof org.json.JSONException?"일시적인 데이터 조회 실패 · 대기 후 다시 확인합니다":"일시적인 통신 오류 · 대기 후 좌석 확인을 이어갑니다");schedule(g,task,Math.max(1,nextNetworkAt-SystemClock.elapsedRealtime()),false);}});return;}}

   if(direct&&e instanceof KorailApi.SoldOut){main.post(()->{if(!live(g,task))return;try{JSONObject sold=new JSONObject(target.toString());sold.put(cabin.equals("1")?"h_gen_rsv_cd":"h_spe_rsv_cd","13").put(cabin.equals("1")?"h_gen_rsv_nm":"h_spe_rsv_nm","매진");JSONArray rows=new JSONArray().put(sold);long now=System.currentTimeMillis();SeatAvailability.stamp(rows,now);trains=SeatAvailability.merge(trains,rows,now);selected=sold;}catch(Exception ignored){}finishWatch(task,"예약 시점에 매진되었습니다 · 취소표 감시를 선택할 수 있습니다");alert("예약 불가","예약 요청 시점에 좌석이 매진되었습니다. 필요하면 취소표 감시를 시작해주세요.");});return;}
   if(e instanceof KorailApi.SoldOut){long now=System.currentTimeMillis();if(TimingPolicy.future(d,target.optString("h_dpt_tm"),now)){long wait=TimingPolicy.delayMillis(TimingPolicy.departureMillis(d,target.optString("h_dpt_tm")),now);final boolean raced=reservationAttempted;main.post(()->{if(!live(g,task))return;phase="watch";if(!raced){lastCheckedAt=now;checks++;}try{JSONObject sold=new JSONObject((task.observed!=null?task.observed:target).toString());sold.put(cabin.equals("1")?"h_gen_rsv_cd":"h_spe_rsv_cd","13");sold.put(cabin.equals("1")?"h_gen_rsv_nm":"h_spe_rsv_nm","매진");task.observed=sold;observed=sold;}catch(JSONException ignored){}say((raced?"예약 시점에 잔여석 없음":"잔여석 없음")+" · 감시 유지");schedule(g,task,wait,false);});return;}}
   main.post(()->{if(!live(g,task))return;String msg=blocked(e)?manualNotice:"감시 중지: "+safe(e)+"\n자동 재조회·재로그인하지 않습니다. 공식 앱에서 상태를 확인하세요."+(app.getSharedPreferences("runtime",0).getBoolean("pending",false)?"\n예약 요청 후 오류라면 예약 내역도 확인하세요.":"");stop(msg);Alerts.send(app,false,msg);alert(blocked(e)?"수동 확인 필요":"감시가 중지되었습니다",msg);});}
 },delayMs,TimeUnit.MILLISECONDS);}

 static boolean sameTrain(JSONObject a,JSONObject b){for(String k:new String[]{"h_trn_no","h_run_dt","h_dpt_dt","h_dpt_tm","h_dpt_rs_stn_cd","h_arv_rs_stn_cd"})if(a.optString(k).isEmpty()||!a.optString(k).equals(b.optString(k)))return false;return true;}
}
