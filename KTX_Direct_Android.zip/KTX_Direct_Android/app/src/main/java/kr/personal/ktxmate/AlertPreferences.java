package kr.personal.ktxmate;
import android.content.Context;
import android.content.SharedPreferences;
import java.time.*;
final class AlertPreferences {
 static boolean quiet(Context c){SharedPreferences p=c.getSharedPreferences("alert_options",0);LocalTime now=LocalTime.now(ZoneId.systemDefault());return QuietHours.within(p.getBoolean("quiet",false),p.getInt("start",1380),p.getInt("end",420),now.getHour()*60+now.getMinute());}
 static String clock(int minute){return String.format(java.util.Locale.US,"%02d:%02d",minute/60,minute%60);}
}
