package kr.personal.ktxmate;
import org.json.JSONObject;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
final class TrainPresentation {
 static String duration(JSONObject r){try{String d=r.optString("h_dpt_dt"),a=r.optString("h_arv_dt");LocalDateTime start=LocalDateTime.of(LocalDate.parse(d,TimingPolicy.DATE),LocalTime.parse(r.optString("h_dpt_tm"),TimingPolicy.TIME));LocalDateTime end=LocalDateTime.of(LocalDate.parse(a.isEmpty()?d:a,TimingPolicy.DATE),LocalTime.parse(r.optString("h_arv_tm"),TimingPolicy.TIME));if(a.isEmpty()&&end.isBefore(start))end=end.plusDays(1);long minutes=Duration.between(start,end).toMinutes();if(minutes<0||minutes>2880)return "";return minutes>=60?(minutes/60)+"시간 "+(minutes%60)+"분":minutes+"분";}catch(Exception e){return "";}}
 static String date(JSONObject r){try{return LocalDate.parse(r.optString("h_dpt_dt"),TimingPolicy.DATE).format(DateTimeFormatter.ofPattern("M.d (E)",Locale.KOREAN));}catch(Exception e){return "";}}
 static String fare(JSONObject r,boolean general){String s=r.optString(general?"h_rsv_psb_nm":"h_spe_rsv_psb_nm").trim();java.util.regex.Matcher m=java.util.regex.Pattern.compile("([0-9][0-9,]*\\s*원)").matcher(s);return m.find()?m.group(1):"";}
}
