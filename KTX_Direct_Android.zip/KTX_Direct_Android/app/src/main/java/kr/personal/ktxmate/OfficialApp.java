package kr.personal.ktxmate;
import android.content.*;
final class OfficialApp {
 static boolean open(Context ctx){try{Intent launch=ctx.getPackageManager().getLaunchIntentForPackage("com.korail.talk");if(launch==null)return false;ctx.startActivity(launch);return true;}catch(Exception e){return false;}}
}
