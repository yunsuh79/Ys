package kr.personal.ktxmate;
import android.os.Build;
import java.io.File;
import java.util.Locale;
/** Local warning heuristics, not a device attestation or proof of compromise. */
final class DeviceSecurity {
 static final class Result {final boolean allowRemember;final String message;Result(boolean allowed,String text){allowRemember=allowed;message=text;}}
 static Result evaluate(boolean su,String tags,String fingerprint,String model,String product,String hardware){String hints=(fingerprint+" "+model+" "+product+" "+hardware).toLowerCase(Locale.ROOT);boolean emulator=hints.contains("generic")||hints.contains("emulator")||hints.contains("sdk_gphone")||hints.contains("goldfish")||hints.contains("ranchu")||hints.contains("google_sdk");boolean modified=tags!=null&&tags.contains("test-keys");if(!su&&!emulator&&!modified)return new Result(true,"기본 보안 점검에서 특이 신호를 찾지 못했습니다. 안전한 기기임을 보증하는 검사는 아닙니다.");return new Result(false,(su?"루팅 관련 파일 흔적이 있습니다. ":"")+(emulator?"에뮬레이터로 추정되는 환경입니다. ":"")+(modified?"테스트 서명 시스템으로 추정됩니다. ":"")+"오탐 또는 탐지 누락이 있을 수 있습니다. 이 환경에서는 저장 계정을 이용한 자동 로그인과 계정정보 저장을 사용하지 않습니다. 기존 자동 로그인 저장정보는 삭제하며, 직접 로그인한 현재 실행의 조회·예약 기능은 사용할 수 있습니다. 신뢰할 수 있는 기기 사용을 권장합니다.");}
 static Result inspect(){boolean su=false;for(String path:new String[]{"/system/bin/su","/system/xbin/su","/sbin/su","/su/bin/su","/system/app/Superuser.apk"})try{if(new File(path).exists())su=true;}catch(SecurityException ignored){}return evaluate(su,Build.TAGS,Build.FINGERPRINT,Build.MODEL,Build.PRODUCT,Build.HARDWARE);}
}
