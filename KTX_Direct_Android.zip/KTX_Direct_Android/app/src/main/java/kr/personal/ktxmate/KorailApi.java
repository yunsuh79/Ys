// Protocol mapping adapted from korail-mobile-api 2.6.2 (Apache-2.0).
package kr.personal.ktxmate;
import org.json.*;
import java.net.*;
import java.io.*;
import java.util.*;
import java.util.zip.GZIPInputStream;
import javax.net.ssl.HttpsURLConnection;
import javax.crypto.*;
import javax.crypto.spec.*;
import java.nio.charset.StandardCharsets;

class KorailApi {
    static final String BASE="https://smart.letskorail.com",QUEUE="https://nf.letskorail.com/ts.wseq";
    final SessionLifetime lifetime=new SessionLifetime();
    final CookieManager cookies=new CookieManager(null,CookiePolicy.ACCEPT_ORIGINAL_SERVER);
    final RequestNetwork requestNetwork;
    interface RequestNetwork {boolean ready();HttpsURLConnection open(URL target)throws Exception;default long generation(){return 0;}default void released(HttpsURLConnection c){}}
    static class ResponseFormat extends IOException {ResponseFormat(){super("일시적인 데이터 조회 실패 · 서버 응답 형식을 확인할 수 없습니다");}}
    static class NetworkPaused extends IOException {NetworkPaused(){super(MobileNetworkPolicy.NOTICE+" · "+MobileNetworkPolicy.HELP);}}
    
    final String deviceId,os,model;
    final long start=System.currentTimeMillis();
    long last=start;
    final ArrayList<Long> intervals=new ArrayList<>();
    volatile String queueState="";
    volatile HttpsURLConnection connection;
    volatile boolean loggedIn=false;
    String memberCard="";
    
    // 생성자: os는 순수 안드로이드 OS 버전("14" 등)으로만 관리
    KorailApi(String id){this(id, "14", "Android");}
    KorailApi(String id,String os,String model){
        this(id, (os!=null&&!os.isEmpty()?os:"14"), model, new RequestNetwork(){
            public boolean ready(){return true;}
            public HttpsURLConnection open(URL target)throws Exception{
                return (HttpsURLConnection) target.openConnection();
            }
        });
    }
    KorailApi(String id,String os,String model,RequestNetwork network){
        this.deviceId=id;
        this.os=(os!=null&&!os.isEmpty()?os:"14");
        this.model=model;
        this.requestNetwork=network;
    }
    
    static LinkedHashMap<String,String> map(String... values){
        LinkedHashMap<String,String> m=new LinkedHashMap<>();
        for(int i=0;i<values.length;i+=2)m.put(values[i],values[i+1]);
        return m;
    }
    
    // 2.6.2 실서버 검증 완료 기본 조합 (AppVersion="7.0.8", Version="250601003")
    static LinkedHashMap<String,String> common(){
        return map("Device","AD","Version","250601003","AppVersion","7.0.8","Key","korail1234567890");
    }
    
    synchronized String token(){
        long now=System.currentTimeMillis();
        intervals.add(now-last);
        last=now;
        if(intervals.size()>5)intervals.remove(0);
        String chars="abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        java.security.SecureRandom rnd=new java.security.SecureRandom();
        StringBuilder r=new StringBuilder();
        for(int i=0;i<4;i++)r.append(chars.charAt(rnd.nextInt(chars.length())));
        return TokenCodec.token(deviceId,os,model,start,now,r.toString(),intervals);
    }
    
    static class RateLimited extends IOException {final long seconds;RateLimited(long seconds){super("서버 요청 제한 · 최소 "+seconds+"초 후 상태 확인 · 자동 재접속 없음");this.seconds=seconds;}}
    static class AccessCheck extends IOException {AccessCheck(String msg){super(msg);}}
    static class LocalSessionExpired extends AccessCheck {LocalSessionExpired(){super("보안을 위해 로그인 세션을 만료했습니다. 직접 다시 로그인해주세요");}}
    static class SessionExpired extends AccessCheck {SessionExpired(){super("로그인 세션 만료 (P058) · 코레일 앱에서 로그인 상태를 확인해주세요");}}
    static class SoldOut extends IOException {SoldOut(){super("IRT010110: 잔여석없음");}}
    
    void clearSession(){lifetime.clear();intervals.clear();loggedIn=false;memberCard="";queueState="";cookies.getCookieStore().removeAll();}
    void cancel(){if(connection!=null)connection.disconnect();}
    
    interface Authorization {void check()throws Exception;}
    Authorization authorization;
    
    String post(String url,LinkedHashMap<String,String> form,boolean protectedRoute)throws Exception{
        if(authorization!=null)authorization.check();
        if(Thread.currentThread().isInterrupted())throw new InterruptedException();
        if(protectedRoute&&loggedIn&&lifetime.expired(SessionLifetime.now())){clearSession();throw new LocalSessionExpired();}
        
        URL target=new URL(url);
        if(!"https".equals(target.getProtocol())||!(target.getHost().equals("smart.letskorail.com")||target.getHost().equals("nf.letskorail.com")))
            throw new IOException("허용되지 않은 서버");
        
        if(requestNetwork==null||!requestNetwork.ready())throw new NetworkPaused();
        long networkVersion=requestNetwork.generation();
        
        HttpsURLConnection c=null;
        try {
            c=requestNetwork.open(target);
            connection=c;
            c.setUseCaches(false);
            c.setRequestProperty("Cache-Control","no-store, no-cache");
            c.setInstanceFollowRedirects(false);
            c.setConnectTimeout(15000);
            c.setReadTimeout(25000);
            c.setRequestMethod("POST");
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type","application/x-www-form-urlencoded; charset=UTF-8");
            c.setRequestProperty("Accept-Encoding","gzip");
            // 순수 안드로이드 OS 버전 문자열만 조합하여 User-Agent 생성
            c.setRequestProperty("User-Agent",target.getHost().equals("smart.letskorail.com")?"korailtalk":"Dalvik/2.1.0 (Linux; U; Android "+os+"; "+model+")");
            
            if(protectedRoute)c.setRequestProperty("x-dynapath-m-token",token());
            for(Map.Entry<String,List<String>> h:cookies.get(target.toURI(),Collections.emptyMap()).entrySet())
                c.setRequestProperty(h.getKey(),String.join("; ",h.getValue()));
            
            StringBuilder body=new StringBuilder();
            for(Map.Entry<String,String> e:form.entrySet()){
                if(e.getValue()==null||e.getValue().isEmpty())continue;
                if(body.length()>0)body.append('&');
                body.append(TokenCodec.enc(e.getKey())).append('=').append(TokenCodec.enc(e.getValue()));
            }
            byte[] bytes=body.toString().getBytes(StandardCharsets.UTF_8);
            c.setFixedLengthStreamingMode(bytes.length);
            
            try(OutputStream out=c.getOutputStream()){out.write(bytes);}
            int status=c.getResponseCode();
            cookies.put(target.toURI(),c.getHeaderFields());
            
            if(status==429)throw new RateLimited(TimingPolicy.retryAfterSeconds(c.getHeaderField("Retry-After"),System.currentTimeMillis()));
            if(status==401||status==403)throw new AccessCheck("서버 접근 제한 HTTP "+status+" · 자동 재접속 없음");
            if(status!=200)throw new IOException("서버 HTTP "+status+" · 자동 재시도하지 않습니다");
            
            InputStream in=c.getInputStream();
            if("gzip".equalsIgnoreCase(c.getContentEncoding()))in=new GZIPInputStream(in);
            try(InputStream input=in;ByteArrayOutputStream out=new ByteArrayOutputStream()){
                byte[] buf=new byte[8192];int n;
                while((n=input.read(buf))>0){
                    out.write(buf,0,n);
                    if(out.size()>3000000)throw new IOException("응답 크기 초과");
                }
                return out.toString("UTF-8");
            }
        } catch(IOException e){
            if(!(e instanceof RateLimited)&&!(e instanceof AccessCheck)&&(!requestNetwork.ready()||networkVersion!=requestNetwork.generation()))
                throw new NetworkPaused();
            throw e;
        } finally {
            connection=null;
            if(c!=null){
                // 각각의 자원 해제 과정을 독립적으로 보호하여 누락 방지
                try {
                    requestNetwork.released(c);
                } catch(Exception ignored) {}
                try {
                    c.disconnect();
                } catch(Exception ignored) {}
            }
        }
    }
    
    JSONObject api(String path,LinkedHashMap<String,String> form,boolean protect)throws Exception{
        return decodeResponse(post(BASE+path,form,protect),protect);
    }
    
    static void checkJsonBudget(String body)throws ResponseFormat{
        if(body==null||body.length()>1000000)throw new ResponseFormat();
        int depth=0;boolean quoted=false,escape=false;
        for(int i=0;i<body.length();i++){
            char ch=body.charAt(i);
            if(quoted){if(escape)escape=false;else if(ch=='\\')escape=true;else if(ch=='"')quoted=false;}
            else if(ch=='"')quoted=true;
            else if(ch=='{'||ch=='['){if(++depth>64)throw new ResponseFormat();}
            else if(ch=='}'||ch==']')depth--;
        }
    }
    
    JSONObject decodeResponse(String body,boolean protect)throws Exception{
        checkJsonBudget(body);JSONObject r;
        try{r=new JSONObject(body);}catch(JSONException e){throw new AccessCheck("JSON 응답이 아닙니다. 차단·점검 여부를 확인하세요.");}
        String message=r.optString("h_msg_txt","").toLowerCase(Locale.ROOT).replaceAll("\\s+","");
        for(String marker:new String[]{"추가인증","본인인증필요","보안문자","자동화된요청","매크로","비정상접근","비정상적인접근","captcha","accessdenied","verifyyouarehuman"})
            if(message.contains(marker))throw new AccessCheck("차단 또는 추가 인증 응답 · 공식 앱에서 확인하세요 · 자동 재접속 없음");
        if(protect&&(!"SUCC".equals(r.optString("strResult"))&&!"FAIL".equals(r.optString("strResult"))))
            throw new AccessCheck("인증 또는 응답 형식 확인 필요 · 조회를 중지합니다");
        if("FAIL".equals(r.optString("strResult"))){
            String code=r.optString("h_msg_cd");
            if("P058".equals(code)){loggedIn=false;throw new SessionExpired();}
            if("IRT010110".equals(code)&&r.optString("h_pnr_no").isEmpty())throw new SoldOut();
            throw new IOException(code+": "+r.optString("h_msg_txt","요청 실패"));
        }
        return r;
    }
    
    interface Operation {JSONObject run()throws Exception;}
    JSONObject queued(String action,Operation op)throws Exception{
        String key="";boolean completed=false;
        try{
            String raw=post(QUEUE+"?opcode=5101&sid=service_1&aid="+action,new LinkedHashMap<>(),false);
            long deadline=System.currentTimeMillis()+90000;
            while(true){
                int p=raw.indexOf(':');
                if(p<0)throw new IOException("대기열 응답 해석 실패");
                String code=raw.substring(0,p).trim();
                Map<String,String> data=new HashMap<>();
                for(String a:raw.substring(p+1).split("&")){
                    int eq=a.indexOf('=');
                    if(eq>=0)data.put(a.substring(0,eq),a.substring(eq+1));
                }
                key=data.getOrDefault("key","");
                if(code.equals("200")||code.equals("300")){queueState="";break;}
                if(!code.equals("201")&&!code.equals("202"))throw new IOException("대기열 거절 "+code);
                queueState="서버 접속 대기"+(data.getOrDefault("nwait","").matches("[0-9]+")?" · "+data.get("nwait")+"명":"");
                if(key.isEmpty()||System.currentTimeMillis()>deadline)throw new IOException("대기열 시간 초과");
                int ttl;
                try{ttl=Integer.parseInt(data.getOrDefault("ttl","1"));}catch(Exception e){ttl=1;}
                Thread.sleep(Math.max(1,Math.min(30,ttl))*1000L);
                raw=post(QUEUE+"?opcode=5002&key="+TokenCodec.enc(key),new LinkedHashMap<>(),false);
            }
            JSONObject result=op.run();completed=true;return result;
        }finally{
            queueState="";
            if(completed&&!key.isEmpty()&&!Thread.currentThread().isInterrupted())
                try{post(QUEUE+"?opcode=5004&key="+TokenCodec.enc(key),new LinkedHashMap<>(),false);}catch(Exception ignored){}
        }
    }
    
    static String encryptedPassword(String password,String key)throws Exception{
        byte[] k=key.getBytes(StandardCharsets.UTF_8);
        if(k.length!=16&&k.length!=24&&k.length!=32)throw new IOException("로그인 암호화 키가 올바르지 않습니다");
        Cipher cipher=Cipher.getInstance("AES/CBC/PKCS5Padding");
        cipher.init(Cipher.ENCRYPT_MODE,new SecretKeySpec(k,"AES"),new IvParameterSpec(Arrays.copyOf(k,16)));
        String inner=Base64.getEncoder().encodeToString(cipher.doFinal(password.getBytes(StandardCharsets.UTF_8)));
        String s=Base64.getUrlEncoder().encodeToString(inner.getBytes(StandardCharsets.UTF_8));
        StringBuilder wrapped=new StringBuilder();
        for(int i=0;i<s.length();i+=76)wrapped.append(s.substring(i,Math.min(i+76,s.length()))).append('\n');
        return wrapped.toString();
    }
    
    JSONObject loginCryptoInfo(int width,int height,int sdk)throws Exception{
        LinkedHashMap<String,String> boot=common();
        boot.put("code","app.login.cphd");
        boot.put("deviceWidth",String.valueOf(width));
        boot.put("deviceHeight",String.valueOf(height));
        boot.put("OSVersion",String.valueOf(sdk));
        JSONObject response=api("/classes/com.korail.mobile.common.code.do",boot,false);
        JSONObject crypto=response.optJSONObject("app.login.cphd");
        if(crypto==null)throw new IOException("로그인 준비 정보 없음 (응답 코드 "+response.optString("h_msg_cd","미확인")+") · 비밀번호는 전송하지 않았습니다");
        Object rawKey=crypto.opt("key");
        if(!(rawKey instanceof String))throw new IOException("로그인 암호화 키 형식 오류 · 비밀번호는 전송하지 않았습니다");
        int n=((String)rawKey).getBytes(StandardCharsets.UTF_8).length;
        if(n!=16&&n!=24&&n!=32)throw new IOException("로그인 암호화 키 길이 오류 · 비밀번호는 전송하지 않았습니다");
        return crypto;
    }
    
    void login(String id,String password,int width,int height,int sdk)throws Exception{
        loggedIn=false;memberCard="";cookies.getCookieStore().removeAll();
        api("/file/CACHE/MobileService.cache",map("timeStamp",String.valueOf(System.currentTimeMillis())),false);
        JSONObject crypto=loginCryptoInfo(width,height,sdk);
        String flag=id.contains("@")?"5":id.matches("[0-9]{11}")?"4":"2";
        LinkedHashMap<String,String> f=common();
        f.putAll(map("txtInputFlg",flag,"txtMemberNo",id,"txtPwd",encryptedPassword(password,crypto.optString("key")),"checkValidPw","Y","idx",crypto.optString("idx")));
        JSONObject r=api("/classes/com.korail.mobile.login.Login",f,true);
        if(!Arrays.asList("IRZ000001","S200").contains(r.optString("h_msg_cd")))
            throw new IOException("로그인 확인 실패: "+r.optString("h_msg_txt"));
        boolean session=false;
        for(HttpCookie cookie:cookies.getCookieStore().getCookies())
            if(cookie.getName().equals("JSESSIONID")&&!cookie.getValue().isEmpty())session=true;
        if(!session)throw new IOException("로그인 세션 없음");
        memberCard=r.optString("strMbCrdNo");
        lifetime.authenticated(SessionLifetime.now());
        loggedIn=true;
    }
    
    static LinkedHashMap<String,String> searchForm(String from,String to,String date,String time){
        LinkedHashMap<String,String> f=common();
        f.putAll(map("txtMenuId","11","radJobId","1","selGoTrain","109","txtTrnGpCd","109","txtGoStart",from,"txtGoEnd",to,"txtGoAbrdDt",date,"txtGoHour",time,"txtPsgFlg_1","1","txtPsgFlg_2","0","txtPsgFlg_3","0","txtPsgFlg_4","0","txtPsgFlg_5","0","txtSeatAttCd_2","000","txtSeatAttCd_3","000","txtSeatAttCd_4","015","ebizCrossCheck","N","srtCheckYn","N","rtYn","N","adjStnScdlOfrFlg","N","qryDvCd","1"));
        return f;
    }
    
    JSONArray search(String from,String to,String date,String time)throws Exception{
        LinkedHashMap<String,String> f=searchForm(from,to,date,time);
        if(!memberCard.isEmpty())f.put("mbCrdNo",memberCard);
        JSONObject r=queued("act_8",()->decodeSearchResponse(post(BASE+"/classes/com.korail.mobile.seatMovie.ScheduleView",f,true)));
        return searchRows(r);
    }
    
    static JSONArray searchRows(JSONObject response)throws Exception{
        Object all=response.opt("trn_infos");
        JSONArray rows=all instanceof JSONArray?(JSONArray)all:all instanceof JSONObject?((JSONObject)all).optJSONArray("trn_info"):null;
        if(rows==null||rows.length()>512)throw new ResponseFormat();
        JSONArray safe=new JSONArray();
        String[] fields={"h_trn_no","h_run_dt","h_dpt_dt","h_dpt_tm","h_arv_dt","h_arv_tm","h_dpt_rs_stn_cd","h_arv_rs_stn_cd","h_dpt_rs_stn_nm","h_arv_rs_stn_nm","h_trn_clsf_cd","h_trn_clsf_nm","h_trn_gp_cd","h_trn_gp_nm","h_dpt_stn_cons_ordr","h_dpt_stn_run_ordr","h_arv_stn_cons_ordr","h_arv_stn_run_ordr","h_seat_att_cd","h_gen_rsv_cd","h_gen_rsv_nm","h_spe_rsv_cd","h_spe_rsv_nm","h_rsv_psb_nm","h_spe_rsv_psb_nm","h_gen_prc","h_spe_prc","h_gen_amt","h_spe_amt"};
        for(int i=0;i<rows.length();i++){
            JSONObject row=rows.optJSONObject(i);
            if(row==null)throw new ResponseFormat();
            JSONObject clean=new JSONObject();
            for(String field:fields){
                Object v=row.opt(field);
                if(v==null||v==JSONObject.NULL)continue;
                if(!(v instanceof String||v instanceof Number)||String.valueOf(v).length()>256)throw new ResponseFormat();
                clean.put(field,String.valueOf(v));
            }
            for(String field:new String[]{"h_trn_no","h_run_dt","h_dpt_dt","h_dpt_tm","h_dpt_rs_stn_cd","h_arv_rs_stn_cd"})
                if(clean.optString(field).isEmpty())throw new ResponseFormat();
            if(!clean.optString("h_trn_no").matches("[0-9]{1,5}")||!clean.optString("h_dpt_rs_stn_cd").matches("[0-9]+")||!clean.optString("h_arv_rs_stn_cd").matches("[0-9]+"))
                throw new ResponseFormat();
            try{
                TimingPolicy.departureMillis(clean.optString("h_dpt_dt"),clean.optString("h_dpt_tm"));
                java.time.LocalDate.parse(clean.optString("h_run_dt"),TimingPolicy.DATE);
            }catch(Exception e){throw new ResponseFormat();}
            safe.put(clean);
        }
        return safe;
    }
    
    JSONObject decodeSearchResponse(String body)throws Exception{
        try{return decodeResponse(body,true);}
        catch(AccessCheck e){throw e;}
        catch(IOException e){
            JSONObject raw=new JSONObject(body);
            if("FAIL".equals(raw.optString("strResult"))&&"WRD000061".equals(raw.optString("h_msg_cd")))
                return new JSONObject().put("strResult","SUCC").put("trn_infos",new JSONArray());
            throw e;
        }
    }
    
    static LinkedHashMap<String,String> trainScheduleForm(JSONObject row)throws Exception{
        String run=row.optString("h_run_dt",row.optString("h_dpt_dt")),number=required(row,"h_trn_no");
        if(!run.matches("[0-9]{8}")||!number.matches("[0-9]{1,5}"))throw new IOException("열차 운행일·번호를 확인할 수 없습니다");
        java.time.LocalDate.parse(run,TimingPolicy.DATE);
        return map("Device","AD","Version","250601003","AppVersion","7.0.8","runDt",run,"trnNo",String.format(java.util.Locale.ROOT,"%05d",Integer.parseInt(number)));
    }
    
    JSONObject trainSchedule(JSONObject row)throws Exception{
        return api("/classes/com.korail.mobile.research.actualTrainSchedule.do",trainScheduleForm(row),true);
    }
    
    JSONArray reservationHistory()throws Exception{
        if(!loggedIn)throw new IOException("로그인이 필요합니다");
        JSONObject response=queued("act_21",()->{
            String body=post(BASE+"/classes/com.korail.mobile.reservation.ReservationView",reservationHistoryForm(),true);
            try{return decodeResponse(body,true);}
            catch(AccessCheck e){throw e;}
            catch(IOException e){
                JSONObject raw=new JSONObject(body);
                if("FAIL".equals(raw.optString("strResult"))&&"P100".equals(raw.optString("h_msg_cd")))
                    return new JSONObject().put("h_jrny_cnt","0");
                throw e;
            }
        });
        return ReservationLedger.rows(response);
    }
    
    static LinkedHashMap<String,String> reservationHistoryForm(){
        LinkedHashMap<String,String> f=common();
        f.put("timeStamp","0");
        return f;
    }
    
    static String required(JSONObject row,String key)throws Exception{
        String v=row.optString(key,"");
        if(v.isEmpty()||v.equals("null"))throw new IOException("열차 예약 필수값 누락: "+key);
        return v;
    }
    
    static LinkedHashMap<String,String> reserveForm(JSONObject row,String seat)throws Exception{
        LinkedHashMap<String,String> f=common();
        f.putAll(map("txtMenuId","11","txtJobId","1101","hidFreeFlg","N","txtStndFlg","N","txtTotPsgCnt","1","txtSeatAttCd1","000","txtSeatAttCd2","000","txtSeatAttCd3","000","txtSeatAttCd4",row.optString("h_seat_att_cd","015"),"txtSeatAttCd5","000","txtJrnyCnt","1","txtCompaCnt1","1","txtPsgTpCd1","1","txtDiscKndCd1","000","txtJrnyTpCd1","11","txtJrnySqno1","001"));
        String[] dst={"txtTrnNo","txtTrnClsfCd","txtTrnGpCd","txtRunDt","txtDptDt","txtDptTm","txtDptRsStnCd","txtDptStnConsOrdr","txtDptStnRunOrdr","txtArvRsStnCd","txtArvStnConsOrdr","txtArvStnRunOrdr"};
        String[] src={"h_trn_no","h_trn_clsf_cd","h_trn_gp_cd","h_run_dt","h_dpt_dt","h_dpt_tm","h_dpt_rs_stn_cd","h_dpt_stn_cons_ordr","h_dpt_stn_run_ordr","h_arv_rs_stn_cd","h_arv_stn_cons_ordr","h_arv_stn_run_ordr"};
        for(int i=0;i<src.length;i++)f.put(dst[i]+"1",required(row,src[i]));
        f.put("txtChgFlg1","N");
        f.put("txtPsrmClCd1",seat);
        return f;
    }
    
    JSONObject reserve(JSONObject row,String seat)throws Exception{
        if(!loggedIn)throw new IOException("로그인이 필요합니다");
        LinkedHashMap<String,String> f=reserveForm(row,seat);
        JSONObject r=queued("act_14",()->api("/classes/com.korail.mobile.certification.TicketReservation",f,true));
        if(!"SUCC".equals(r.optString("strResult"))||r.optString("h_pnr_no","").isEmpty())
            throw new IOException("예약 성공을 확인하지 못했습니다. 공식 예약 내역을 확인하세요");
        return r;
    }
}