package kr.personal.ktxmate;
import android.app.*;
import android.content.*;
import android.content.pm.ServiceInfo;
import android.os.*;

public class MonitorService extends Service {
    static final String START="kr.personal.ktxmate.START",STOP="kr.personal.ktxmate.STOP";
    static final long REMINDER_AFTER_BACKGROUND=345L*60L*1000L;
    final Handler life=new Handler(Looper.getMainLooper());
    NativeController c;PowerManager.WakeLock lock;boolean finished=false,foregroundStarted=false;
    final Runnable heartbeat=new Runnable(){public void run(){if(finished||c==null||!c.active())return;WatchJournal.running(MonitorService.this,c.watchCount());update(c.lastStatus);life.postDelayed(this,60000);}};
    final Runnable wakeRenewal=()->renewWakeLock();
    final Runnable reminder=()->safeAlert("장시간 감시 중입니다. Android 실행 제한이 적용될 수 있습니다. 알림의 배터리 설정에서 안내를 확인하고, 앱을 열어 감시 상태와 예약 내역을 확인해주세요.");
    void noteForeground(boolean visible){life.removeCallbacks(reminder);if(!visible&&foregroundStarted&&!finished)life.postDelayed(reminder,REMINDER_AFTER_BACKGROUND);}
    void renewWakeLock(){life.removeCallbacks(wakeRenewal);if(finished||lock==null)return;if(c!=null&&c.networkPaused&&!"booking".equals(c.phase)){if(lock.isHeld())lock.release();return;}try{lock.acquire(30L*60L*1000L);life.postDelayed(wakeRenewal,10L*60L*1000L);}catch(Exception e){endWithGuide("Android 전원 관리 상태로 감시가 중지되었습니다. 앱을 열어 배터리 설정과 예약 내역을 확인해주세요.");}}
    @Override public void onCreate(){super.onCreate();Alerts.setup(this);c=NativeController.get(this);}
    Notification notification(String msg){
        PendingIntent battery=PendingIntent.getActivity(this,11,new Intent(this,MainActivity.class).putExtra(BackgroundGuide.EXTRA,true).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP|Intent.FLAG_ACTIVITY_CLEAR_TOP),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        PendingIntent stop=PendingIntent.getService(this,10,new Intent(this,MonitorService.class).setAction(STOP),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        return new Notification.Builder(this,Alerts.RUNNING).setSmallIcon(R.drawable.ic_status).setContentTitle(c!=null&&c.active()?(c.networkPaused?"자리봄 · 모바일 데이터 대기":"자리봄 · 감시 중"):"자리봄 · 알림 처리 중").setContentText(msg).setStyle(new Notification.BigTextStyle().bigText(msg)).setContentIntent(Alerts.open(this)).setOngoing(true).setOnlyAlertOnce(true).setVisibility(Notification.VISIBILITY_PRIVATE).addAction(new Notification.Action.Builder(null,"배터리 설정",battery).build()).addAction(new Notification.Action.Builder(null,"감시 중지",stop).build()).build();
    }
    @Override public int onStartCommand(Intent intent,int flags,int startId){
        if(intent==null||STOP.equals(intent.getAction())){try{if(c.active())c.stop("상시 알림에서 감시를 중지했습니다");}catch(Exception ignored){}finally{finish();}return START_NOT_STICKY;}
        try{
            finished=false;
            if(Build.VERSION.SDK_INT>=29)startForeground(100,notification("시작 준비 중"),ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);else startForeground(100,notification("시작 준비 중"));
            foregroundStarted=true;
            if(!c.active()&&(c.selected==null||!c.api.loggedIn||!Alerts.allowed(this))){Alerts.send(this,false,"열차 선택·로그인과 알림 권한을 확인하세요.");finish();return START_NOT_STICKY;}
            c.service=this;
            if(lock==null){lock=((PowerManager)getSystemService(POWER_SERVICE)).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,"Jaribom:Watch");lock.setReferenceCounted(false);}if(!lock.isHeld())renewWakeLock();if(finished)return START_NOT_STICKY;
            noteForeground(c.listener.get()!=null);life.removeCallbacks(heartbeat);life.postDelayed(heartbeat,60000);
            beginFromIntent(intent);if(!c.active())finish();else update(c.lastStatus);
        }catch(Exception e){endWithGuide(BackgroundGuide.startFailure());}
        return START_NOT_STICKY;
    }
    void beginFromIntent(Intent intent)throws Exception{org.json.JSONObject target=intent.hasExtra("watchTarget")?new org.json.JSONObject(intent.getStringExtra("watchTarget")):c.selected;c.addWatch(target,intent.getStringExtra("watchCabin")==null?c.seat:intent.getStringExtra("watchCabin"),intent.getStringExtra("watchFrom")==null?c.from:intent.getStringExtra("watchFrom"),intent.getStringExtra("watchTo")==null?c.to:intent.getStringExtra("watchTo"),intent.getStringExtra("watchDate")==null?c.date:intent.getStringExtra("watchDate"),intent.getBooleanExtra("directBooking",false));}
    void update(String text){if(foregroundStarted&&!finished){if(c!=null&&c.networkPaused&&!"booking".equals(c.phase)){life.removeCallbacks(wakeRenewal);if(lock!=null&&lock.isHeld())lock.release();}else if(lock!=null&&!lock.isHeld())renewWakeLock();}if(foregroundStarted&&!finished)try{getSystemService(NotificationManager.class).notify(100,notification(text));}catch(Exception ignored){}}
    void finishAfterAlerts(){if(!finished&&(c==null||!c.active()))finish();}
    void safeAlert(String msg){try{Alerts.send(this,false,msg);}catch(Exception ignored){}}
    void endWithGuide(String msg){if(c!=null&&c.active())WatchJournal.interrupted(this,msg);if(c!=null&&c.service==this)c.service=null;try{if(c!=null)c.stop("감시 중지: "+msg);}catch(Exception ignored){}finally{finish();}safeAlert(msg);}
    void finish(){if(finished)return;finished=true;life.removeCallbacksAndMessages(null);try{if(lock!=null&&lock.isHeld())lock.release();}catch(Exception ignored){}if(c!=null&&c.service==this)c.service=null;try{stopForeground(STOP_FOREGROUND_REMOVE);}catch(Exception ignored){}finally{foregroundStarted=false;stopSelf();}}
    @Override public void onTimeout(int startId,int fgsType){endWithGuide(BackgroundGuide.timeout());}
    @Override public void onDestroy(){try{if(c!=null&&c.service==this){c.service=null;if(c.active())try{WatchJournal.interrupted(this,"백그라운드 서비스가 예기치 않게 종료되었습니다.");c.stop("감시 중지: 백그라운드 서비스가 종료되었습니다. 앱에서 감시 상태와 코레일 예약 내역을 확인해주세요.");}catch(Exception ignored){}}}finally{finish();super.onDestroy();}}
    @Override public void onTrimMemory(int level){super.onTrimMemory(level);if(level>=10&&c!=null)c.trimTransientCaches();}
    @Override public void onLowMemory(){super.onLowMemory();if(c!=null)c.trimTransientCaches();}
    @Override public IBinder onBind(Intent i){return null;}
}
