package kr.personal.ktxmate;
/** Local eligibility only; never chooses an IP or changes device network settings. */
final class MobileNetworkPolicy {
 static final String NOTICE="네트워크 정책상 백그라운드 모니터링이 일시 중지됩니다";
 static final String HELP="연결이 끊겼거나 Wi-Fi·VPN을 사용 중이면 감시·코레일 통신을 하지 않습니다. 인터넷 연결이 확인된 모바일 데이터(LTE/5G 등)에서 이용해주세요.";
 static final long LOCAL_RECHECK_MILLIS=10000;
 static boolean allowed(boolean cellular,boolean wifi,boolean vpn,boolean internet,boolean validated){return cellular&&!wifi&&!vpn&&internet&&validated;}
}
