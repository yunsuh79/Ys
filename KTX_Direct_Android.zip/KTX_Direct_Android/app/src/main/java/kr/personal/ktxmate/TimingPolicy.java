package kr.personal.ktxmate;
import java.time.*;
import java.time.format.*;

/** Pure timing policy, independently testable without Android or network access. */
final class TimingPolicy {
 static final ZoneId KST=ZoneId.of("Asia/Seoul");
 static final DateTimeFormatter DATE=DateTimeFormatter.BASIC_ISO_DATE,TIME=DateTimeFormatter.ofPattern("HHmmss");
 static long departureMillis(String date,String time){return LocalDateTime.of(LocalDate.parse(date,DATE),LocalTime.parse(time,TIME)).atZone(KST).toInstant().toEpochMilli();}
 static String today(long now){return Instant.ofEpochMilli(now).atZone(KST).toLocalDate().format(DATE);}
 static String nowTime(long now){return Instant.ofEpochMilli(now).atZone(KST).format(TIME);}
 static String timeAfterDateChange(String previousDate,String nextDate,String previousTime){return previousDate.equals(nextDate)?previousTime:"000000";}
 static int firstSelectableHour(String date,long now){
  String current=today(now);if(date.compareTo(current)<0)throw new IllegalArgumentException("지난 날짜는 선택할 수 없습니다");
  return date.equals(current)?Integer.parseInt(nowTime(now).substring(0,2)):0;
 }
 static String pickerTime(String date,String requested,long now){
  LocalTime value=LocalTime.parse(requested,TIME);int first=firstSelectableHour(date,now);
  if(date.equals(today(now))&&value.getHour()<=first)return nowTime(now);
  return value.withMinute(0).withSecond(0).format(TIME);
 }
 static String searchTime(String date,String requested,long now){
  long chosen=departureMillis(date,requested);String today=today(now);
  if(date.compareTo(today)<0)throw new IllegalArgumentException("지난 날짜는 조회할 수 없습니다");
  if(date.equals(today)&&chosen<=now){ZonedDateTime next=Instant.ofEpochMilli(now).atZone(KST).plusSeconds(1);return next.toLocalDate().format(DATE).equals(date)?next.format(TIME):"235959";}
  return requested;
 }
 static boolean future(String date,String time,long now){try{return departureMillis(date,time)>now;}catch(Exception e){return false;}}
 static boolean night(long now){int hour=Instant.ofEpochMilli(now).atZone(KST).getHour();return hour>=23||hour<5;}
 static long delayMillis(long departure,long now){
  long left=departure-now;
  int min,max;
  if(night(now)){min=8000;max=10000;}
  else if(left<=6*3600000L){min=1000;max=3000;}
  else if(left<24*3600000L){min=3000;max=4000;}
  else{min=5000;max=6000;}
  return java.util.concurrent.ThreadLocalRandom.current().nextLong(min,max+1L);
 }
 static long retryAfterSeconds(String text,long now){
  if(text==null||text.trim().isEmpty())return 60;
  try{return Math.max(1,Long.parseLong(text.trim()));}catch(Exception ignored){}
  try{return Math.max(1,(ZonedDateTime.parse(text,DateTimeFormatter.RFC_1123_DATE_TIME).toInstant().toEpochMilli()-now+999)/1000);}catch(Exception ignored){return 60;}
 }
}
