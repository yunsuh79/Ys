package kr.personal.ktxmate;
import org.json.*;
import java.util.*;
import java.io.IOException;
/** Use the server's train/day-specific schedule; never infer stops from a generic line map. */
final class TrainStops {
 static final class Result {final String summary,path;final int count;Result(String summary,String path,int count){this.summary=summary;this.path=path;this.count=count;}}
 static String key(JSONObject row){StringBuilder b=new StringBuilder();for(String field:new String[]{"h_run_dt","h_dpt_dt","h_trn_no","h_dpt_rs_stn_cd","h_arv_rs_stn_cd","h_dpt_rs_stn_nm","h_arv_rs_stn_nm","h_dpt_stn_run_ordr","h_arv_stn_run_ordr","h_dpt_tm","h_arv_tm"})b.append(row.optString(field)).append('|');return b.toString();}
 static String scalar(JSONObject row,String key){Object raw=row.opt(key);return raw==null||raw==JSONObject.NULL?"":String.valueOf(raw).trim();}
 static String normalized(String value){return value.matches("[0-9]+")?value.replaceFirst("^0+(?!$)",""):value;}
 static boolean endpoint(JSONObject stop,JSONObject train,boolean departure){String prefix=departure?"h_dpt_":"h_arv_",code=scalar(train,prefix+"rs_stn_cd"),name=scalar(train,prefix+"rs_stn_nm");boolean station=!code.isEmpty()?normalized(code).equals(normalized(scalar(stop,"stopRsStnCd"))):!name.isEmpty()&&name.equals(scalar(stop,"stopStnNm"));if(!station)return false;String expected=scalar(train,prefix+"stn_run_ordr"),actual=scalar(stop,"runOrdr");return expected.isEmpty()||actual.isEmpty()||normalized(expected).equals(normalized(actual));}
 static Result segment(JSONObject response,JSONObject train)throws Exception{
  JSONArray list=response.optJSONArray("dlayList");if(list==null||list.length()==0||list.length()>512)throw new IOException("이 열차의 정차역 정보를 받지 못했습니다. 다시 확인해주세요.");
  List<JSONObject> stops=new ArrayList<>();boolean ordered=true;Set<Integer> orders=new HashSet<>();
  for(int i=0;i<list.length();i++){JSONObject stop=list.optJSONObject(i);if(stop==null)throw new IOException("정차역 응답 형식을 확인할 수 없습니다");stops.add(stop);String order=scalar(stop,"runOrdr");try{if(!orders.add(Integer.parseInt(order)))ordered=false;}catch(Exception e){ordered=false;}}
  if(ordered)Collections.sort(stops,(a,b)->Integer.compare(Integer.parseInt(scalar(a,"runOrdr")),Integer.parseInt(scalar(b,"runOrdr"))));
  int first=-1,last=-1,starts=0,ends=0;for(int i=0;i<stops.size();i++){if(endpoint(stops.get(i),train,true)){first=i;starts++;}if(endpoint(stops.get(i),train,false)){last=i;ends++;}}
  if(starts!=1||ends!=1||first>=last)throw new IOException("선택한 승차 구간의 정차역을 확인할 수 없습니다");
  String dep=scalar(stops.get(first),"dptTm"),arr=scalar(stops.get(last),"arvTm");if((dep.matches("[0-9]{6}")&&!dep.equals("000000")&&!scalar(train,"h_dpt_tm").isEmpty()&&!dep.equals(scalar(train,"h_dpt_tm")))||(arr.matches("[0-9]{6}")&&!arr.equals("000000")&&!scalar(train,"h_arv_tm").isEmpty()&&!arr.equals(scalar(train,"h_arv_tm"))))throw new IOException("정차역 시간표가 조회한 열차와 다릅니다. 열차를 다시 조회해주세요.");
  StringBuilder path=new StringBuilder();for(int i=first;i<=last;i++){String name=scalar(stops.get(i),"stopStnNm");if(name.isEmpty()||name.length()>100||path.length()+name.length()>4096)throw new IOException("정차역 이름이 누락되어 표시할 수 없습니다");if(path.length()>0)path.append(" → ");path.append(name);}
  int count=last-first-1;return new Result(count==0?"중간 정차역 없음":"경유 정차역 "+count+"곳",path.toString(),count);
 }
}
