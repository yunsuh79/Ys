package kr.personal.ktxmate;
import org.json.*;
import java.util.*;
/** Ordered local route favorites; old array-of-pairs preferences remain compatible. */
final class FavoriteRoutes {
 private final ArrayList<String[]> routes=new ArrayList<>();
 FavoriteRoutes(String json){try{JSONArray a=new JSONArray(json);for(int i=0;i<a.length()&&routes.size()<8;i++){JSONArray p=a.optJSONArray(i);if(p==null||p.length()!=2)continue;String f=p.optString(0).trim(),t=p.optString(1).trim();if(valid(f,t)&&index(f,t)<0)routes.add(new String[]{f,t});}}catch(Exception ignored){}}
 static boolean valid(String f,String t){return f!=null&&t!=null&&!f.trim().isEmpty()&&!t.trim().isEmpty()&&!f.trim().equals(t.trim());}
 int size(){return routes.size();}String from(int i){return routes.get(i)[0];}String to(int i){return routes.get(i)[1];}
 int index(String f,String t){for(int i=0;i<routes.size();i++)if(routes.get(i)[0].equals(f.trim())&&routes.get(i)[1].equals(t.trim()))return i;return -1;}
 boolean toggle(String f,String t){if(!valid(f,t))throw new IllegalArgumentException("서로 다른 출발역과 도착역을 입력해주세요.");f=f.trim();t=t.trim();int i=index(f,t);if(i>=0){routes.remove(i);return false;}if(routes.size()>=8)throw new IllegalStateException("즐겨찾기는 최대 8개입니다. 관리에서 기존 구간을 삭제해주세요.");routes.add(new String[]{f,t});return true;}
 void remove(int i){routes.remove(i);}
 void move(int i,int delta){int target=i+delta;if(i<0||i>=size()||target<0||target>=size())return;Collections.swap(routes,i,target);}
 String json(){JSONArray a=new JSONArray();for(String[] p:routes)a.put(new JSONArray().put(p[0]).put(p[1]));return a.toString();}
}
