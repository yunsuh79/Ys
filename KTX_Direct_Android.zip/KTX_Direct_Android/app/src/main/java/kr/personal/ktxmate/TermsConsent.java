package kr.personal.ktxmate;
import android.content.Context;
final class TermsConsent {
 static final int VERSION=10;
 static boolean accepted(Context c){return c.getSharedPreferences("terms",0).getInt("accepted",0)==VERSION;}
 static boolean accept(Context c){return c.getSharedPreferences("terms",0).edit().putInt("accepted",VERSION).putInt("termsVersion",VERSION).putInt("privacyVersion",VERSION).putString("acceptedAt",String.valueOf(System.currentTimeMillis())).commit();}
 static final String TEXT=LegalDocuments.TERMS+"\n\n────────────────\n\n"+LegalDocuments.PRIVACY;
}
