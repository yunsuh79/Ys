package kr.personal.ktxmate;
final class RecoveryGuide {
 static String reason(Exception e){if(e instanceof KorailApi.LocalSessionExpired)return "보안 정책에 따라 로그인 세션을 만료했습니다. 로그인 후 24시간 또는 감시 없이 백그라운드에서 30분 이상 지난 경우입니다.";if(e instanceof KorailApi.SessionExpired)return "코레일 로그인 세션이 만료되었습니다 (P058).";if(e instanceof KorailApi.RateLimited)return "코레일 서버가 요청을 일시 제한했습니다 (429). 최소 "+Math.max(1,((KorailApi.RateLimited)e).seconds)+"초 동안 추가 요청을 보내지 않습니다.";return "보안 인증 또는 접근 상태를 확인해야 합니다.";}
 static String message(Exception e,boolean pending){return reason(e)+"\n\n자동 조회·예약·재로그인을 중지했습니다.\n\n1. [코레일 앱에서 확인]을 눌러 공식 앱의 로그인 상태와 인증 안내를 먼저 확인해주세요."+(e instanceof KorailApi.RateLimited?" 서버가 안내한 대기 시간이 지나도 자동 재개하지 않습니다.":"")+"\n\n2. 예약을 시도했다면 공식 예약 내역과 결제기한도 확인해주세요.\n\n3. 자리봄으로 돌아와 직접 로그인한 뒤 조회·감시를 다시 시작해주세요. 공식 앱의 로그인이 자동 반영되지는 않으며, 자리봄의 세션이 자동 복구되지는 않습니다."+(pending?"\n\n예약 요청 결과가 불분명합니다. 공식 예약 내역 확인 전에는 중복 예약 방지 잠금을 해제하지 마세요.":"");}
}
