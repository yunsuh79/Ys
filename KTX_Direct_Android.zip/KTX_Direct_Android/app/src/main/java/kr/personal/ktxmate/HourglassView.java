package kr.personal.ktxmate;
import android.content.Context;
import android.graphics.*;
import android.os.SystemClock;
import android.view.View;
/** Lightweight local animation; no task or network activity. */
final class HourglassView extends View {
 final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
 HourglassView(Context context){super(context);setContentDescription("모래시계 · 열차 조회 중");setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO);}
 @Override protected void onDraw(Canvas canvas){super.onDraw(canvas);int save=canvas.save();float size=Math.min(getWidth(),getHeight());canvas.translate((getWidth()-size)/2,(getHeight()-size)/2);canvas.scale(size/100,size/100);float phase=(SystemClock.uptimeMillis()%2400)/2400f;float progress=Math.min(1,phase/.82f);if(phase>.82f)canvas.rotate(180*(phase-.82f)/.18f,50,50);
  paint.setStyle(Paint.Style.FILL);paint.setColor(0xffedf6e8);Path glass=new Path();glass.moveTo(26,17);glass.lineTo(74,17);glass.lineTo(70,33);glass.lineTo(55,49);glass.lineTo(55,51);glass.lineTo(70,67);glass.lineTo(74,83);glass.lineTo(26,83);glass.lineTo(30,67);glass.lineTo(45,51);glass.lineTo(45,49);glass.lineTo(30,33);glass.close();canvas.drawPath(glass,paint);
  int clip=canvas.save();canvas.clipPath(glass);paint.setColor(0xffe6aa42);canvas.drawRect(25,22+24*progress,75,46,paint);Path sand=new Path();sand.moveTo(50,78-20*progress);sand.lineTo(28,80);sand.lineTo(72,80);sand.close();canvas.drawPath(sand,paint);paint.setStrokeWidth(2);canvas.drawLine(50,49,50,76-18*progress,paint);canvas.restoreToCount(clip);
  paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(3);paint.setStrokeJoin(Paint.Join.ROUND);paint.setColor(0xff20734f);canvas.drawPath(glass,paint);paint.setStrokeCap(Paint.Cap.ROUND);paint.setStrokeWidth(6);canvas.drawLine(22,14,78,14,paint);canvas.drawLine(22,86,78,86,paint);paint.setStyle(Paint.Style.FILL);canvas.restoreToCount(save);if(isShown())postInvalidateOnAnimation();
 }
}
