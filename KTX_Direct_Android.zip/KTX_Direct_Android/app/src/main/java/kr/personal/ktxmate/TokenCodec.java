// Derived from korail-mobile-api 2.6.2, Copyright (c) 2026 yakisoba0728, Apache-2.0.
package kr.personal.ktxmate;
import java.net.URLEncoder;
import java.math.BigInteger;
import java.util.*;

class TokenCodec {
    static final String TABLE="3FE9jgRD4KdCyuawklqGJYmvfMn15P7US8XbxeLQtWT6OicBAopINs2Vh0HZrz",AS="[38ff229cb34c7dda8e28220a2d750cce]";
    
    static String enc(String s){try{return URLEncoder.encode(s,"UTF-8").replace("~","%7E");}catch(Exception e){throw new IllegalArgumentException(e);}}
    
    static String encode(String s,String table){
        ArrayList<Integer> bytes=new ArrayList<>();
        for(char c:s.toCharArray()){
            int x=c;
            if(x<128)bytes.add(x);
            else if(x<2048){bytes.add(128|((x>>7)&15));bytes.add(x&127);}
            else if((63488&x)!=55296){bytes.add(((x>>14)&15)|144);bytes.add((x>>7)&127);bytes.add(x&127);}
        }
        StringBuilder out=new StringBuilder();
        for(int i=0;i<bytes.size();){
            int n=Math.min(2,bytes.size()-i),v=0;
            for(int j=0;j<n;j++)v=v*161+bytes.get(i++);
            char[] chars=new char[n+1];
            for(int k=n;k>=0;k--){chars[k]=table.charAt(v%30);v/=30;}
            out.append(chars);
        }
        return out.toString();
    }
    
    static String permute(String key){
        BigInteger v=BigInteger.ZERO;
        for(char c:key.toCharArray()){
            int bit=32768;
            for(int j=0;j<16;j++){if((bit&c)!=0)break;bit>>=1;}
            v=v.multiply(BigInteger.valueOf(bit<<1)).add(BigInteger.valueOf(c));
        }
        StringBuilder b=new StringBuilder();
        for(int i=0;i<30;i++){
            BigInteger[] qr=v.divideAndRemainder(BigInteger.valueOf(30-i));
            int n=qr[1].intValue();
            for(int j=0;j<TABLE.length();j++){
                char c=TABLE.charAt(j);
                if(b.indexOf(String.valueOf(c))<0&&n--==0){b.append(c);break;}
            }
            v=qr[0];
        }
        return b.toString();
    }
    
    static String token(String id,String os,String model,long start,long now,String random,List<Long> intervals){
        LinkedHashMap<String,String> f=new LinkedHashMap<>();
        f.put("ai","com.korail.talk");
        f.put("di",id);
        f.put("as",AS);
        f.put("su","false");
        f.put("dbg","false");
        f.put("emu","false");
        f.put("hk","false");
        f.put("it",String.valueOf(start));
        f.put("ts",String.valueOf(now));
        StringBuilder body=new StringBuilder();
        for(Map.Entry<String,String> e:f.entrySet()){
            if(body.length()>0)body.append('&');
            body.append(enc(e.getKey())).append('=').append(enc(e.getValue()));
        }
        for(long n:intervals)body.append("&rt=").append(n);
        body.append("&os=").append(enc(os)).append("&dm=").append(enc(model)).append("&st=Android&sv=v1.0.3");
        String key="v1.0.3+"+random+"+"+now;
        String ekey=encode(key,TABLE);
        
        // 최신 2.6.2 규격의 핵심인 "2!" 프리픽스 적용
        return "2!b"+TABLE.charAt(2)+TABLE.charAt(37)+TABLE.charAt(2)+TABLE.charAt(29)+TABLE.charAt(ekey.length())+ekey+encode(body.toString(),permute(key));
    }
}