package kr.personal.ktxmate;
import javax.crypto.*;
import javax.crypto.spec.GCMParameterSpec;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
/** Authenticated local encryption. Keys are supplied by Android Keystore in production. */
final class SecretBox {
 private static final byte[] AAD="Jaribom.remember.v1".getBytes(StandardCharsets.UTF_8);
 static String seal(javax.crypto.SecretKey key,String text)throws Exception{if(text==null||text.length()>16384)throw new IllegalArgumentException("Credential size invalid");byte[] plain=text.getBytes(StandardCharsets.UTF_8);try{Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.ENCRYPT_MODE,key);if(cipher.getIV().length!=12)throw new IllegalArgumentException("Invalid nonce");cipher.updateAAD(AAD);return Base64.getEncoder().encodeToString(cipher.getIV())+":"+Base64.getEncoder().encodeToString(cipher.doFinal(plain));}finally{java.util.Arrays.fill(plain,(byte)0);}}

 static String open(javax.crypto.SecretKey key,String blob)throws Exception{if(blob==null||blob.length()>65536)throw new IllegalArgumentException("Invalid encrypted credential");String[] parts=blob.split(":",-1);if(parts.length!=2)throw new IllegalArgumentException("Invalid encrypted credential");byte[] iv=Base64.getDecoder().decode(parts[0]);if(iv.length!=12)throw new IllegalArgumentException("Invalid nonce");Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.DECRYPT_MODE,key,new GCMParameterSpec(128,iv));cipher.updateAAD(AAD);byte[] ciphertext=Base64.getDecoder().decode(parts[1]);if(ciphertext.length<16)throw new IllegalArgumentException("Missing authentication tag");byte[] plain=cipher.doFinal(ciphertext);try{return new String(plain,StandardCharsets.UTF_8);}finally{java.util.Arrays.fill(plain,(byte)0);}}
}
