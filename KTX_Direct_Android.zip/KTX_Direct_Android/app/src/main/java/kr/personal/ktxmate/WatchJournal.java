package kr.personal.ktxmate;
import android.content.*;
/** Small local lifecycle marker, never a replayable booking queue. */
final class WatchJournal {
 static SharedPreferences prefs(Context c){return c.getSharedPreferences("monitor_lifecycle",0);}
 static void running(Context c,int count){prefs(c).edit().putBoolean("active",count>0).remove("notice").putInt("count",count).putString("lastSeen",String.valueOf(System.currentTimeMillis())).commit();}
 static void stopped(Context c){prefs(c).edit().putBoolean("active",false).putInt("count",0).commit();}
 static String recover(Context c){SharedPreferences p=prefs(c);String notice=p.getString("notice","");if(p.getBoolean("active",false)){notice="이전 실행에서 감시가 정상 종료되지 않았습니다. 시스템의 프로세스 회수·앱 종료·재부팅 등이 원인일 수 있습니다.\n\n마지막 확인: "+lastSeen(p)+"\n\n감시와 예약을 자동으로 다시 실행하지 않았습니다. 코레일 앱에서 예약 내역과 결제기한을 확인한 뒤 필요한 감시를 직접 시작해주세요.";p.edit().putBoolean("active",false).putString("notice",notice).commit();}return notice;}
 static String lastSeen(SharedPreferences p){try{return java.time.Instant.ofEpochMilli(Long.parseLong(p.getString("lastSeen",""))).atZone(TimingPolicy.KST).format(java.time.format.DateTimeFormatter.ofPattern("M.d HH:mm:ss"));}catch(Exception e){return "미확인";}}
 static void interrupted(Context c,String reason){prefs(c).edit().putBoolean("active",false).putString("notice",reason+"\n\n감시·예약을 자동 재실행하지 않았습니다. 코레일 앱에서 예약 내역을 먼저 확인한 뒤 필요한 감시를 직접 시작해주세요.").commit();}
 static void acknowledge(Context c){prefs(c).edit().remove("notice").commit();}
}
