package kr.personal.ktxmate;
import android.content.Context;
import android.net.*;
import javax.net.ssl.HttpsURLConnection;
import java.net.URL;
import java.net.URLConnection;
/** Reads the default network; opens each connection on that checked cellular network only. */
final class MobileNetwork implements KorailApi.RequestNetwork {
 private final ConnectivityManager manager;private ConnectivityManager.NetworkCallback callback;private Network lastNetwork,socketNetwork;private HttpsURLConnection socket;private long epoch;
 MobileNetwork(Context context){ConnectivityManager found=null;try{found=context.getSystemService(ConnectivityManager.class);}catch(RuntimeException ignored){}manager=found;lastNetwork=eligible();}
 private Network eligible(){try{if(manager==null)return null;Network network=manager.getActiveNetwork();if(network==null)return null;NetworkCapabilities caps=manager.getNetworkCapabilities(network);return caps!=null&&MobileNetworkPolicy.allowed(caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR),caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI),caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN),caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET),caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED))?network:null;}catch(RuntimeException ignored){return null;}}
 public boolean ready(){return eligible()!=null;}
 boolean wifi(){try{if(manager==null)return false;Network n=manager.getActiveNetwork();NetworkCapabilities caps=n==null?null:manager.getNetworkCapabilities(n);return caps!=null&&caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI);}catch(RuntimeException e){return false;}}
 synchronized void refresh(){Network current=eligible();if(!java.util.Objects.equals(current,lastNetwork)){lastNetwork=current;epoch++;}if(socket!=null&&!java.util.Objects.equals(current,socketNetwork)){HttpsURLConnection old=socket;socket=null;socketNetwork=null;try{old.disconnect();}catch(RuntimeException ignored){}}}
 public synchronized long generation(){return epoch;}
 public synchronized void released(HttpsURLConnection c){if(socket==c){socket=null;socketNetwork=null;}}
 public HttpsURLConnection open(URL url)throws Exception{refresh();Network network=eligible();if(network==null)throw new KorailApi.NetworkPaused();URLConnection connection;try{connection=network.openConnection(url);}catch(java.io.IOException e){refresh();if(!ready())throw new KorailApi.NetworkPaused();throw e;}if(!(connection instanceof HttpsURLConnection))throw new java.io.IOException("HTTPS 연결이 필요합니다");HttpsURLConnection https=(HttpsURLConnection)connection;synchronized(this){socket=https;socketNetwork=network;refresh();if(socket!=https)throw new KorailApi.NetworkPaused();}return https;}

 synchronized void start(Runnable changed){if(manager==null||callback!=null)return;ConnectivityManager.NetworkCallback listener=new ConnectivityManager.NetworkCallback(){@Override public void onAvailable(Network network){refresh();changed.run();}@Override public void onCapabilitiesChanged(Network network,NetworkCapabilities caps){refresh();changed.run();}@Override public void onLost(Network network){refresh();changed.run();}};try{manager.registerDefaultNetworkCallback(listener);callback=listener;}catch(RuntimeException ignored){callback=null;}}
}
