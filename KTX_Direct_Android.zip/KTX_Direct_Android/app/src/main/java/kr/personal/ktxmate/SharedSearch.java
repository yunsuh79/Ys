package kr.personal.ktxmate;
import org.json.*;

/** One short-lived immutable search page, scoped to route/date and controller session. */
final class SharedSearch {
 private String from="",to="",date="",json="";private long until,received;
 synchronized void clear(){json="";until=received=0;}
 synchronized void put(String f,String t,String d,JSONArray rows,long wall,long expires){from=f;to=t;date=d;json=rows.toString();received=wall;until=expires;}
 synchronized JSONArray forWatch(String f,String t,String d,JSONObject target,long checked,long elapsed)throws Exception{
  if(json.isEmpty()||elapsed>=until||checked>=received||!from.equals(f)||!to.equals(t)||!date.equals(d))return null;
  JSONArray rows=new JSONArray(json);int matches=0;
  for(int i=0;i<rows.length();i++)if(NativeController.sameTrain(target,rows.getJSONObject(i)))matches++;
  return matches==1?rows:null;
 }
}
