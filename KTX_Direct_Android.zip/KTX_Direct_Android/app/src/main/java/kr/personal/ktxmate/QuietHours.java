package kr.personal.ktxmate;
final class QuietHours {
 static boolean within(boolean enabled,int start,int end,int minute){if(!enabled)return false;if(start<0||start>=1440||end<0||end>=1440||minute<0||minute>=1440)return false;if(start==end)return true;return start<end?minute>=start&&minute<end:minute>=start||minute<end;}
}
