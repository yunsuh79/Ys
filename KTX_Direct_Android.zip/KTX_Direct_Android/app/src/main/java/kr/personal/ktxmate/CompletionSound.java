package kr.personal.ktxmate;

import android.content.Context;
import android.media.*;
import android.os.*;

/** Finite in-app completion sound. Does not change the phone's volume or DND settings. */
final class CompletionSound {
 private static MediaPlayer player;
 private static final Handler main=new Handler(Looper.getMainLooper());
 private static Runnable timeout;
 static String lastStatus="아직 재생하지 않았습니다";
 static boolean enabled(Context c){return c.getSharedPreferences("settings",0).getBoolean("completionSound",true);}
 static void enabled(Context c,boolean enabled){c.getSharedPreferences("settings",0).edit().putBoolean("completionSound",enabled).apply();if(!enabled)stop();}
 static void release(MediaPlayer expected){if(player!=expected)return;if(timeout!=null){main.removeCallbacks(timeout);timeout=null;}player=null;try{expected.release();}catch(Exception ignored){}}
 static void stop(){if(player!=null)release(player);lastStatus="소리 재생을 중지했습니다";}
 static String play(Context c){
  if(AlertPreferences.quiet(c)){lastStatus="무음 시간대 · 소리 생략";return lastStatus;}
  if(!enabled(c)){lastStatus="앱의 완료음이 꺼져 있습니다";return lastStatus;}
  if(player!=null)release(player);
  try{
   AudioAttributes attrs=new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build();
   final MediaPlayer p=MediaPlayer.create(c.getApplicationContext(),R.raw.reservation_complete,attrs,0);
   if(p==null){lastStatus="소리 파일을 열지 못했습니다";return lastStatus;}
   player=p;p.setLooping(false);p.setVolume(1f,1f);
   p.setOnCompletionListener(done->{lastStatus="완료음 재생이 끝났습니다";release(done);});
   p.setOnErrorListener((failed,what,extra)->{lastStatus="소리 재생 오류 ("+what+", "+extra+")";release(failed);return true;});
   p.start();lastStatus="완료음 재생을 요청했습니다 · 약 1초";
   timeout=()->{if(player==p){lastStatus="소리 재생 시간 제한으로 종료했습니다";release(p);}};main.postDelayed(timeout,1300);
  }catch(Exception e){if(player!=null)release(player);lastStatus="소리 재생 실패: "+e.getClass().getSimpleName();}
  return lastStatus;
 }
 static String volumes(Context c){AudioManager a=c.getSystemService(AudioManager.class);return "미디어 음량 "+a.getStreamVolume(AudioManager.STREAM_MUSIC)+" / "+a.getStreamMaxVolume(AudioManager.STREAM_MUSIC)+"   ·   알림 음량 "+a.getStreamVolume(AudioManager.STREAM_NOTIFICATION)+" / "+a.getStreamMaxVolume(AudioManager.STREAM_NOTIFICATION);}
}
