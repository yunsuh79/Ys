package kr.personal.ktxmate;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;
/** Offline issuer signature and installation binding validation. No shared secret. */
final class LicenseVerifier {
 static final String PACKAGE="kr.personal.ktxmate";
 static final String ISSUER="MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEoAsdMOHkeb8q7BhsK+eZBznfapV64W7GtGZ6nmA2aneXwGFwKhEi6EkFHZipcSO1nGE/vkZ6vn5zRN2eaUc03A==";
 static final long MAX_TERM=366L*86400;
 static long verify(String code,String binding,long now)throws Exception{return verify(code,binding,now,ISSUER);}
 static long verify(String code,String binding,long now,String issuer)throws Exception{
  if(code==null||code.length()>2048||!binding.matches("[0-9a-f]{64}"))throw new GeneralSecurityException("invalid license");
  String[] parts=code.trim().split("\\.",-1);if(parts.length!=2)throw new GeneralSecurityException("invalid format");
  byte[] payload=Base64.getUrlDecoder().decode(parts[0]),sig=Base64.getUrlDecoder().decode(parts[1]);
  if(payload.length>512||sig.length>80||sig.length<8)throw new GeneralSecurityException("invalid size");
  PublicKey key=KeyFactory.getInstance("EC").generatePublic(new X509EncodedKeySpec(Base64.getDecoder().decode(issuer)));
  Signature check=Signature.getInstance("SHA256withECDSA");check.initVerify(key);check.update(payload);
  if(!check.verify(sig))throw new GeneralSecurityException("invalid signature");
  String[] fields=new String(payload,StandardCharsets.UTF_8).split("\n",-1);
  if(fields.length!=5||!"JB1".equals(fields[0])||!PACKAGE.equals(fields[1])||!binding.equals(fields[2]))throw new GeneralSecurityException("wrong installation");
  if(!fields[3].matches("[0-9]{1,12}")||!fields[4].matches("[0-9]{1,12}"))throw new GeneralSecurityException("invalid time");
  long issued=Long.parseLong(fields[3]),expires=Long.parseLong(fields[4]);
  // All valid issuer-signed enrollments are permanent, including legacy dated codes.
  // Legacy dates are validated as data only; device clock or old expiry cannot revoke enrollment.
  if(issued<=0||(expires!=0&&(expires<=issued||expires-issued>MAX_TERM)))throw new GeneralSecurityException("invalid license dates");
  return 0;
 }
 static String hash(byte[] bytes)throws GeneralSecurityException{byte[] digest=MessageDigest.getInstance("SHA-256").digest(bytes);StringBuilder out=new StringBuilder();for(byte b:digest)out.append(String.format(java.util.Locale.ROOT,"%02x",b&255));return out.toString();}
}
