package kr.personal.ktxmate;
import android.content.Context;
import android.view.*;
import android.widget.ScrollView;
/** Vertical pull at the top only; ordinary scrolling and horizontal date swipes stay separate. */
final class PullRefreshScrollView extends ScrollView {
 interface Listener {boolean allowed();void pulling(float progress);void released(boolean refresh);}
 Listener listener;float startX,startY;boolean eligible,pulling;final float threshold,slop;
 PullRefreshScrollView(Context context){super(context);threshold=72*getResources().getDisplayMetrics().density;slop=ViewConfiguration.get(context).getScaledTouchSlop();}
 @Override public boolean onInterceptTouchEvent(MotionEvent e){
  if(e.getActionMasked()==MotionEvent.ACTION_DOWN){startX=e.getRawX();startY=e.getRawY();eligible=getScrollY()==0&&listener!=null&&listener.allowed();pulling=false;}
  if(e.getActionMasked()==MotionEvent.ACTION_MOVE&&eligible&&listener.allowed()){
   float dx=Math.abs(e.getRawX()-startX),dy=e.getRawY()-startY;
   if(e.getPointerCount()==1&&dy>slop&&dy>dx*1.4f&&getScrollY()==0){pulling=true;return true;}
  }
  return super.onInterceptTouchEvent(e);
 }
 @Override public boolean onTouchEvent(MotionEvent e){if(pulling){
  float progress=Math.max(0,(e.getRawY()-startY)/threshold);
  if(e.getActionMasked()==MotionEvent.ACTION_MOVE){listener.pulling(progress);return true;}
  if(e.getActionMasked()==MotionEvent.ACTION_UP||e.getActionMasked()==MotionEvent.ACTION_CANCEL){boolean refresh=e.getActionMasked()==MotionEvent.ACTION_UP&&progress>=1&&e.getPointerCount()==1&&listener.allowed();pulling=false;eligible=false;listener.released(refresh);return true;}
  return true;
 }return super.onTouchEvent(e);}
}
