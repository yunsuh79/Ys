package kr.personal.ktxmate;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.*;
import android.os.Build;
import android.security.keystore.*;
import java.security.*;
import java.security.spec.ECGenParameterSpec;
/** Installation key stays in Android Keystore. License is public signed authorization. */
final class DeviceLicense {
 static final String ALIAS="jaribom.install.license.v1",SIGNER="c4a48d092d1d075e07ef2eb9242460d6682f603ba3485ab192f980def3363e4f";
 static final String NOTICE="사용 권한을 확인할 수 없습니다. 등록코드를 발급자에게 전달한 뒤 인증코드를 한 번 입력해주세요. 인증 후 만료 없이 사용할 수 있습니다.";
 static SharedPreferences prefs(Context c){return c.getSharedPreferences("installation_license",0);}
 static void trustedBuild(Context c)throws Exception{
  if(!LicenseVerifier.PACKAGE.equals(c.getPackageName()))throw new GeneralSecurityException();
  PackageInfo info=c.getPackageManager().getPackageInfo(c.getPackageName(),Build.VERSION.SDK_INT>=28?PackageManager.GET_SIGNING_CERTIFICATES:PackageManager.GET_SIGNATURES);
  android.content.pm.Signature[] certs=Build.VERSION.SDK_INT>=28?info.signingInfo.getApkContentsSigners():info.signatures;
  if(certs==null||certs.length!=1||!SIGNER.equals(LicenseVerifier.hash(certs[0].toByteArray())))throw new GeneralSecurityException();
 }
 static KeyStore keys()throws Exception{KeyStore k=KeyStore.getInstance("AndroidKeyStore");k.load(null);return k;}
 static String registration(Context c)throws Exception{
  trustedBuild(c);KeyStore k=keys();
  if(!k.containsAlias(ALIAS)){
   // Lost app data means a new registration; a surviving key is harmless but never exported.
   KeyPairGenerator gen=KeyPairGenerator.getInstance(KeyProperties.KEY_ALGORITHM_EC,"AndroidKeyStore");
   gen.initialize(new KeyGenParameterSpec.Builder(ALIAS,KeyProperties.PURPOSE_SIGN|KeyProperties.PURPOSE_VERIFY).setAlgorithmParameterSpec(new ECGenParameterSpec("secp256r1")).setDigests(KeyProperties.DIGEST_SHA256).build());gen.generateKeyPair();k=keys();
  }
  return binding(k);
 }
 static String binding(KeyStore k)throws Exception{
  PublicKey pub=k.getCertificate(ALIAS).getPublicKey();byte[] nonce=new byte[32];new SecureRandom().nextBytes(nonce);
  java.security.Signature proof=java.security.Signature.getInstance("SHA256withECDSA");proof.initSign((PrivateKey)k.getKey(ALIAS,null));proof.update(nonce);byte[] signed=proof.sign();
  proof.initVerify(pub);proof.update(nonce);if(!proof.verify(signed))throw new GeneralSecurityException();return LicenseVerifier.hash(pub.getEncoded());
 }
 static long expiry(Context c)throws Exception{
  trustedBuild(c);KeyStore k=keys();if(!k.containsAlias(ALIAS))throw new GeneralSecurityException();
  LicenseVerifier.verify(prefs(c).getString("code",""),binding(k),System.currentTimeMillis()/1000);
  if(prefs(c).contains("lastSeen"))prefs(c).edit().remove("lastSeen").apply();
  return 0; // Permanent enrollment; recheck signature and installation key, never a clock TTL.
 }
 static boolean allowed(Context c){try{expiry(c);return true;}catch(Exception e){return false;}}
 static void require(Context c)throws Exception{if(!allowed(c))throw new AccessDenied();}
 static final class AccessDenied extends Exception{AccessDenied(){super(NOTICE);}}
 static void activate(Context c,String code)throws Exception{
  long now=System.currentTimeMillis()/1000;LicenseVerifier.verify(code.trim(),registration(c),now);
  if(!prefs(c).edit().putString("code",code.trim()).remove("lastSeen").commit())throw new GeneralSecurityException("save failed");
 }
}
