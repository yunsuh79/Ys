from pathlib import Path
import subprocess,os
p=Path(__file__).resolve().parents[1];out=p/'build/license-tests';out.mkdir(parents=True,exist_ok=True)
subprocess.run(['java','com.sun.tools.javac.Main','--release','8','-d',str(out),str(p/'app/src/main/java/kr/personal/ktxmate/LicenseVerifier.java'),str(p/'tests/LicenseTests.java')],check=True)
subprocess.run(['java','-cp',str(out),'kr.personal.ktxmate.LicenseTests'],check=True)
