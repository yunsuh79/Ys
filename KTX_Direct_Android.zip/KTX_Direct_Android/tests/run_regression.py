from pathlib import Path
import os,subprocess,concurrent.futures
p=Path(__file__).resolve().parents[1];json_jar=str(Path(os.environ.get('JSON_JAR',p.parent/'android-tools/research/json.jar')));s=p/'app/src/main/java/kr/personal/ktxmate';out=p/'build/v130-tests';out.mkdir(parents=True,exist_ok=True)
names=['ControllerSoldOutTests','AutoLoginTests','SessionSecurityTests','SecretBoxTests','DirectBookingTests','BrowseDuringWatchTests','MultiWatchTests','TimingTests','PickerTimeTests','StationUsageTests','SearchStateTests','AccessRecoveryTests','QuietHoursTests','ConsentTests','NightPollingTests','RetiredIntegrationTests','TrainStopsTests','StopControllerTests','WatchStartNoticeTests','SearchTransitionTests','MobileNetworkPolicyTests','NetworkPauseTests','PollingProtectionTests','RecoveryGuideTests','NetworkRecoveryTests','HistoryTests','RobustnessTests','AuthHardeningTests','LicenseGateTests']
prod=['TokenCodec','TimingPolicy','KorailApi','ReservationLedger','SeatAvailability','TrainPresentation','NativeController','PollingPolicy','NetworkRecovery','SharedSearch','RecoveryGuide','WatchJournal','SessionLifetime','DeviceSecurity','SecretBox','StationUsage','MajorStations','FavoriteRoutes','QuietHours','AlertPreferences','TermsConsent','LegalDocuments','RetiredIntegration','TrainStops','MobileNetworkPolicy']
files=list((p/'tests/controller_stubs').rglob('*.java'))+[s/(n+'.java') for n in prod]+[p/'tests'/(n+'.java') for n in names]
subprocess.run(['java','com.sun.tools.javac.Main','--release','8','-encoding','UTF-8','-cp',json_jar,'-d',str(out)]+[str(x) for x in files],check=True)
def run(n):
 r=subprocess.run(['java','-cp',str(out)+os.pathsep+json_jar,'kr.personal.ktxmate.'+n],capture_output=True,text=True,timeout=110)
 if r.returncode:return 'FAILED '+n+'\n'+r.stdout+r.stderr
 return n+': '+r.stdout.strip().splitlines()[-1]
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:
 results=list(ex.map(run,names))
 for result in results:print(result,flush=True)
 if any(r.startswith('FAILED') for r in results):raise SystemExit(1)
