package kr.personal.ktxmate;
public class QuietHoursTests {
 static int count;static void check(boolean ok,String label){if(!ok)throw new AssertionError(label);count++;System.out.println("PASS "+label);}
 public static void main(String[] args){
  check(!QuietHours.within(false,1380,420,0),"disabled schedule never mutes");
  check(QuietHours.within(true,1380,420,1380),"overnight start included");check(QuietHours.within(true,1380,420,0),"midnight is quiet");check(QuietHours.within(true,1380,420,419),"overnight before end included");check(!QuietHours.within(true,1380,420,420),"end excluded");check(!QuietHours.within(true,1380,420,1379),"before start not muted");
  check(QuietHours.within(true,540,1080,540)&&QuietHours.within(true,540,1080,1079),"daytime interval supported");check(!QuietHours.within(true,540,1080,1080),"daytime end excluded");check(QuietHours.within(true,0,0,700),"equal times mean all-day silence");check(!QuietHours.within(true,-1,400,30),"invalid preference fails safely");check(!QuietHours.within(true,0,1400,1440),"invalid minute rejected");
  System.out.println(count+" quiet-hour checks passed");
 }
}
