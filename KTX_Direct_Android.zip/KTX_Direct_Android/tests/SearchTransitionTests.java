package kr.personal.ktxmate;
import android.content.Context;
import org.json.*;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.*;
public class SearchTransitionTests {
 static int count;static void check(boolean ok,String label){if(!ok)throw new AssertionError(label);count++;System.out.println("PASS "+label);}
 static class API extends KorailApi {
  volatile String response="",failure="";volatile CountDownLatch entered,release;
  final List<Map<String,String>> sent=new CopyOnWriteArrayList<>();
  API(){super("test","16","Test");}
  @Override JSONObject queued(String action,Operation op)throws Exception{return op.run();}
  @Override String post(String url,LinkedHashMap<String,String> form,boolean protect)throws Exception{
   if(!url.endsWith("/classes/com.korail.mobile.seatMovie.ScheduleView"))throw new AssertionError("unexpected endpoint");sent.add(new LinkedHashMap<>(form));if(entered!=null)entered.countDown();if(release!=null&&!release.await(3,TimeUnit.SECONDS))throw new IOException("test gate timeout");if(!failure.isEmpty())throw new IOException(failure);return response;
  }
 }
 static String empty()throws Exception{return new JSONObject().put("strResult","FAIL").put("h_msg_cd","WRD000061").put("h_msg_txt","직통열차는 없지만, 환승으로 조회 가능합니다.").toString();}
 static String rows()throws Exception{return new JSONObject().put("strResult","SUCC").put("trn_infos",new JSONArray().put(ControllerSoldOutTests.target())).toString();}
 static void settle(NativeController c)throws Exception{long end=System.nanoTime()+TimeUnit.SECONDS.toNanos(4);while(c.busy&&System.nanoTime()<end)Thread.sleep(5);if(c.busy)throw new AssertionError("request did not finish");}
 public static void main(String[] args)throws Exception{
  API api=new API();Context ctx=new Context();NativeController c=ControllerSoldOutTests.controller(ctx,api);
  try{
   api.response=rows();c.search("서울","부산","20991020","000000");settle(c);check(c.trains.length()==1&&c.queryOutcome.equals("success"),"first successful search publishes rows");
   c.invalidateSearch();check(c.trains.length()==0&&c.selected==null&&c.queryOutcome.equals("draft"),"swap/date edit discards previous rows and selected booking target");
   api.response=empty();api.entered=new CountDownLatch(1);api.release=new CountDownLatch(1);c.search("부산","서울","20991021","000000");check(api.entered.await(3,TimeUnit.SECONDS),"reversed route reaches transport");check(c.trains.length()==0&&c.from.equals("부산")&&c.to.equals("서울")&&c.date.equals("20991021"),"new request immediately owns its route/date with no old rows");api.release.countDown();settle(c);
   check(c.queryOutcome.equals("empty")&&c.trains.length()==0&&!c.lastStatus.startsWith("실패:"),"WRD000061 is successful empty result rather than request failure");check(c.lastStatus.equals("조회된 열차가 없습니다"),"empty state has explicit user-facing message");
   Map<String,String> reversed=api.sent.get(api.sent.size()-1);check(reversed.get("txtGoStart").equals("부산")&&reversed.get("txtGoEnd").equals("서울"),"swap sends actual reversed endpoints");check(ctx.getSharedPreferences("last_query",0).getString("from","").equals("부산"),"successful empty query remembers last submitted route");
   long now=System.currentTimeMillis();String today=TimingPolicy.today(now),time=TimingPolicy.nowTime(now);api.entered=null;api.release=null;c.search("동탄","김천구미",today,time);settle(c);
   Map<String,String> current=api.sent.get(api.sent.size()-1);check(current.get("txtGoAbrdDt").equals(today)&&c.date.equals(today),"now-after search replaces tomorrow in request and displayed context");check(current.get("txtGoHour").compareTo(time)>=0&&c.time.equals(current.get("txtGoHour")),"now-after search uses fresh Korea time");check(c.queryOutcome.equals("empty")&&c.trains.length()==0,"empty current-day search never leaves tomorrow rows");
   api.response=rows();c.search("서울","부산","20991020","000000");settle(c);api.failure="test network failure";c.search("김천구미","동탄","20991022","150000");settle(c);
   check(c.queryOutcome.equals("error")&&c.trains.length()==0&&c.lastStatus.startsWith("실패:"),"genuine transport failure stays error and clears old successful list");check(c.date.equals("20991022")&&c.from.equals("김천구미"),"failed request retains new context instead of reverting to previous query");check(c.queryError.contains("network failure")&&!c.searching,"error reason preserved and spinner cleared");check(ctx.getSharedPreferences("last_query",0).getString("from","").equals("서울"),"failed query does not replace persisted successful route");
   api.failure="";api.response=new JSONObject().put("strResult","FAIL").put("h_msg_cd","OTHER").put("h_msg_txt","알 수 없는 오류").toString();c.search("동탄","김천구미","20991023","000000");settle(c);check(c.queryOutcome.equals("error"),"unknown failure is not masked as no trains");
   api.response=new JSONObject().put("strResult","FAIL").put("h_msg_cd","WRD000061").put("h_msg_txt","보안문자 인증이 필요합니다").toString();c.search("동탄","김천구미","20991023","000000");settle(c);check(c.queryOutcome.equals("error")&&!c.manualNotice.isEmpty(),"captcha takes priority over empty-result code");
   boolean reserveStillFails=false;try{api.decodeResponse(empty(),true);}catch(IOException e){reserveStillFails=true;}check(reserveStillFails,"no-train normalization is scoped to train search only");
  }finally{if(api.release!=null)api.release.countDown();c.stop("cleanup");c.io.shutdownNow();}
  API slow=new API();slow.response=rows();slow.entered=new CountDownLatch(1);slow.release=new CountDownLatch(1);Context fresh=new Context();NativeController pending=ControllerSoldOutTests.controller(fresh,slow);
  try{pending.search("서울","부산","20991020","000000");check(slow.entered.await(1,TimeUnit.SECONDS),"old request paused in flight");pending.invalidateSearch();slow.release.countDown();settle(pending);check(pending.queryOutcome.equals("draft")&&pending.trains.length()==0,"late result cannot repopulate list after input edit");check(fresh.getSharedPreferences("last_query",0).getString("from","").isEmpty(),"discarded result does not overwrite last successful route");check(new StationUsage(fresh.getSharedPreferences("station_usage",0).getString("items","[]")).frequent(6).isEmpty(),"discarded response does not record station frequency");}finally{slow.release.countDown();pending.stop("cleanup");pending.io.shutdownNow();}
  API raw=new API();raw.response=new JSONObject().put("strResult","SUCC").put("trn_infos",new JSONObject().put("trn_info",new JSONArray())).toString();NativeController zero=ControllerSoldOutTests.controller(new Context(),raw);try{zero.search("서울","부산","20991020","000000");settle(zero);check(zero.queryOutcome.equals("empty")&&zero.trains.length()==0,"successful zero-row response uses same empty state");}finally{zero.stop("cleanup");zero.io.shutdownNow();}
  System.out.println(count+" search transition checks passed");
 }
}
