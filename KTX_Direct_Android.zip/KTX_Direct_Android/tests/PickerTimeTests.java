package kr.personal.ktxmate;
public class PickerTimeTests {
 static int count;
 static void check(boolean ok,String label){if(!ok)throw new AssertionError(label);count++;System.out.println("PASS "+label);}
 public static void main(String[] args){
  long now=TimingPolicy.departureMillis("20261017","082617");
  check(TimingPolicy.firstSelectableHour("20261017",now)==8,"today hides hours before eight");
  check(TimingPolicy.pickerTime("20261017","080000",now).equals("082617"),"current hour uses now rather than past hour boundary");
  check(TimingPolicy.pickerTime("20261017","000000",now).equals("082617"),"returning to today selects now");
  check(TimingPolicy.pickerTime("20261017","094500",now).equals("090000"),"later hours have no manual minutes");
  check(TimingPolicy.firstSelectableHour("20261018",now)==0,"future date exposes all hours");
  check(TimingPolicy.pickerTime("20261018","000000",now).equals("000000"),"future midnight remains selectable");
  check(TimingPolicy.pickerTime("20261018","084500",now).equals("080000"),"future hour is a whole hour");
  boolean rejects=false;try{TimingPolicy.firstSelectableHour("20261016",now);}catch(IllegalArgumentException expected){rejects=true;}check(rejects,"past dates rejected");
  long later=TimingPolicy.departureMillis("20261017","090001");
  check(TimingPolicy.firstSelectableHour("20261017",later)==9&&TimingPolicy.pickerTime("20261017","080000",later).equals("090001"),"open picker follows hour rollover");
  long night=TimingPolicy.departureMillis("20261017","235959");
  check(TimingPolicy.firstSelectableHour("20261017",night)==23&&TimingPolicy.pickerTime("20261017","230000",night).equals("235959"),"last hour only offers now");
  check(TimingPolicy.firstSelectableHour("20261018",TimingPolicy.departureMillis("20261018","000000"))==0,"midnight starts with hour zero");
  check(TimingPolicy.timeAfterDateChange("20261017","20261018","180000").equals("000000"),"changing date resets the selected hour");
  System.out.println(count+" date-time picker checks passed");
 }
}
