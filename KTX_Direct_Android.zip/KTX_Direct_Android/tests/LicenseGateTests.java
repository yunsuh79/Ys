package kr.personal.ktxmate;
import android.content.Context;import java.util.concurrent.atomic.AtomicInteger;import org.json.*;
public class LicenseGateTests {
 static int n;static void check(boolean b){if(!b)throw new AssertionError("gate check "+n);n++;}
 public static void main(String[] args)throws Exception{
  AutoLoginTests.API api=new AutoLoginTests.API();Context ctx=new Context();NativeController c=AutoLoginTests.controller(ctx,api);AtomicInteger work=new AtomicInteger();
  try{
   DeviceLicense.enabled=false;c.run("blocked",()->work.incrementAndGet(),true);check(!c.busy&&work.get()==0);
   c.vault.save("user","pw");c.tryAutoLogin(10,10);AutoLoginTests.settle(c);check(api.logins.get()==0);
   c.begin();check(!c.active()&&c.watchCount()==0);
   DeviceLicense.enabled=true;c.nextNetworkAt=android.os.SystemClock.elapsedRealtime()+150;c.run("queued",()->work.incrementAndGet(),true);DeviceLicense.enabled=false;AutoLoginTests.settle(c);check(work.get()==0);
  }finally{DeviceLicense.enabled=true;c.stop("test");c.io.shutdownNow();}
  KorailApi raw=new KorailApi("t","16","test");raw.authorization=()->{throw new Exception("denied-before-transport");};try{raw.post("https://smart.letskorail.com/test",new java.util.LinkedHashMap<>(),false);throw new AssertionError();}catch(Exception e){check("denied-before-transport".equals(e.getMessage()));}
  AtomicInteger reads=new AtomicInteger();KorailApi watchApi=new KorailApi("t","16","test"){@Override JSONArray search(String f,String t,String d,String h){reads.incrementAndGet();return new JSONArray();}};watchApi.loggedIn=true;NativeController w=ControllerSoldOutTests.controller(new Context(),watchApi);
  try{DeviceLicense.enabled=true;w.nextNetworkAt=android.os.SystemClock.elapsedRealtime()+500;w.begin();DeviceLicense.enabled=false;check(NetworkPauseTests.await(()->!w.active(),2)&&reads.get()==0);}finally{DeviceLicense.enabled=true;w.stop("test");w.io.shutdownNow();}
  System.out.println(n+" license gate checks passed");
 }
}
