package kr.personal.ktxmate;
import java.net.*;import javax.net.ssl.HttpsURLConnection;import java.util.concurrent.atomic.*;
public class MobileNetworkPolicyTests {
 static int count;static void check(boolean ok,String label){if(!ok)throw new AssertionError(label);count++;System.out.println("PASS "+label);}
 public static void main(String[] args)throws Exception{
  check(MobileNetworkPolicy.allowed(true,false,false,true,true),"validated default cellular eligible");check(!MobileNetworkPolicy.allowed(false,true,false,true,true),"Wi-Fi refused");check(!MobileNetworkPolicy.allowed(true,true,false,true,true),"Wi-Fi with cellular availability refused");check(!MobileNetworkPolicy.allowed(true,false,true,true,true),"VPN with cellular underlying transport refused");check(!MobileNetworkPolicy.allowed(true,false,false,true,false),"unvalidated cellular waits");check(!MobileNetworkPolicy.allowed(true,false,false,false,true),"cellular without internet capability refused");check(!MobileNetworkPolicy.allowed(false,false,false,true,true),"Ethernet and other transports refused");check(!MobileNetworkPolicy.allowed(false,false,false,false,false),"offline refused");
  AtomicInteger opens=new AtomicInteger();KorailApi api=new KorailApi("test","16","Test",new KorailApi.RequestNetwork(){public boolean ready(){return false;}public HttpsURLConnection open(URL u){opens.incrementAndGet();throw new AssertionError("must never open Wi-Fi");}});
  boolean paused=false;try{api.post(KorailApi.BASE+"/test",KorailApi.map("test","value"),false);}catch(KorailApi.NetworkPaused e){paused=true;}check(paused&&opens.get()==0,"shared HTTP boundary blocks before opening any non-cellular connection");
  boolean explicit=false;try{new KorailApi("test","16","Test").post(KorailApi.BASE+"/test",KorailApi.map(),false);}catch(java.io.IOException e){explicit=true;}check(explicit,"missing explicit mobile transport cannot fall back to a default URL connection");
  check(!NativeController.blocked(new KorailApi.NetworkPaused()),"local network pause is distinct from server access restriction");
  System.out.println(count+" mobile network policy checks passed");
 }
}
