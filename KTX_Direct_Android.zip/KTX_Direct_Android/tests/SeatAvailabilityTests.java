package kr.personal.ktxmate;
import org.json.*;
public class SeatAvailabilityTests {
 static int n;static void check(boolean b,String s){if(!b)throw new AssertionError(s);n++;}
 static JSONObject row(String id)throws Exception{return new JSONObject().put("h_trn_no",id).put("h_run_dt","20991020").put("h_dpt_dt","20991020").put("h_dpt_tm","172300").put("h_dpt_rs_stn_cd","0001").put("h_arv_rs_stn_cd","0020");}
 public static void main(String[] a)throws Exception{
 JSONObject r=row("059").put("h_gen_rsv_cd","11").put("h_spe_rsv_cd","13");
 check(SeatAvailability.available(r,true),"positive cabin code");check(!SeatAvailability.available(r,false),"cabins independent");
 r.put("h_gen_rsv_nm","<b>매진</b>");check(!SeatAvailability.available(r,true),"negative text overrides code");
 r.put("h_gen_rsv_nm","예약 가능").put("h_gen_rsv_cd","13");check(!SeatAvailability.available(r,true),"negative code overrides text");
 r.put("h_gen_rsv_cd","11").put("h_std_rest_seat_cnt","0");check(SeatAvailability.available(r,true),"optional zero metadata does not override available cabin code");r.remove("h_std_rest_seat_cnt");
 for(String name:new String[]{"예약대기","입석","자유석","예약불가","잔여석 없음"}){r.put("h_gen_rsv_nm",name);check(!SeatAvailability.available(r,true),name);}
 r.put("h_gen_rsv_cd","11").put("h_gen_rsv_nm","매진임박").put("h_gen_rsv_cd2","19").put("h_std_rest_seat_cnt","");check(SeatAvailability.available(r,true),"observed 395 general nearly-sold-out remains available");check("예약 가능".equals(SeatAvailability.label(r,true,120000)),"nearly-sold-out UI label");
 r.put("h_spe_rsv_cd","11").put("h_spe_rsv_nm","매진임박").put("h_spe_rsv_cd2","19");check(SeatAvailability.available(r,false),"observed 397 special nearly-sold-out remains available");
 r.put("h_gen_rsv_cd","13").put("h_gen_rsv_nm","매진임박");check(!SeatAvailability.available(r,true),"negative cabin code still rejects");r.put("h_gen_rsv_cd","11").put("h_gen_rsv_nm","매진");
 check(!SeatAvailability.available(row("060"),true),"unknown is not available");
 r.put("_seatCheckedAt",100000);check(SeatAvailability.fresh(r,115000),"fresh boundary");check(!SeatAvailability.fresh(r,115001),"expiry");check(!SeatAvailability.fresh(r,99999),"future timestamp");check(!SeatAvailability.fresh(row("060"),100000),"missing timestamp");
 check("매진".equals(SeatAvailability.label(r,true,120000)),"last known status remains visible");
 JSONObject old=row("059").put("_seatCheckedAt",1),other=row("060").put("_seatCheckedAt",2),latest=row("059").put("h_gen_rsv_cd","13");JSONArray updates=new JSONArray().put(latest);SeatAvailability.stamp(updates,100000);JSONArray merged=SeatAvailability.merge(new JSONArray().put(old).put(other),updates,100000);
 check(merged.getJSONObject(0).optLong("_seatCheckedAt")==100000,"matching train updated");check(merged.getJSONObject(1).optLong("_seatCheckedAt")==2,"other train remains stale");
 check(!SeatAvailability.available(merged.getJSONObject(0),true),"merged sold out");
 System.out.println(n+" seat availability checks passed");
 }
}
