package kr.personal.ktxmate;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import java.util.Base64;
public class SecretBoxTests {
 static int count;static void check(boolean ok,String label){if(!ok)throw new AssertionError(label);count++;System.out.println("PASS "+label);}
 static boolean rejects(SecretKey key,String value){try{SecretBox.open(key,value);return false;}catch(Exception expected){return true;}}
 public static void main(String[] args)throws Exception{KeyGenerator gen=KeyGenerator.getInstance("AES");gen.init(256);SecretKey key=gen.generateKey();String text="{\"id\":\"test@example.invalid\",\"password\":\"테스트-only-password\"}";String one=SecretBox.seal(key,text),two=SecretBox.seal(key,text);
 check(text.equals(SecretBox.open(key,one)),"credential round trip including Unicode");check(!one.equals(two),"fresh nonce used for each save");check(!one.contains("test@example.invalid")&&!one.contains("테스트-only-password"),"serialized ciphertext contains no plaintext fields");
 String[] parts=one.split(":");byte[] encrypted=Base64.getDecoder().decode(parts[1]);encrypted[0]^=1;check(rejects(key,parts[0]+":"+Base64.getEncoder().encodeToString(encrypted)),"tampered ciphertext rejected");
 check(rejects(gen.generateKey(),one),"different key rejected");check(rejects(key,"broken"),"malformed payload rejected");check(rejects(key,"AA==:"+parts[1]),"invalid nonce rejected");check(rejects(key,null),"null payload rejected");check(rejects(key,new String(new char[65537])),"oversized payload rejected");check(rejects(key,parts[0]+":AA=="),"truncated authentication tag rejected");check(rejects(key,parts[0]+":"+parts[1]+":extra"),"extra envelope fields rejected");boolean sealRejected=false;try{SecretBox.seal(key,new String(new char[16385]));}catch(IllegalArgumentException e){sealRejected=true;}check(sealRejected,"oversized plaintext rejected before encryption");System.out.println(count+" credential encryption checks passed");}
}
