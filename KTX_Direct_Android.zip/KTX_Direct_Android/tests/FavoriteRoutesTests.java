package kr.personal.ktxmate;
public class FavoriteRoutesTests {
 static int count;static void check(boolean ok,String label){if(!ok)throw new AssertionError(label);count++;System.out.println("PASS "+label);}
 public static void main(String[] args){
 FavoriteRoutes old=new FavoriteRoutes("[[\"서울\",\"부산\"],[\"동탄\",\"김천구미\"]]");check(old.size()==2&&old.index("서울","부산")==0,"existing favorites migrate without re-entry");
 check(!old.toggle("서울","부산")&&old.index("서울","부산")==-1,"star removes existing favorite");
 check(old.toggle(" 서울 "," 부산 ")&&old.index("서울","부산")==1,"star adds and trims route");
 old.move(1,-1);check(old.from(0).equals("서울"),"reorder upward");old.move(0,1);check(old.from(1).equals("서울"),"reorder downward");old.move(1,1);check(old.from(1).equals("서울"),"boundary move preserves order");
 FavoriteRoutes saved=new FavoriteRoutes(old.json());check(saved.size()==2&&saved.from(1).equals("서울"),"saved order restored");
 boolean rejected=false;try{old.toggle("서울"," 서울 ");}catch(Exception e){rejected=true;}check(rejected&&old.size()==2,"same station rejected without changing favorites");
 FavoriteRoutes malformed=new FavoriteRoutes("not JSON");check(malformed.size()==0,"damaged preferences handled");
 FavoriteRoutes dup=new FavoriteRoutes("[[\"서울\",\"부산\"],[\"서울\",\"부산\"],[\"\",\"부산\"],[\"서울\",\"서울\"]]");check(dup.size()==1,"duplicates and invalid routes filtered");
 FavoriteRoutes full=new FavoriteRoutes("[]");for(int i=0;i<8;i++)full.toggle("역"+i,"부산");rejected=false;try{full.toggle("추가역","부산");}catch(Exception e){rejected=true;}check(rejected&&full.size()==8,"maximum favorites enforced");full.remove(0);check(full.size()==7&&full.from(0).equals("역1"),"delete preserves remaining order");
 System.out.println(count+" favorites checks passed");
 }
}
