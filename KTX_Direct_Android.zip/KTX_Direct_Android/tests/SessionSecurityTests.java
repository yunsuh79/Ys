package kr.personal.ktxmate;
import android.content.Context;
import java.net.HttpCookie;
import java.net.URI;
public class SessionSecurityTests {
 static int count;
 static void check(boolean value,String label){if(!value)throw new AssertionError(label);count++;System.out.println("PASS "+label);}
 static void seed(KorailApi api){api.loggedIn=true;api.memberCard="test-member";api.queueState="test-queue";api.cookies.getCookieStore().add(URI.create(KorailApi.BASE),new HttpCookie("JSESSIONID","test-session"));}
 static void cleared(KorailApi api,String label){check(!api.loggedIn&&api.memberCard.isEmpty()&&api.queueState.isEmpty()&&api.cookies.getCookieStore().getCookies().isEmpty(),label);}
 public static void main(String[] args)throws Exception{
  KorailApi api=new KorailApi("test","16","Test");seed(api);api.clearSession();cleared(api,"session cleanup removes cookies, member number and queue state");
  NativeController c=ControllerSoldOutTests.controller(new Context(),api);
  try{
   seed(api);c.accountKey="test-owner";c.historyCheckedAt=123;c.logout();cleared(api,"logout removes all session material");check(c.accountKey.isEmpty()&&c.historyCheckedAt==0,"logout removes account context");
   seed(api);c.accountKey="test-owner";c.run("test",()->{throw new KorailApi.AccessCheck("test challenge");});AutoLoginTests.settle(c);cleared(api,"access challenge removes all session material");check(c.accountKey.isEmpty(),"access challenge removes account context");
   seed(api);c.run("test",()->{throw new KorailApi.RateLimited(60);});AutoLoginTests.settle(c);cleared(api,"rate limit removes all session material");
  }finally{c.io.shutdownNow();}
  System.out.println(count+" session security checks passed");
 }
}
