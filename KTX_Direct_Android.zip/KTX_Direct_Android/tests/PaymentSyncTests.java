package kr.personal.ktxmate;
import android.content.Context;
import org.json.*;
import java.io.IOException;
import java.util.concurrent.*;
public class PaymentSyncTests {
 static int n;static void check(boolean b,String s){if(!b)throw new AssertionError(s);n++;System.out.println("PASS "+s);}
 static class API extends ControllerSoldOutTests.API {
  JSONArray history=new JSONArray();boolean fail;int reads;
  API()throws Exception{super(1);}
  @Override JSONArray reservationHistory()throws Exception{reads++;if(fail)throw new IOException("test history read failed");return history;}
 }
 static void settle(NativeController c)throws Exception{long end=System.nanoTime()+TimeUnit.SECONDS.toNanos(3);while(c.busy&&System.nanoTime()<end)Thread.sleep(10);}
 static NativeController setup(API api)throws Exception{NativeController c=ControllerSoldOutTests.controller(new Context(),api);c.accountKey=ReservationLedger.account("payment-test");c.recordBooking(c.accountKey,c.selected,"서울","부산","12345678","공식 앱 확인","1",0);return c;}
 public static void main(String[] args)throws Exception{
  API api=new API();NativeController c=setup(api);JSONObject target=c.selected;
  try{check(c.hasPaymentRecords(),"confirmed record eligible for refresh");api.history=new JSONArray().put(new JSONObject(target.toString()).put("h_pnr_no","12345678").put("source","server").put("h_trn_no","00059"));c.syncHistory();settle(c);check(c.paymentFor(target,"1")!=null,"existing server reservation keeps payment action");check(c.historyRows().length()==1,"leading-zero train numbers deduplicate");api.fail=true;c.syncHistory();settle(c);check(c.paymentFor(target,"1")!=null&&!c.busy&&!c.searching,"failed history read preserves last-known status without loading lock");api.fail=false;api.history=new JSONArray();c.syncHistory();settle(c);check(c.paymentFor(target,"1")==null,"missing server reservation removes payment action");check(c.historyRows().length()==1,"missing reservation retains history without assuming cancellation");}finally{c.io.shutdownNow();}
  API fresh=new API();NativeController f=setup(fresh);JSONObject train=f.selected;
  try{f.search("서울","부산","20991020","000000");settle(f);check(fresh.reads==1&&fresh.searches.get()==1,"user refresh reconciles payment and queries seats once");check(f.paymentFor(train,"1")==null&&fresh.reservations.get()==0,"refresh clears missing payment marker without booking");}finally{f.io.shutdownNow();}
  System.out.println(n+" payment synchronization checks passed");
 }
}
