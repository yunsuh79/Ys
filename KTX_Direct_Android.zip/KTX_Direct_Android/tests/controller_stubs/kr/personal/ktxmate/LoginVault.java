package kr.personal.ktxmate;
import android.content.Context;
/** Test-only vault: exercises controller decisions, NOT Android Keystore. */
final class LoginVault {
 final android.content.SharedPreferences prefs;
 LoginVault(Context c){prefs=c.getSharedPreferences("test-vault",0);}
 boolean has(){return !prefs.getString("id","").isEmpty();}
 String[] read(){return new String[]{prefs.getString("id",""),prefs.getString("pw","")};}
 void save(String id,String pw){prefs.edit().putString("id",id).putString("pw",pw).commit();}
 void clear(){prefs.edit().remove("id").remove("pw").commit();}
}
