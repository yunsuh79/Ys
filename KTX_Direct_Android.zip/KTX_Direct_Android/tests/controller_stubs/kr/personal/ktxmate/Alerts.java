package kr.personal.ktxmate;class Alerts{static void send(android.content.Context c,boolean test,String message){}}
