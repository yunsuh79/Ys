package kr.personal.ktxmate;class MonitorService{void update(String s){}void finish(){}void finishAfterAlerts(){}}
