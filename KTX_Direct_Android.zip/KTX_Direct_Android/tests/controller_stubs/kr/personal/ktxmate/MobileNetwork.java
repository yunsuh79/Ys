package kr.personal.ktxmate;
import android.content.Context;import javax.net.ssl.HttpsURLConnection;import java.net.URL;
/** JVM-only network state double. No live transport is available. */
final class MobileNetwork implements KorailApi.RequestNetwork {
 volatile boolean available=true;Runnable change;
 MobileNetwork(Context c){}
 public boolean ready(){return available;}
 public HttpsURLConnection open(URL url)throws Exception{throw new AssertionError("live network forbidden in JVM tests");}
 void start(Runnable changed){change=changed;}
 void set(boolean next){available=next;if(change!=null)change.run();}
}
