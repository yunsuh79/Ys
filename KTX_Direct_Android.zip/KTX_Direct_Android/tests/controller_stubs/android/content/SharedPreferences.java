package android.content;
import java.util.concurrent.ConcurrentHashMap;
public class SharedPreferences {
 final ConcurrentHashMap<String,Object> values=new ConcurrentHashMap<>();
 public int getInt(String k,int d){Object v=values.get(k);return v instanceof Integer?(Integer)v:d;}
 public String getString(String k,String d){Object v=values.get(k);return v instanceof String?(String)v:d;}
 public boolean getBoolean(String k,boolean d){Object v=values.get(k);return v instanceof Boolean?(Boolean)v:d;}
 public Editor edit(){return new Editor();}
 public class Editor {final java.util.Map<String,Object> writes=new java.util.HashMap<>();public Editor putString(String k,String v){writes.put(k,v);return this;}public Editor putInt(String k,int v){writes.put(k,v);return this;}public Editor putBoolean(String k,boolean v){writes.put(k,v);return this;}public Editor remove(String k){values.remove(k);return this;}public Editor clear(){values.clear();return this;}public boolean commit(){values.putAll(writes);return true;}public void apply(){commit();}}
}
