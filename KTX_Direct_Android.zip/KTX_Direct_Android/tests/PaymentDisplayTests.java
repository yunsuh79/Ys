package kr.personal.ktxmate;
import org.json.*;
public class PaymentDisplayTests {
 static int n;static void check(boolean b,String s){if(!b)throw new AssertionError(s);n++;}
 public static void main(String[] args)throws Exception{
 JSONObject train=ControllerSoldOutTests.target();JSONObject record=new JSONObject(train.toString()).put("_paymentPending",true).put("_bookedCabin","1").put("h_pnr_no","12345678");long now=TimingPolicy.departureMillis("20991020","170000");
 check(ReservationLedger.pendingPayment(record,train,"1",now),"confirmed cabin has payment action");check(!ReservationLedger.pendingPayment(record,train,"2",now),"other cabin not marked");
 JSONObject other=new JSONObject(train.toString()).put("h_trn_no","060");check(!ReservationLedger.pendingPayment(record,other,"1",now),"different train not marked");other=new JSONObject(train.toString()).put("h_dpt_dt","20991021");check(!ReservationLedger.pendingPayment(record,other,"1",now),"different date not marked");
 record.put("_paymentUntil",now+1000);check(ReservationLedger.pendingPayment(record,train,"1",now),"before deadline");check(!ReservationLedger.pendingPayment(record,train,"1",now+1000),"deadline expires badge");record.put("_paymentUntil",0);
 check(!ReservationLedger.pendingPayment(record,train,"1",TimingPolicy.departureMillis("20991020","172300")),"departed train not marked");record.put("_paymentPending",false);check(!ReservationLedger.pendingPayment(record,train,"1",now),"no pending marker no payment status");record.put("_paymentPending",true).put("h_pnr_no","invalid");check(!ReservationLedger.pendingPayment(record,train,"1",now),"unverified identifier not marked");
 check(ReservationLedger.paymentUntil(new JSONObject().put("h_ntisu_lmt_dt","20991020").put("h_ntisu_lmt_tm","171000"))==now+600000,"server deadline parsed");check(ReservationLedger.paymentUntil(new JSONObject())==0,"missing deadline not fabricated");
 System.out.println(n+" payment display checks passed");
 }
}
