package kr.personal.ktxmate;
import android.content.Context;import org.json.*;import java.util.concurrent.atomic.*;
public class WatchStartNoticeTests {
 static int count;static void check(boolean ok,String label){if(!ok)throw new AssertionError(label);count++;System.out.println("PASS "+label);}
 static class UI implements NativeController.Listener {AtomicInteger starts=new AtomicInteger();String cabin="",number="";public void update(){}public void alert(String t,String m){}public void watchStarted(JSONObject train,String c){cabin=c;number=train.optString("h_trn_no");starts.incrementAndGet();}}
 public static void main(String[] args)throws Exception{
  KorailApi api=new KorailApi("test","16","Test"){@Override JSONArray search(String f,String t,String d,String h)throws Exception{return new JSONArray().put(ControllerSoldOutTests.target().put("h_gen_rsv_cd","13"));}};api.loggedIn=true;Context ctx=new Context();NativeController c=ControllerSoldOutTests.controller(ctx,api);UI ui=new UI();c.listener=new java.lang.ref.WeakReference<>(ui);JSONObject row=ControllerSoldOutTests.target();
  try{c.addWatch(row,"1","서울","부산","20991020",false);check(ui.starts.get()==1&&ui.cabin.equals("1")&&ui.number.equals("059"),"accepted watch emits target and cabin exactly once");c.addWatch(row,"1","서울","부산","20991020",false);check(ui.starts.get()==1,"duplicate registration emits no start notice");c.stop("test");api.loggedIn=false;c.addWatch(row,"1","서울","부산","20991020",false);check(ui.starts.get()==1,"missing login emits no false start notice");api.loggedIn=true;ctx.getSharedPreferences("runtime",0).edit().putBoolean("pending",true).commit();c.addWatch(row,"1","서울","부산","20991020",false);check(ui.starts.get()==1,"uncertain prior booking emits no false start notice");ctx.getSharedPreferences("runtime",0).edit().putBoolean("pending",false).commit();c.addWatch(row,"1","서울","부산","20991020",true);check(ui.starts.get()==1,"direct booking does not claim cancellation-watch start");}finally{c.stop("cleanup");c.io.shutdownNow();}
  System.out.println(count+" watch start notice checks passed");
 }
}
