from pathlib import Path
import os,subprocess
p=Path(__file__).resolve().parents[1];json_jar=os.environ.get('JSON_JAR',str(p.parent/'android-tools/research/json.jar'));out=p/'build/mobile-transport-tests';out.mkdir(parents=True,exist_ok=True);src=p/'app/src/main/java/kr/personal/ktxmate'
files=list((p/'tests/network_stubs').rglob('*.java'))+[p/'tests/controller_stubs/android/content/Context.java',p/'tests/controller_stubs/android/content/SharedPreferences.java']+[src/(n+'.java') for n in ['MobileNetwork','MobileNetworkPolicy','KorailApi','SessionLifetime','TimingPolicy','TokenCodec','ReservationLedger']]+[p/'tests/MobileTransportTests.java']
subprocess.run(['java','com.sun.tools.javac.Main','--release','8','-encoding','UTF-8','-cp',json_jar,'-d',str(out)]+list(map(str,files)),check=True)
subprocess.run(['java','-cp',str(out)+os.pathsep+json_jar,'kr.personal.ktxmate.MobileTransportTests'],check=True)
