package kr.personal.ktxmate;
public class NetworkPopupStateTests {
 static int n;static void check(boolean b){if(!b)throw new AssertionError("popup "+n);n++;}
 public static void main(String[] args){
  NetworkPopupState s=new NetworkPopupState();s.observe(true,false);check(!s.pending());s.observe(true,false);check(s.consume(true,false)==null);
  s.observe(false,true);check(s.pending());NetworkPopupState.Notice wifi=s.consume(true,false);check(wifi.kind==NetworkPopupState.WIFI&&wifi.title.contains("Wi-Fi")&&wifi.message.contains("일시 중지"));check(s.consume(true,false)==null);s.observe(false,true);check(!s.pending());
  s.observe(false,false);s.observe(true,false);NetworkPopupState.Notice restored=s.consume(true,false);check(restored.kind==NetworkPopupState.MOBILE&&restored.message.contains("기존 대기"));check(s.consume(true,false)==null);
  s.observe(false,false);s.observe(true,false);check(!s.pending()); // short connection flap returns to presented state before display
  s.observe(false,true);s.observe(false,true);check(s.pending());s.consume(false,false);s.observe(true,false);NetworkPopupState.Notice held=s.consume(true,true);check(held.message.contains("자동으로 재개하지 않습니다"));
  s.observe(false,false);NetworkPopupState.Notice offline=s.consume(true,false);check(offline.kind==NetworkPopupState.UNAVAILABLE&&offline.message.contains("일시 중지"));
  s.observe(true,false);NetworkPopupState.Notice idle=s.consume(false,false);check(idle.message.contains("이용할 수 있습니다"));
  NetworkPopupState baseline=new NetworkPopupState();baseline.observe(false,true);check(!baseline.pending());baseline.observe(true,false);check(baseline.pending()); // retained while UI is not ready; consumes only when shown
  check(baseline.consume(false,false).kind==NetworkPopupState.MOBILE);
  check(NetworkPopupState.notice(NetworkPopupState.WIFI,true,true).message.contains("자동으로 재개하지 않습니다"));
  NetworkPopupState.Notice blocked=NetworkPopupState.entryNotice(true);
  check(blocked.kind==NetworkPopupState.WIFI&&blocked.title.contains("사용할 수 없습니다"));
  check(blocked.message.contains("앱 정책상 Wi-Fi 접속 시에는")&&blocked.message.contains("홈 화면"));
  check(blocked.message.contains("Wi-Fi를 끄고")&&blocked.message.contains("LTE/5G"));
  NetworkPopupState.Notice noMobile=NetworkPopupState.entryNotice(false);
  check(noMobile.kind==NetworkPopupState.UNAVAILABLE&&noMobile.message.contains("VPN"));
  check(noMobile.message.contains("연결이 확인되면 홈 화면"));
  System.out.println(n+" network popup state checks passed");
 }
}
