package kr.personal.ktxmate;
import android.content.Context;
import org.json.*;
import java.io.IOException;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
public class ControllerSoldOutTests {
 static int count;static void check(boolean ok,String label){if(!ok)throw new AssertionError(label);count++;System.out.println("PASS "+label);}
 static JSONObject target()throws Exception{return new JSONObject().put("h_trn_no","059").put("h_run_dt","20991020").put("h_dpt_dt","20991020").put("h_dpt_tm","172300").put("h_dpt_rs_stn_cd","0001").put("h_arv_rs_stn_cd","0020").put("h_gen_rsv_cd","11");}
 static class API extends KorailApi {
  final AtomicInteger searches=new AtomicInteger(),reservations=new AtomicInteger();final CountDownLatch secondQuery=new CountDownLatch(1);final int mode;final JSONObject row;
  API(int mode)throws Exception{super("test","16","Test");this.mode=mode;row=target();if(mode==5)row.put("h_gen_rsv_nm","매진");if(mode==6)row.put("h_gen_rsv_nm","매진임박");loggedIn=true;}
  @Override JSONArray search(String f,String t,String d,String h)throws Exception{int n=searches.incrementAndGet();if(n>=2){secondQuery.countDown();return new JSONArray().put(new JSONObject(row.toString()).put("h_gen_rsv_cd","13"));}if(mode==3)throw new RateLimited(60);if(mode==4)throw new SoldOut();return new JSONArray().put(row);}
  @Override JSONObject reserve(JSONObject r,String seat)throws Exception{reservations.incrementAndGet();if(mode==1||mode==6)throw new SoldOut();if(mode==2)throw new IOException("response timeout");throw new AssertionError("unexpected reservation");}
 }
 static NativeController controller(Context ctx,KorailApi api)throws Exception{TermsConsent.accept(ctx);NativeController c=new NativeController(ctx);java.lang.reflect.Field field=NativeController.class.getDeclaredField("api");field.setAccessible(true);field.set(c,api);c.selected=target();c.date="20991020";return c;}
 static void waitIdle(NativeController c)throws Exception{long end=System.nanoTime()+TimeUnit.SECONDS.toNanos(2);while(c.active()&&System.nanoTime()<end)Thread.sleep(10);}
 public static void main(String[] args)throws Exception{
  Context ctx=new Context();API raced=new API(1);NativeController c=controller(ctx,raced);
  try{c.begin();check(raced.secondQuery.await(12,TimeUnit.SECONDS),"reservation sold-out returns to fresh seat search");check(c.active()&&"watch".equals(c.phase),"monitor remains active after sold-out");check(raced.reservations.get()==1,"no direct replay of failed reservation");check(!ctx.getSharedPreferences("runtime",0).getBoolean("pending",true),"explicit rejection clears only its uncertainty lock");}finally{c.stop("test complete");c.io.shutdownNow();}
  Context uncertainCtx=new Context();API uncertain=new API(2);NativeController u=controller(uncertainCtx,uncertain);
  try{u.begin();waitIdle(u);check(!u.active(),"unknown reservation failure stops monitor");check(uncertainCtx.getSharedPreferences("runtime",0).getBoolean("pending",false),"unknown outcome retains uncertainty lock");check(!uncertain.secondQuery.await(1200,TimeUnit.MILLISECONDS)&&uncertain.reservations.get()==1,"unknown outcome causes no further search or reservation");}finally{u.stop("test complete");u.io.shutdownNow();}
  API limited=new API(3);NativeController l=controller(new Context(),limited);
  try{l.begin();waitIdle(l);check(!l.active()&&!limited.secondQuery.await(1200,TimeUnit.MILLISECONDS)&&limited.reservations.get()==0,"request limit still stops with no automatic retry");}finally{l.stop("test complete");l.io.shutdownNow();}
  API noSeats=new API(4);NativeController n=controller(new Context(),noSeats);
  try{n.begin();check(noSeats.secondQuery.await(12,TimeUnit.SECONDS)&&n.active()&&noSeats.reservations.get()==0,"search-stage sold-out continues read-only monitoring");}finally{n.stop("test complete");n.io.shutdownNow();}
  API conflicting=new API(5);NativeController f=controller(new Context(),conflicting);
  try{f.begin();check(conflicting.secondQuery.await(12,TimeUnit.SECONDS)&&f.active()&&conflicting.reservations.get()==0,"sold-out name overrides positive code without booking");}finally{f.stop("test complete");f.io.shutdownNow();}
  API nearly=new API(6);NativeController p=controller(new Context(),nearly);
  try{p.begin();check(nearly.secondQuery.await(12,TimeUnit.SECONDS)&&nearly.reservations.get()==1,"nearly sold out triggers reservation before sold-out race resumes watch");}finally{p.stop("test complete");p.io.shutdownNow();}
  System.out.println(count+" controller checks passed");
 }
}
