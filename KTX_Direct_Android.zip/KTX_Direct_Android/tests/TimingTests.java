package kr.personal.ktxmate;
import java.time.*;
public class TimingTests {
 static int count=0;static void check(boolean ok,String label){if(!ok)throw new AssertionError(label);count++;System.out.println("PASS "+label);}
 public static void main(String[] args){long now=ZonedDateTime.of(2026,10,16,15,32,15,0,TimingPolicy.KST).toInstant().toEpochMilli();
 check(TimingPolicy.searchTime("20261016","090000",now).equals("153216"),"past time today moves strictly after now");
 check(TimingPolicy.searchTime("20261016","180000",now).equals("180000"),"future time today retained");
 check(TimingPolicy.searchTime("20261017","090000",now).equals("090000"),"tomorrow time retained");
 boolean rejected=false;try{TimingPolicy.searchTime("20261015","090000",now);}catch(Exception e){rejected=true;}check(rejected,"past date rejected");
 check(!TimingPolicy.future("20261016","153215",now),"departing now excluded");
 check(TimingPolicy.future("20261016","153216",now),"next second included");
 long[] remaining={1,6*3600000L,6*3600000L+1,24*3600000L-1,24*3600000L,48*3600000L};
 int[][] ranges={{1000,3000},{1000,3000},{3000,4000},{3000,4000},{5000,6000},{5000,6000}};
 for(int i=0;i<remaining.length;i++){boolean within=true,changed=false;long first=TimingPolicy.delayMillis(now+remaining[i],now);for(int n=0;n<5000;n++){long delay=TimingPolicy.delayMillis(now+remaining[i],now);within&=delay>=ranges[i][0]&&delay<=ranges[i][1];changed|=delay!=first;}check(within,"tier bounds for remaining milliseconds "+remaining[i]);check(changed,"random delay resampled for remaining milliseconds "+remaining[i]);}
 check(TimingPolicy.retryAfterSeconds("120",now)==120,"respect server retry-after seconds");
 check(TimingPolicy.retryAfterSeconds("Fri, 16 Oct 2026 06:34:15 GMT",now)==120,"respect server retry-after date");
 check(TimingPolicy.retryAfterSeconds(null,now)==60,"rate limit default wait");
 long midnight=ZonedDateTime.of(2026,10,16,23,59,59,0,TimingPolicy.KST).toInstant().toEpochMilli();
 check(TimingPolicy.searchTime("20261016","090000",midnight).equals("235959"),"midnight does not silently change date");
 check(!TimingPolicy.future("20261016","235959",midnight),"midnight boundary row excluded");
 check("000000".equals(TimingPolicy.timeAfterDateChange("20261016","20261017","201500")),"next day resets time to midnight");
 check("000000".equals(TimingPolicy.timeAfterDateChange("20261018","20261017","165200")),"previous day resets time to midnight");
 check("000000".equals(TimingPolicy.timeAfterDateChange("20261017","20261102","165200")),"calendar date change resets time");
 check("165200".equals(TimingPolicy.timeAfterDateChange("20261017","20261017","165200")),"confirming unchanged date keeps explicit time");
 System.out.println(count+" timing checks passed");
 }
}
