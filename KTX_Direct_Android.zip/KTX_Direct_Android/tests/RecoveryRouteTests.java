package kr.personal.ktxmate;
import android.content.Context;
import org.json.*;
import java.util.concurrent.*;
public class RecoveryRouteTests {
 static int n;static void check(boolean b,String s){if(!b)throw new AssertionError(s);n++;System.out.println("PASS "+s);}
 public static void main(String[] args)throws Exception{
  Context ctx=new Context();NativeController c=ControllerSoldOutTests.controller(ctx,new ControllerSoldOutTests.API(1));
  try{ctx.getSharedPreferences("runtime",0).edit().putBoolean("pending",true).putString("lastPNR","12345678").commit();c.busy=true;boolean blocked=false;try{c.clearPendingAfterReview();}catch(Exception e){blocked=true;}check(blocked&&ctx.getSharedPreferences("runtime",0).getBoolean("pending",false),"busy request cannot be unlocked");c.busy=false;c.phase="booking";blocked=false;try{c.clearPendingAfterReview();}catch(Exception e){blocked=true;}check(blocked,"in-flight reservation cannot be unlocked");c.phase="idle";c.clearPendingAfterReview();check(!ctx.getSharedPreferences("runtime",0).getBoolean("pending",true),"explicit review clears persisted lock");check("12345678".equals(ctx.getSharedPreferences("runtime",0).getString("lastPNR","")),"unlock retains confirmed reservation data");}finally{c.io.shutdownNow();}
  Context routeCtx=new Context();NativeController first=ControllerSoldOutTests.controller(routeCtx,new ControllerSoldOutTests.API(1));NativeController next=null;
  try{first.search("동탄","김천구미","20991020","000000");long end=System.nanoTime()+TimeUnit.SECONDS.toNanos(3);while(first.busy&&System.nanoTime()<end)Thread.sleep(10);next=new NativeController(routeCtx);check("동탄".equals(next.from)&&"김천구미".equals(next.to),"last successful query route restored in new controller");check(next.date.isEmpty(),"previous trip date not reused on startup");}finally{first.io.shutdownNow();if(next!=null)next.io.shutdownNow();}
  System.out.println(n+" recovery and route checks passed");
 }
}
