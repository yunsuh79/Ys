package kr.personal.ktxmate;
import java.security.*;import java.util.*;import java.nio.charset.StandardCharsets;
public final class LicenseTests {
 static int checks;static KeyPair pair;static String pub,binding=String.join("",Collections.nCopies(64,"a"));static final long NOW=1800000000L;
 static String code(String payload)throws Exception{byte[] bytes=payload.getBytes(StandardCharsets.UTF_8);Signature s=Signature.getInstance("SHA256withECDSA");s.initSign(pair.getPrivate());s.update(bytes);Base64.Encoder e=Base64.getUrlEncoder().withoutPadding();return e.encodeToString(bytes)+"."+e.encodeToString(s.sign());}
 static String payload(String device,long issued,long expires){return "JB1\nkr.personal.ktxmate\n"+device+"\n"+issued+"\n"+expires;}
 static void ok(boolean b){checks++;if(!b)throw new AssertionError(checks);}
 static void reject(String code,String device,long now)throws Exception{try{LicenseVerifier.verify(code,device,now,pub);throw new AssertionError("accepted invalid license");}catch(GeneralSecurityException|IllegalArgumentException expected){checks++;}}
 public static void main(String[] args)throws Exception{
  KeyPairGenerator g=KeyPairGenerator.getInstance("EC");g.initialize(new java.security.spec.ECGenParameterSpec("secp256r1"));pair=g.generateKeyPair();pub=Base64.getEncoder().encodeToString(pair.getPublic().getEncoded());
  String valid=code(payload(binding,NOW,NOW+86400));ok(LicenseVerifier.verify(valid,binding,NOW,pub)==0);
  reject(valid,String.join("",Collections.nCopies(64,"b")),NOW);ok(LicenseVerifier.verify(valid,binding,NOW+86400,pub)==0);ok(LicenseVerifier.verify(valid,binding,NOW-301,pub)==0);
  ok(LicenseVerifier.verify(valid,binding,NOW-300,pub)==0);
  String[] parts=valid.split("\\.");byte[] changed=Base64.getUrlDecoder().decode(parts[0]);changed[0]='X';reject(Base64.getUrlEncoder().withoutPadding().encodeToString(changed)+"."+parts[1],binding,NOW);
  reject(code(payload(binding,NOW,NOW)),binding,NOW);reject(code(payload(binding,NOW,NOW-1)),binding,NOW);reject(code(payload(binding,NOW,NOW+367L*86400)),binding,NOW);
  reject(code(payload(binding,NOW,NOW+86400).replace("kr.personal.ktxmate","other.package")),binding,NOW);
  reject(code(payload(binding,NOW,NOW+86400)+"\nextra"),binding,NOW);reject(code("JB1\nkr.personal.ktxmate\n"+binding+"\nNaN\n1800086400"),binding,NOW);
  reject("",binding,NOW);reject("aaa.bbb.ccc",binding,NOW);reject(String.join("",Collections.nCopies(2049,"x")),binding,NOW);reject(valid,"bad",NOW);
  String permanent=code(payload(binding,NOW,0));
  ok(LicenseVerifier.verify(permanent,binding,NOW,pub)==0);
  ok(LicenseVerifier.verify(permanent,binding,NOW+100L*366*86400,pub)==0);
  reject(permanent,String.join("",Collections.nCopies(64,"b")),NOW);
  String old=pub;pub=Base64.getEncoder().encodeToString(g.generateKeyPair().getPublic().getEncoded());reject(valid,binding,NOW);pub=old;
  ok(LicenseVerifier.hash(new byte[0]).equals("e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"));
  // Actual administrator tool signs a harmless test binding. Public verification only.
  if(args.length==1)ok(LicenseVerifier.verify(args[0],binding,System.currentTimeMillis()/1000)==0);
  System.out.println(checks+" license checks passed");
 }
}
