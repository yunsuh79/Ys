package kr.personal.ktxmate;
import android.content.Context;
import org.json.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
public class BrowseDuringWatchTests {
 static int n;static void check(boolean b,String s){if(!b)throw new AssertionError(s);n++;System.out.println("PASS "+s);}
 static class API extends KorailApi {
  final CountDownLatch entered=new CountDownLatch(1),release=new CountDownLatch(1);final List<String> calls=new CopyOnWriteArrayList<>();final AtomicInteger running=new AtomicInteger(),maximum=new AtomicInteger();boolean limited;
  API(){super("test","16","Test");loggedIn=true;}
  @Override JSONArray search(String f,String t,String d,String h)throws Exception{int count=running.incrementAndGet();maximum.accumulateAndGet(count,Math::max);try{calls.add(f+"|"+d);entered.countDown();if(!release.await(3,TimeUnit.SECONDS))throw new Exception("test timeout");if(limited&&f.equals("동탄"))throw new RateLimited(60);JSONObject row=ControllerSoldOutTests.target().put("h_gen_rsv_cd","13").put("h_spe_rsv_cd","13");if(f.equals("동탄"))row.put("h_trn_no","395").put("h_run_dt",d).put("h_dpt_dt",d).put("h_dpt_tm","165200").put("h_dpt_rs_stn_cd","0021").put("h_arv_rs_stn_cd","0022");return new JSONArray().put(row);}finally{running.decrementAndGet();}}
 }
 static void settle(NativeController c)throws Exception{long end=System.nanoTime()+TimeUnit.SECONDS.toNanos(12);while(c.busy&&System.nanoTime()<end)Thread.sleep(10);}
 public static void main(String[] args)throws Exception{
  API api=new API();Context ctx=new Context();NativeController c=ControllerSoldOutTests.controller(ctx,api);JSONObject old=ControllerSoldOutTests.target().put("h_gen_rsv_cd","13");
  try{c.addWatch(old,"1","서울","부산","20991020",false);check(api.entered.await(1,TimeUnit.SECONDS),"original watch started");c.search("동탄","김천구미","20991021","000000");check(c.busy&&c.searching,"browse request accepted while watching");api.release.countDown();settle(c);check(!c.busy&&"동탄".equals(c.from)&&"20991021".equals(c.date),"new route and date query completes");check(c.watchCount()==1&&c.watching(old,"1")!=null,"existing watch survives browsing");NativeController.WatchTask w=c.watches.get(0);check("서울".equals(w.from)&&"부산".equals(w.to)&&"20991020".equals(w.date),"original target route and date remain frozen");check(api.maximum.get()==1,"browse and watch network requests stay serial");JSONObject next=c.trains.getJSONObject(0);c.addWatch(next,"1",c.from,c.to,c.date,false);check(c.watchCount()==2,"new search result can become a second watch");check("서울".equals(c.routeFrom(old))&&"부산".equals(c.routeTo(old)),"watch card keeps original route after browsing elsewhere");StationUsage usage=new StationUsage(ctx.getSharedPreferences("station_usage",0).getString("items","[]"));check(usage.count("서울")==0&&usage.count("동탄")==1&&usage.count("김천구미")==1,"watch polling excluded from frequency while manual browsing counted");}finally{api.release.countDown();c.stop("test cleanup");c.io.shutdownNow();}
  API blocked=new API();NativeController b=ControllerSoldOutTests.controller(new Context(),blocked);
  try{b.addWatch(old,"1","서울","부산","20991020",false);blocked.entered.await(1,TimeUnit.SECONDS);blocked.limited=true;b.search("동탄","김천구미","20991021","000000");blocked.release.countDown();settle(b);check(!b.active()&&b.watchCount()==0&&!blocked.loggedIn,"request limit during browsing stops all watches");}finally{blocked.release.countDown();b.stop("test cleanup");b.io.shutdownNow();}
  System.out.println(n+" browsing-during-watch checks passed");
 }
}
