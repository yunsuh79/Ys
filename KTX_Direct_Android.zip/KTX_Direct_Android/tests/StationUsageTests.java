package kr.personal.ktxmate;
import java.util.*;
public class StationUsageTests {
 static int count;static void check(boolean value,String label){if(!value)throw new AssertionError(label);count++;System.out.println("PASS "+label);}
 public static void main(String[] args){
  StationUsage usage=new StationUsage("[]");check(usage.frequent(6).isEmpty(),"fresh install does not invent station history");check(usage.ordered().equals(Arrays.asList(MajorStations.NAMES)),"unused major stations retain default order");
  usage.route("동탄","김천구미");usage.record("동탄");check(usage.ordered().get(0).equals("동탄"),"frequent station comes first");check(usage.frequent(6).get(1).equals("김천구미"),"queried destination also appears at top");
  usage.record("서울");usage.record("부산");check(usage.ordered().indexOf("부산")<usage.ordered().indexOf("서울"),"recent choice breaks equal-frequency ties");
  StationUsage restored=new StationUsage(usage.json());check(restored.ordered().equals(usage.ordered())&&restored.count("동탄")==2,"frequency and recency survive reload");
  usage.record("없는역");check(!usage.ordered().contains("없는역"),"unrecognized stations cannot enter picker");
  usage.route("동탄","동탄");check(usage.count("동탄")==2,"invalid route is not recorded");check(usage.frequent(2).size()==2,"top station chip limit honored");
  check(StationUsage.matches("김천구미","ㄱㅊㄱㅁ"),"Korean initials find station");check(StationUsage.matches("김천구미","구미"),"partial station name search");check(StationUsage.matches("여수EXPO","expo"),"case-insensitive Latin station search");check(StationUsage.matches("김천구미"," ㄱㅊ "),"whitespace ignored in initials search");check(!StationUsage.matches("동탄","서울"),"unrelated station filtered out");
  check(new StationUsage("bad-json").frequent(6).isEmpty(),"corrupt preferences fail safely");
  System.out.println(count+" station usage checks passed");
 }
}
