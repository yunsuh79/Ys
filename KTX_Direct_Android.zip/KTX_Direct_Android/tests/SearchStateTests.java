package kr.personal.ktxmate;
import android.content.Context;
import org.json.*;
import java.io.IOException;
import java.util.concurrent.*;
public class SearchStateTests {
 static int n;static void check(boolean b,String s){if(!b)throw new AssertionError(s);n++;System.out.println("PASS "+s);}
 static class API extends KorailApi {
  final CountDownLatch entered=new CountDownLatch(1),release=new CountDownLatch(1);int calls;boolean fail;
  API(){super("test","16","Test");}
  @Override JSONArray search(String f,String t,String d,String h)throws Exception{calls++;entered.countDown();if(!release.await(2,TimeUnit.SECONDS))throw new IOException("test gate timed out");if(fail)throw new IOException("test query failed");return new JSONArray().put(ControllerSoldOutTests.target());}
 }
 static void settle(NativeController c)throws Exception{long end=System.nanoTime()+TimeUnit.SECONDS.toNanos(3);while(c.busy&&System.nanoTime()<end)Thread.sleep(10);}
 public static void main(String[] args)throws Exception{
  API api=new API();Context ctx=new Context();NativeController c=ControllerSoldOutTests.controller(ctx,api);
  try{c.search("서울","부산","20991020","000000");check(api.entered.await(1,TimeUnit.SECONDS),"query entered");check(c.busy&&c.searching,"loading state visible for full query");c.search("서울","부산","20991020","000000");check(api.calls==1,"repeat refresh cannot overlap query");api.release.countDown();settle(c);check(!c.busy&&!c.searching,"success clears loading indicator");check(c.trains.length()==1,"result published before loading clears");StationUsage usage=new StationUsage(ctx.getSharedPreferences("station_usage",0).getString("items","[]"));check(usage.count("서울")==1&&usage.count("부산")==1,"one completed manual query records both stations once");}finally{api.release.countDown();c.io.shutdownNow();}
  API failing=new API();failing.fail=true;failing.release.countDown();Context failedCtx=new Context();NativeController f=ControllerSoldOutTests.controller(failedCtx,failing);
  try{f.search("서울","부산","20991020","000000");settle(f);check(!f.busy&&!f.searching&&f.lastStatus.startsWith("실패:"),"failure clears loading indicator and reports error");check(new StationUsage(failedCtx.getSharedPreferences("station_usage",0).getString("items","[]")).frequent(6).isEmpty(),"failed query does not change station frequency");}finally{f.io.shutdownNow();}
  System.out.println(n+" search state checks passed");
 }
}
