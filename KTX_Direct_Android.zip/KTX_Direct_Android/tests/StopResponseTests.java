package kr.personal.ktxmate;
import org.json.*;
import java.io.IOException;
import java.util.LinkedHashMap;
public class StopResponseTests {
 static int count;static void check(boolean ok,String label){if(!ok)throw new AssertionError(label);count++;System.out.println("PASS "+label);}
 interface Action{void run()throws Exception;}
 static boolean rejects(Action action){try{action.run();return false;}catch(Exception e){return true;}}
 static class MockQueue extends KorailApi {
  int calls;String response;
  MockQueue(String value){super("test","16","Test");response=value;}
  @Override String post(String url,LinkedHashMap<String,String> form,boolean protect)throws Exception{calls++;return response;}
 }
 public static void main(String[] args)throws Exception{
  KorailApi api=new KorailApi("test","16","Test");
  check(rejects(()->api.decodeResponse("<html>captcha</html>",true)),"HTML challenge stops");
  check(rejects(()->api.decodeResponse("{\"strResult\":\"FAIL\",\"h_msg_txt\":\"추가 인증 필요\"}",true)),"authentication failure stops");
  check(rejects(()->api.decodeResponse("{\"strResult\":\"SUCC\",\"h_msg_txt\":\"자동화된 요청으로 감지\"}",true)),"blocking message stops even with success flag");
  check(rejects(()->api.decodeResponse("{\"strResult\":\"SUCC\",\"h_msg_txt\":\"CAPTCHA required\"}",true)),"English challenge stops");
  check(rejects(()->api.decodeResponse("{\"unknown\":true}",true)),"unknown authenticated format stops");
  api.loggedIn=true;check(rejects(()->api.decodeResponse("{\"strResult\":\"FAIL\",\"h_msg_cd\":\"P058\"}",true))&&!api.loggedIn,"expired session cleared without logging in");
  check("SUCC".equals(api.decodeResponse("{\"strResult\":\"SUCC\",\"h_msg_txt\":\"정상 처리\"}",true).optString("strResult")),"normal response accepted");
  MockQueue denied=new MockQueue("403:key=test");check(rejects(()->denied.queued("test",()->{throw new AssertionError("operation must not run");}))&&denied.calls==1,"queue denial triggers no subsequent request");
  MockQueue challenge=new MockQueue("200:key=test");check(rejects(()->challenge.queued("test",()->{throw new IOException("추가 인증");}))&&challenge.calls==1,"operation rejection triggers no follow-up request");
  MockQueue limited=new MockQueue("200:key=test");check(rejects(()->limited.queued("test",()->{throw new KorailApi.RateLimited(60);}))&&limited.calls==1,"rate limit triggers no follow-up request");
  MockQueue normal=new MockQueue("200:key=test");normal.queued("test",()->new JSONObject().put("strResult","SUCC"));check(normal.calls==2,"normal queue completion still releases queue");
  boolean sold=false;try{api.decodeResponse("{\"strResult\":\"FAIL\",\"h_msg_cd\":\"IRT010110\",\"h_msg_txt\":\"잔여석없음\"}",true);}catch(KorailApi.SoldOut expected){sold=true;}check(sold,"exact explicit sold-out code classified separately");
  sold=false;try{api.decodeResponse("{\"strResult\":\"FAIL\",\"h_msg_cd\":\"UNKNOWN\",\"h_msg_txt\":\"잔여석없음\"}",true);}catch(KorailApi.SoldOut wrong){sold=true;}catch(Exception expected){}check(!sold,"matching message alone does not permit retry");
  sold=false;try{api.decodeResponse("{\"strResult\":\"FAIL\",\"h_msg_cd\":\"IRT010110\",\"h_msg_txt\":\"추가 인증 필요\"}",true);}catch(KorailApi.SoldOut wrong){sold=true;}catch(Exception expected){}check(!sold,"authentication marker takes precedence over sold-out code");
  sold=false;try{api.decodeResponse("{\"strResult\":\"FAIL\",\"h_msg_cd\":\"IRT010110\",\"h_pnr_no\":\"1234567890\"}",true);}catch(KorailApi.SoldOut wrong){sold=true;}catch(Exception expected){}check(!sold,"contradictory reservation number is not safe to retry");
  check("SUCC".equals(api.decodeResponse("{\"strResult\":\"SUCC\",\"h_msg_cd\":\"IRT010110\"}",true).optString("strResult")),"success is not treated as explicit failed booking");
  final boolean[] waitingSeen={false};KorailApi waiting=new KorailApi("test","16","Test") {int calls;@Override String post(String url,LinkedHashMap<String,String> form,boolean protect)throws Exception{calls++;if(calls==1)return "201:key=test&ttl=1&nwait=7";if(calls==2)waitingSeen[0]="서버 접속 대기 · 7명".equals(queueState);return "200:key=test";}};
  waiting.queued("test",()->new JSONObject().put("strResult","SUCC"));check(waitingSeen[0]&&waiting.queueState.isEmpty(),"real queue wait count exposed then cleared on admission");
  KorailApi waitFailure=new KorailApi("test","16","Test") {int calls;@Override String post(String url,LinkedHashMap<String,String> form,boolean protect)throws Exception{calls++;if(calls==1)return "201:key=test&ttl=1&nwait=7";throw new RateLimited(60);}};
  check(rejects(()->waitFailure.queued("test",()->new JSONObject()))&&waitFailure.queueState.isEmpty(),"failed queue request clears waiting indicator without retry");
  System.out.println(count+" stop-response checks passed");
 }
}
