"""Inspect final DEX definitions, not incidental strings, for release protection invariants."""
import re,struct,sys
from pathlib import Path

def definitions(path):
 b=Path(path).read_bytes()
 assert b[:4]==b'dex\n','Not DEX'
 u32=lambda off:struct.unpack_from('<I',b,off)[0]
 def string(off):
  # Skip ULEB128 UTF16 length; descriptors are ASCII.
  while b[off]&128:off+=1
  off+=1;end=b.index(0,off);return b[off:end].decode('utf8','replace')
 strings=[string(u32(u32(60)+i*4)) for i in range(u32(56))]
 types=[strings[u32(u32(68)+i*4)] for i in range(u32(64))]
 return {types[u32(u32(100)+i*32)] for i in range(u32(96))}

if __name__=='__main__':
 classes=definitions(sys.argv[1]);mapping=Path(sys.argv[2]).read_text();checks=0
 for name in ['MainActivity','LicenseActivity','MonitorService']:
  assert f'Lkr/personal/ktxmate/{name};' in classes,f'Missing framework component {name}';checks+=1
 for name in ['KorailApi','NativeController','TokenCodec','SecretBox','LoginVault','DeviceLicense','LicenseVerifier']:
  original='kr.personal.ktxmate.'+name
  match=re.search(r'^'+re.escape(original)+r' -> (.+):$',mapping,re.M)
  assert match and match[1]!=original,'Core class not renamed: '+original
  assert 'L'+original.replace('.','/')+';' not in classes,'Original core descriptor exposed: '+original
  assert 'L'+match[1].replace('.','/')+';' in classes,'Renamed core class missing: '+original;checks+=1
 for cls,method in [('KorailApi','post'),('KorailApi','reserve'),('DeviceLicense','trustedBuild')]:
  lines=mapping.splitlines();inside=False;found=False
  for line in lines:
   if line and not line[0].isspace() and not line.startswith('#'):
    inside=line.startswith('kr.personal.ktxmate.'+cls+' -> ')
   if inside and re.search(r'\b'+re.escape(method)+r'\(',line):
    renamed=line.rsplit(' -> ',1)[-1]
    if ' -> ' in line and renamed!=method:found=True
  assert found,'Core method not renamed: '+cls+'.'+method;checks+=1
 assert b'KorailApi.java' not in Path(sys.argv[1]).read_bytes(),'Original core source filename exposed';checks+=1
 print(f'{checks} final DEX protection checks passed; {len(classes)} class definitions')
