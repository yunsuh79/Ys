package kr.personal.ktxmate;
import java.time.*;
public class NightPollingTests {
 static int count;static void check(boolean ok,String label){if(!ok)throw new AssertionError(label);count++;System.out.println("PASS "+label);}
 static long at(int day,int h,int m,int sec){return ZonedDateTime.of(2026,10,day,h,m,sec,0,TimingPolicy.KST).toInstant().toEpochMilli();}
 static void range(long now,long left,int min,int max,String label){boolean inside=true,varies=false;long first=TimingPolicy.delayMillis(now+left,now);for(int i=0;i<1000;i++){long d=TimingPolicy.delayMillis(now+left,now);inside&=d>=min&&d<=max;varies|=d!=first;}check(inside,label+" bounds");check(varies,label+" freshly randomized");}
 public static void main(String[] args){
  check(!TimingPolicy.night(at(17,22,59,59)),"22:59:59 uses daytime policy");
  check(TimingPolicy.night(at(17,23,0,0)),"23:00 starts overnight policy");
  check(TimingPolicy.night(at(18,0,0,0)),"midnight remains overnight");
  check(TimingPolicy.night(at(18,4,59,59)),"04:59:59 remains overnight");
  check(!TimingPolicy.night(at(18,5,0,0)),"05:00 restores daytime policy");
  for(long left:new long[]{60000,6*3600000L,12*3600000L,48*3600000L})range(at(17,23,0,0),left,8000,10000,"23:00 remaining "+left);
  range(at(18,4,59,59),60000,8000,10000,"last overnight second");
  range(at(18,5,0,0),60000,1000,3000,"05:00 near departure");
  range(at(17,22,59,59),12*3600000L,3000,4000,"before overnight next-day departure");
  range(at(18,5,0,0),48*3600000L,5000,6000,"05:00 distant departure");
  java.util.TimeZone before=java.util.TimeZone.getDefault();try{java.util.TimeZone.setDefault(java.util.TimeZone.getTimeZone("America/New_York"));check(TimingPolicy.night(at(17,23,30,0))&&!TimingPolicy.night(at(18,5,0,0)),"policy uses Korea time regardless of device timezone");}finally{java.util.TimeZone.setDefault(before);}
  System.out.println(count+" overnight polling checks passed");
 }
}
