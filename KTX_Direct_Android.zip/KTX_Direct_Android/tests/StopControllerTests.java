package kr.personal.ktxmate;
import android.content.Context;import org.json.*;import java.util.concurrent.*;import java.util.concurrent.atomic.*;
public class StopControllerTests {
 static int count;static void check(boolean ok,String label){if(!ok)throw new AssertionError(label);count++;System.out.println("PASS "+label);}
 static void settle(NativeController c)throws Exception{long end=System.nanoTime()+TimeUnit.SECONDS.toNanos(13);while(c.busy&&System.nanoTime()<end)Thread.sleep(10);check(!c.busy,"detail request completed");}
 static class API extends KorailApi {AtomicInteger reads=new AtomicInteger();volatile boolean fail=false,limit=false;API(){super("test","16","Test");loggedIn=true;}@Override JSONArray search(String f,String t,String d,String h)throws Exception{return new JSONArray().put(ControllerSoldOutTests.target().put("h_gen_rsv_cd","13"));}@Override JSONObject reserve(JSONObject row,String cabin){throw new AssertionError("unexpected booking");}@Override JSONObject trainSchedule(JSONObject row)throws Exception{reads.incrementAndGet();if(limit)throw new RateLimited(60);if(fail)throw new java.io.IOException("test failure");return TrainStopsTests.schedule();}}
 public static void main(String[] args)throws Exception{Context ctx=new Context();API api=new API();NativeController c=ControllerSoldOutTests.controller(ctx,api);JSONObject row=TrainStopsTests.train();String key=TrainStops.key(row);
  try{c.loadStops(row);settle(c);check(api.reads.get()==1&&c.stopCache.get(key).path.equals("동탄 → 대전 → 김천구미"),"detail cached from actual server response");check(c.loadingStops.isEmpty()&&!c.searching,"detail never leaves global spinner or loading label stuck");c.loadStops(row);check(api.reads.get()==1&&!c.busy,"cached route adds no network requests");
   c.stopCache.clear();api.fail=true;c.nextNetworkAt=0;c.loadStops(row);settle(c);check(c.stopCache.isEmpty()&&c.loadingStops.isEmpty(),"ordinary failure does not fabricate a route or retain loading state");
   api.fail=false;api.limit=true;c.loadStops(row);settle(c);check(c.retryWaitSeconds()>0&&!api.loggedIn,"detail 429 uses existing manual recovery and session clearing");int before=api.reads.get();c.loadStops(row);check(api.reads.get()==before&&!c.busy,"detail respects held retry-after without making request");
  }finally{c.stop("cleanup");c.io.shutdownNow();}
  API watching=new API();NativeController monitor=ControllerSoldOutTests.controller(new Context(),watching);try{monitor.begin();long end=System.nanoTime()+TimeUnit.SECONDS.toNanos(2);while(monitor.checks==0&&System.nanoTime()<end)Thread.sleep(10);check(monitor.active(),"mock watch started before detail lookup");monitor.loadStops(row);settle(monitor);check(monitor.active()&&monitor.watchCount()==1&&monitor.stopCache.containsKey(key),"detail lookup succeeds while preserving independent watch");}finally{monitor.stop("cleanup");monitor.io.shutdownNow();}
  System.out.println(count+" stop controller checks passed");
 }
}
