"""Run the actual Activity gate methods with isolated view/lifecycle doubles (not a device)."""
from pathlib import Path
import subprocess
p=Path(__file__).resolve().parents[1];out=p/'build/network-gate-tests';out.mkdir(parents=True,exist_ok=True)
s=(p/'app/src/main/java/kr/personal/ktxmate/MainActivity.java').read_text()
methods=s[s.index(' boolean syncNetworkGate(){'):s.index(' void openNetworkSettings(){')]
harness=r'''package kr.personal.ktxmate;
public class NetworkGateTests {
 boolean ready=true,screenResumed=true,termsShowing,startupFinished,introClosing,focus=true,finishing,destroyed;
 int LEAF=1,shownNetworkGateKind=-1,settings,exits,finishes,intros;
 FrameLayout shell=new FrameLayout(this),introOverlay,networkGateOverlay;
 LinearLayout root=new LinearLayout(this);TextView networkGateMessage;AlertDialog networkGateDialog;
 Controller c=new Controller();Handler startup=new Handler();
 static class Network{boolean mobile,wifi=true;boolean ready(){return mobile;}boolean wifi(){return wifi;}}
 static class Controller{Network network=new Network();}
 static class Handler{java.util.ArrayList<Runnable> jobs=new java.util.ArrayList<>();void post(Runnable r){jobs.add(r);}}
 static class View{static final int INVISIBLE=4,VISIBLE=0,IMPORTANT_FOR_ACCESSIBILITY_AUTO=0,IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS=4,ACCESSIBILITY_LIVE_REGION_POLITE=1;int visibility=VISIBLE,access;void setVisibility(int v){visibility=v;}void setImportantForAccessibility(int v){access=v;}void setBackground(Object o){}void setClickable(boolean v){}void setFocusable(boolean v){}void setPadding(int a,int b,int c,int d){}void setGravity(int i){}void bringToFront(){}}
 static class FrameLayout extends View{FrameLayout(Object c){}java.util.List<View> children=new java.util.ArrayList<>();void addView(View v,Object lp){children.add(v);}void addView(View v){children.add(v);}void removeView(View v){children.remove(v);}static class LayoutParams{LayoutParams(int a,int b){}}}
 static class LinearLayout extends FrameLayout{LinearLayout(Object c){super(c);}static class LayoutParams{LayoutParams(int a,int b){}}}
 static class ScrollView extends FrameLayout{ScrollView(Object c){super(c);}void setFillViewport(boolean b){}void addView(View v){children.add(v);}}
 static class ImageView extends View{ImageView(Object c){}void setImageResource(int i){}}
 static class TextView extends View{String value="";String getText(){return value;}void setText(String s){value=s;}void setAccessibilityLiveRegion(int i){}}
 static class Color{static final int WHITE=-1;static int rgb(int a,int b,int c){return 0;}}
 static class Gravity{static final int CENTER=1;}
 static class R{static class mipmap{static final int ic_launcher=1;}}
 static class AlertDialog{interface Click{void onClick(Object d,int w);}interface Dismiss{void onDismiss(Object d);}static int shows;boolean showing,cancelable=true,outside=true;Dismiss dismiss;String title,message;boolean isShowing(){return showing;}void setCancelable(boolean v){cancelable=v;}void setCanceledOnTouchOutside(boolean v){outside=v;}void setOnDismissListener(Dismiss d){dismiss=d;}void show(){showing=true;shows++;}void dismiss(){showing=false;if(dismiss!=null)dismiss.onDismiss(this);}static class Builder{AlertDialog dialog=new AlertDialog();Builder(Object c){}Builder setTitle(String s){dialog.title=s;return this;}Builder setMessage(String s){dialog.message=s;return this;}Builder setPositiveButton(String s,Click c){return this;}Builder setNegativeButton(String s,Click c){return this;}Builder setNeutralButton(String s,Click c){return this;}AlertDialog create(){return dialog;}}}
 int dp(int n){return n;}Object gradient(int a,int b,int c){return null;}LinearLayout column(){return new LinearLayout(this);}TextView brandTitle(int n){return new TextView();}TextView text(String s,int size,int color,boolean bold){TextView t=new TextView();t.setText(s);return t;}View button(String s,boolean b,Runnable r){return new View();}void space(Object c,int n){}void hideNetworkPopup(){}void hideWatchNotice(){}void dismissIntro(){intros++;}void finishStartup(){finishes++;}void openNetworkSettings(){settings++;}void syncNetworkPopup(){syncNetworkGate();}void finishAffinity(){exits++;}boolean isFinishing(){return finishing;}boolean isDestroyed(){return destroyed;}boolean hasWindowFocus(){return focus;}
METHODS
 static int n;static void check(boolean b){if(!b)throw new AssertionError("gate check "+n);n++;}
 public static void main(String[] args){
  NetworkGateTests a=new NetworkGateTests();a.introOverlay=new FrameLayout(a);
  check(a.syncNetworkGate());check(a.root.visibility==View.INVISIBLE);check(a.root.access==View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS);check(a.networkGateOverlay!=null);check(a.networkGateMessage.value.contains("앱 정책상 Wi-Fi"));check(a.networkGateDialog.isShowing());check(!a.networkGateDialog.cancelable&&!a.networkGateDialog.outside);check(a.startup.jobs.isEmpty());
  AlertDialog popup=a.networkGateDialog;int shows=AlertDialog.shows;popup.dismiss();check(a.syncNetworkGate());check(a.networkGateDialog==null&&AlertDialog.shows==shows);check(a.root.visibility==View.INVISIBLE); // Confirm cannot expose home.
  a.c.network.wifi=false;check(a.syncNetworkGate());check(a.networkGateDialog.message.contains("VPN"));check(a.root.visibility==View.INVISIBLE); // Offline/invalid mobile remains blocked.
  a.c.network.mobile=true;check(!a.syncNetworkGate());check(a.networkGateDialog==null&&a.networkGateOverlay==null);check(a.root.visibility==View.VISIBLE);check(a.root.access==View.IMPORTANT_FOR_ACCESSIBILITY_AUTO);check(a.startup.jobs.size()==1);a.startup.jobs.get(0).run();check(a.intros==1);
  a.startup.jobs.clear();check(!a.syncNetworkGate());check(a.startup.jobs.isEmpty()); // No duplicate intro/startup loop on ordinary mobile updates.
  a.introOverlay=null;a.startupFinished=true;a.c.network.mobile=false;a.c.network.wifi=true;a.screenResumed=false;check(a.syncNetworkGate());check(a.networkGateDialog==null&&a.root.visibility==View.INVISIBLE);
  a.screenResumed=true;a.focus=false;check(a.syncNetworkGate());check(a.networkGateDialog==null);a.focus=true;check(a.syncNetworkGate());check(a.networkGateDialog!=null);
  a.hideNetworkGateDialog();a.shownNetworkGateKind=-1;a.termsShowing=true;check(a.syncNetworkGate());check(a.networkGateDialog==null);a.termsShowing=false;check(a.syncNetworkGate());check(a.networkGateDialog!=null);
  a.c.network.mobile=true;check(!a.syncNetworkGate());check(a.startup.jobs.isEmpty()); // Existing session is not restarted or reauthenticated.
  System.out.println(n+" actual MainActivity network gate checks passed with UI doubles (no device)");
 }
}
'''.replace('METHODS',methods)
f=out/'NetworkGateTests.java';f.write_text(harness)
subprocess.run(['java','com.sun.tools.javac.Main','--release','8','-encoding','UTF-8','-d',str(out),str(f),str(p/'app/src/main/java/kr/personal/ktxmate/NetworkPopupState.java')],check=True)
subprocess.run(['java','-cp',str(out),'kr.personal.ktxmate.NetworkGateTests'],check=True)
