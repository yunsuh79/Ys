package kr.personal.ktxmate;
import org.json.*;
/** A single read-only search using the current KST time. No account data. */
public class LiveCurrentSearch {
 public static void main(String[] args)throws Exception{
  LiveSearch.configureProxy();long now=System.currentTimeMillis();String date=TimingPolicy.today(now),time=TimingPolicy.searchTime(date,"000000",now);KorailApi api=new KorailApi("0123456789abcdef","16","SM-S926N");JSONArray rows=api.search("서울","부산",date,time);int future=0;long received=System.currentTimeMillis();
  for(int i=0;i<rows.length();i++){JSONObject r=rows.getJSONObject(i);if(TimingPolicy.future(r.optString("h_dpt_dt",date),r.optString("h_dpt_tm"),received))future++;}
  System.out.println(new JSONObject().put("queryDateKST",date).put("queryTimeKST",time).put("returnedRows",rows.length()).put("futureRows",future).put("loginOrReservationSent",false));
 }
}
