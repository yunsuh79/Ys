package kr.personal.ktxmate;
import android.content.Context;
import java.util.concurrent.atomic.AtomicInteger;
public class RetiredIntegrationTests {
 static int count;static void check(boolean ok,String label){if(!ok)throw new AssertionError(label);count++;System.out.println("PASS "+label);}
 public static void main(String[] args){Context c=new Context();
  c.getSharedPreferences("kakao_secure",0).edit().putString("blob","test-ciphertext").commit();
  c.getSharedPreferences("kakao_alerts",0).edit().putBoolean("enabled",true).putString("status","old").commit();
  c.getSharedPreferences("kakao_delivery",0).edit().putBoolean("old-event",true).commit();
  c.getSharedPreferences("remembered_login",0).edit().putString("blob","keep-login").commit();
  c.getSharedPreferences("reservation_history",0).edit().putString("items","keep-history").commit();
  c.getSharedPreferences("alert_options",0).edit().putBoolean("quiet",true).commit();
  AtomicInteger erased=new AtomicInteger();check(RetiredIntegration.clear(c,()->erased.incrementAndGet()),"upgrade cleanup succeeds");
  check(c.getSharedPreferences("kakao_secure",0).getString("blob","").isEmpty(),"old encrypted token blob erased");
  check(!c.getSharedPreferences("kakao_alerts",0).getBoolean("enabled",false)&&c.getSharedPreferences("kakao_alerts",0).getString("status","").isEmpty(),"old enablement and status erased");
  check(!c.getSharedPreferences("kakao_delivery",0).getBoolean("old-event",false),"old delivery markers erased");
  check(erased.get()==1,"retired key erased");
  check(c.getSharedPreferences("remembered_login",0).getString("blob","").equals("keep-login"),"Korail vault untouched");
  check(c.getSharedPreferences("reservation_history",0).getString("items","").equals("keep-history"),"reservation history untouched");
  check(c.getSharedPreferences("alert_options",0).getBoolean("quiet",false),"local quiet hours retained");
  check(!RetiredIntegration.clear(c,()->{throw new java.io.IOException("key store temporarily unavailable");}),"key error reported without crashing");
  check(RetiredIntegration.clear(c,()->erased.incrementAndGet())&&erased.get()==2,"later launch retries key erasure safely");
  System.out.println(count+" retired integration cleanup checks passed");
 }
}
