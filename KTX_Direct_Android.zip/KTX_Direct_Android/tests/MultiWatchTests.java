package kr.personal.ktxmate;
import android.content.Context;
import org.json.*;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
public class MultiWatchTests {
 static int n;static void check(boolean b,String s){if(!b)throw new AssertionError(s);n++;System.out.println("PASS "+s);}
 interface Condition{boolean ready();}
 static boolean await(Condition c,int seconds)throws Exception{long end=System.nanoTime()+TimeUnit.SECONDS.toNanos(seconds);while(!c.ready()&&System.nanoTime()<end)Thread.sleep(10);return c.ready();}
 static JSONObject train(String id,String time)throws Exception{return ControllerSoldOutTests.target().put("h_trn_no",id).put("h_dpt_tm",time).put("h_gen_rsv_cd","13").put("h_spe_rsv_cd","13");}
 static class API extends KorailApi {
  final JSONObject[] rows={train("059","172300"),train("060","173000"),train("061","174000"),train("062","180000")};
  final CountDownLatch entered=new CountDownLatch(1),release=new CountDownLatch(1);final List<String> queried=new CopyOnWriteArrayList<>();final AtomicInteger concurrent=new AtomicInteger(),maximum=new AtomicInteger(),reserves=new AtomicInteger();volatile boolean available,uncertain,limited;
  API()throws Exception{super("test","16","Test");loggedIn=true;}
  @Override JSONArray search(String f,String t,String d,String h)throws Exception{int running=concurrent.incrementAndGet();maximum.accumulateAndGet(running,Math::max);try{entered.countDown();if(!release.await(4,TimeUnit.SECONDS))throw new IOException("test gate timeout");queried.add(h);if(limited)throw new RateLimited(60);JSONArray result=new JSONArray();for(int i=0;i<rows.length;i++){JSONObject row=new JSONObject(rows[i].toString());if(i==0&&available)row.put("h_gen_rsv_cd","11");result.put(row);}return result;}finally{concurrent.decrementAndGet();}}
  @Override JSONObject reserve(JSONObject r,String cabin)throws Exception{reserves.incrementAndGet();if(uncertain)throw new IOException("unknown reservation outcome");return new JSONObject().put("strResult","SUCC").put("h_pnr_no","12345678");}
 }
 static NativeController setup(Context ctx,API api)throws Exception{NativeController c=ControllerSoldOutTests.controller(ctx,api);c.accountKey=ReservationLedger.account("multi-test");return c;}
 static void add(NativeController c,JSONObject row,String cabin){c.addWatch(row,cabin,"서울","부산","20991020",false);}
 public static void main(String[] args)throws Exception{
  API api=new API();NativeController c=setup(new Context(),api);
  try{add(c,api.rows[0],"1");check(api.entered.await(1,TimeUnit.SECONDS),"first watch query started");add(c,api.rows[1],"1");add(c,api.rows[2],"1");check(c.watchCount()==3,"three watches registered");api.rows[0].put("h_trn_no","099");check("059".equals(c.watches.get(0).target.optString("h_trn_no")),"registered task freezes its target snapshot");api.rows[0].put("h_trn_no","059");add(c,api.rows[3],"1");check(c.watchCount()==3,"fourth watch rejected");add(c,api.rows[0],"1");check(c.watchCount()==3,"duplicate cabin not registered");c.stopWatch(api.rows[1],"1");check(c.watchCount()==2&&c.watching(api.rows[0],"1")!=null&&c.watching(api.rows[2],"1")!=null,"individual stop preserves other watches");api.release.countDown();check(await(()->c.watching(api.rows[0],"1")!=null&&c.watching(api.rows[2],"1")!=null&&c.watching(api.rows[0],"1").checked>0&&c.watching(api.rows[2],"1").checked>0,24),"remaining watches both receive fresh inquiry results");check(!api.queried.contains("173000")&&api.maximum.get()==1,"stopped watch not queried and network work stays serial");api.available=true;check(await(()->api.reserves.get()==1&&c.watchCount()==1,26),"one booking completes only its own watch");check(c.watching(api.rows[2],"1")!=null&&c.active(),"other watch continues after successful booking");check(c.paymentFor(api.rows[0],"1")!=null,"completed cabin becomes payment pending");c.stop("test");check(c.watchCount()==0&&!c.active(),"stop all clears all slots");}finally{api.release.countDown();c.stop("test cleanup");c.io.shutdownNow();}
  Context ctx=new Context();API fail=new API();NativeController f=setup(ctx,fail);
  try{add(f,fail.rows[0],"1");check(fail.entered.await(1,TimeUnit.SECONDS),"failure scenario entered");add(f,fail.rows[1],"1");add(f,fail.rows[2],"1");fail.available=true;fail.uncertain=true;fail.release.countDown();check(await(()->!f.active(),3)&&f.watchCount()==0,"unknown booking outcome stops every watch");check(ctx.getSharedPreferences("runtime",0).getBoolean("pending",false)&&fail.reserves.get()==1,"uncertainty lock preserved and mutation not replayed");}finally{fail.release.countDown();f.stop("test cleanup");f.io.shutdownNow();}
  API limited=new API();NativeController l=setup(new Context(),limited);
  try{add(l,limited.rows[0],"1");limited.entered.await(1,TimeUnit.SECONDS);add(l,limited.rows[1],"1");limited.limited=true;limited.release.countDown();check(await(()->!l.active(),3)&&l.watchCount()==0&&!limited.loggedIn,"request limit stops all watches and login");}finally{limited.release.countDown();l.stop("test cleanup");l.io.shutdownNow();}
  System.out.println(n+" multi-watch checks passed");
 }
}
