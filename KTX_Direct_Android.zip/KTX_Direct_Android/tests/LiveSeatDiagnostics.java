package kr.personal.ktxmate;
import org.json.*;
import java.util.*;
/** One public read-only query. Only train time and seat status fields are printed. */
public class LiveSeatDiagnostics {
 public static void main(String[] args)throws Exception{LiveSearch.configureProxy();long now=System.currentTimeMillis();KorailApi api=new KorailApi("0123456789abcdef","16","SM-S926N");JSONArray rows=api.search(args.length>0?args[0]:"동탄",args.length>1?args[1]:"김천구미",args.length>2?args[2]:TimingPolicy.today(now),args.length>3?args[3]:TimingPolicy.searchTime(TimingPolicy.today(now),"000000",now));JSONArray output=new JSONArray();for(int i=0;i<rows.length();i++){JSONObject row=rows.getJSONObject(i),safe=new JSONObject().put("train",row.optString("h_trn_no")).put("departure",row.optString("h_dpt_tm"));Iterator<String> keys=row.keys();while(keys.hasNext()){String key=keys.next();if(key.contains("rsv")||key.contains("seat")||key.contains("wait"))safe.put(key,row.get(key));}output.put(safe);}System.out.println(output);}
}
