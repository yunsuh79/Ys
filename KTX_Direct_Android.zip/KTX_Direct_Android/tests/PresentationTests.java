package kr.personal.ktxmate;
import org.json.JSONObject;
public class PresentationTests {
 static int count;static void check(boolean ok,String label){if(!ok)throw new AssertionError(label);count++;System.out.println("PASS "+label);}
 public static void main(String[] args)throws Exception{
 JSONObject r=new JSONObject().put("h_dpt_dt","20261022").put("h_dpt_tm","104800").put("h_arv_dt","20261022").put("h_arv_tm","115400");
 check("1시간 6분".equals(TrainPresentation.duration(r)),"same day duration");
 r.put("h_dpt_tm","234800").put("h_arv_dt","20261023").put("h_arv_tm","005400");check("1시간 6분".equals(TrainPresentation.duration(r)),"explicit next day arrival");
 r.remove("h_arv_dt");check("1시간 6분".equals(TrainPresentation.duration(r)),"missing arrival date rolls over midnight");
 r.put("h_arv_tm","invalid");check("".equals(TrainPresentation.duration(r)),"invalid time omitted");
 r.put("h_rsv_psb_nm","25,700원").put("h_spe_rsv_psb_nm","예약대기 가능");check("25,700원".equals(TrainPresentation.fare(r,true)),"server fare displayed");check("".equals(TrainPresentation.fare(r,false)),"status text never misrepresented as fare");
 r.put("h_rsv_psb_nm","25,600원\n5%적립");check("25,600원".equals(TrainPresentation.fare(r,true)),"actual fare excludes rewards suffix");
 check("10.22 (목)".equals(TrainPresentation.date(r)),"Korean travel date");System.out.println(count+" presentation checks passed");
 }
}
