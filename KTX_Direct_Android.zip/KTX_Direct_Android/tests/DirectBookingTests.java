package kr.personal.ktxmate;
import android.content.Context;
import org.json.*;
import java.util.concurrent.*;
public class DirectBookingTests {
 static int n;static void check(boolean ok,String label){if(!ok)throw new AssertionError(label);n++;System.out.println("PASS "+label);}
 static class Success extends ControllerSoldOutTests.API {
  Success()throws Exception{super(6);}
  @Override JSONObject reserve(JSONObject row,String cabin)throws Exception{reservations.incrementAndGet();return new JSONObject().put("strResult","SUCC").put("h_pnr_no","12345678");}
 }
 public static void main(String[] args)throws Exception{
  Context ctx=new Context();Success api=new Success();NativeController c=ControllerSoldOutTests.controller(ctx,api);c.accountKey=ReservationLedger.account("direct-test");
  try{c.begin(true);ControllerSoldOutTests.waitIdle(c);check(api.searches.get()==0&&api.reservations.get()==1,"direct booking skips search and sends one reservation");check(!ctx.getSharedPreferences("runtime",0).getBoolean("pending",true),"confirmed direct booking clears uncertainty");check("12345678".equals(ctx.getSharedPreferences("runtime",0).getString("lastPNR","")),"direct booking stores verified number");check(c.paymentFor(c.selected,"1")!=null,"successful booking exposes cabin payment action");c.begin(true);check(!c.active()&&api.reservations.get()==1,"payment-pending cabin blocks duplicate booking");}finally{c.stop("test");c.io.shutdownNow();}
  Context soldCtx=new Context();ControllerSoldOutTests.API sold=new ControllerSoldOutTests.API(1);NativeController s=ControllerSoldOutTests.controller(soldCtx,sold);
  try{s.begin(true);ControllerSoldOutTests.waitIdle(s);check(!s.active()&&sold.reservations.get()==1&&!sold.secondQuery.await(1200,TimeUnit.MILLISECONDS),"direct sold-out stops without starting monitoring");check(!soldCtx.getSharedPreferences("runtime",0).getBoolean("pending",true),"definitive sold-out unlocks");}finally{s.stop("test");s.io.shutdownNow();}
  Context unknownCtx=new Context();ControllerSoldOutTests.API unknown=new ControllerSoldOutTests.API(2);NativeController u=ControllerSoldOutTests.controller(unknownCtx,unknown);
  try{u.begin(true);ControllerSoldOutTests.waitIdle(u);check(unknownCtx.getSharedPreferences("runtime",0).getBoolean("pending",false)&&unknown.reservations.get()==1&&unknown.searches.get()==0,"unknown direct outcome stops and retains lock");u.begin(true);check(!u.active()&&unknown.reservations.get()==1,"pending result blocks another direct request");}finally{u.stop("test");u.io.shutdownNow();}
  ControllerSoldOutTests.API conflict=new ControllerSoldOutTests.API(5);NativeController f=ControllerSoldOutTests.controller(new Context(),conflict);f.selected=conflict.row;
  try{f.begin(true);check(!f.active()&&conflict.reservations.get()==0,"sold-out text prevents direct booking");}finally{f.stop("test");f.io.shutdownNow();}
  System.out.println(n+" direct booking checks passed");
 }
}
