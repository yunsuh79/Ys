package kr.personal.ktxmate;
import org.json.*;import java.nio.file.*;import java.util.*;
public class ProtocolTests {
 static void check(boolean ok,String label){if(!ok)throw new AssertionError(label);System.out.println("PASS "+label);}
 public static void main(String[] args)throws Exception{
  JSONObject v=new JSONObject(new String(Files.readAllBytes(Paths.get(args[0])),"UTF-8"));
  check(TokenCodec.token("0123456789abcdef","17","TestModel",1700000000000L,1700000001234L,"abcd",Arrays.asList(1234L)).equals(v.getString("token")),"token matches reference vector");
  check(KorailApi.encryptedPassword("테스트-password-123","0123456789abcdef").equals(v.getString("password")),"password encryption matches reference");
  check(new JSONObject(KorailApi.searchForm("서울","부산","20261020","180000")).similar(v.getJSONObject("search")),"search payload matches reference");
  check(new JSONObject(KorailApi.reserveForm(v.getJSONObject("train"),"1")).similar(v.getJSONObject("reserve")),"reservation payload matches reference");
  final String[] sentCode={null};
  KorailApi mock=new KorailApi("test","16","TestModel"){
    @Override JSONObject api(String path,LinkedHashMap<String,String> form,boolean protect)throws Exception{
      sentCode[0]=form.get("code");
      if(!path.equals("/classes/com.korail.mobile.common.code.do"))throw new AssertionError("unexpected endpoint");
      return new JSONObject().put("app.login.cphd",new JSONObject().put("idx","1").put("key","0123456789abcdef0123456789abcdef"));
    }
  };
  check(mock.loginCryptoInfo(1080,2340,36).getString("key").length()==32,"32-byte login metadata accepted");
  check("app.login.cphd".equals(sentCode[0]),"bootstrap code is a scalar form field, not a list literal");
  KorailApi missing=new KorailApi("test","16","TestModel"){
    @Override JSONObject api(String path,LinkedHashMap<String,String> form,boolean protect)throws Exception{return new JSONObject().put("strResult","SUCC");}
  };
  boolean missingRejected=false;try{missing.loginCryptoInfo(1080,2340,36);}catch(Exception e){missingRejected=true;}
  check(missingRejected,"missing crypto metadata fails before password submission");
  boolean rejected=false;try{KorailApi.encryptedPassword("pw","");}catch(Exception e){rejected=true;}check(rejected,"no plaintext password fallback");
  rejected=false;try{KorailApi.reserveForm(new JSONObject(),"1");}catch(Exception e){rejected=true;}check(rejected,"missing train identifiers rejected");
 }
}
