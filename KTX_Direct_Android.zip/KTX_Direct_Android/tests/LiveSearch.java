package kr.personal.ktxmate;
import java.net.*;import java.util.*;import org.json.*;
/** Read-only JVM smoke test. Does not log in or reserve. */
public class LiveSearch {
 static void configureProxy(){
  String env=System.getenv("HTTPS_PROXY");if(env==null)env=System.getenv("ALL_PROXY");
  if(env!=null&&!env.isEmpty()){
   final URI uri=URI.create(env);final Proxy proxy=new Proxy(uri.getScheme().startsWith("socks")?Proxy.Type.SOCKS:Proxy.Type.HTTP,new InetSocketAddress(uri.getHost(),uri.getPort()));
   ProxySelector.setDefault(new ProxySelector(){public List<Proxy> select(URI target){return Collections.singletonList(proxy);}public void connectFailed(URI target,SocketAddress addr,java.io.IOException e){}});
   if(uri.getUserInfo()!=null){final String[] a=uri.getUserInfo().split(":",2);Authenticator.setDefault(new Authenticator(){protected PasswordAuthentication getPasswordAuthentication(){return new PasswordAuthentication(a[0],(a.length>1?a[1]:"").toCharArray());}});}
  }
 }
 public static void main(String[] args)throws Exception{
  configureProxy();
  KorailApi api=new KorailApi("0123456789abcdef","17","TestModel");long now=System.currentTimeMillis();
  try{JSONArray rows=api.search("서울","부산","20261020","180000");JSONObject result=new JSONObject();result.put("result","success");result.put("train_count",rows.length());JSONArray sample=new JSONArray();for(int i=0;i<Math.min(3,rows.length());i++){JSONObject row=rows.getJSONObject(i);JSONObject t=new JSONObject();t.put("train",row.optString("h_trn_no"));t.put("departure",row.optString("h_dpt_tm"));t.put("arrival",row.optString("h_arv_tm"));sample.put(t);}result.put("sample",sample);result.put("elapsed_ms",System.currentTimeMillis()-now);System.out.println(result.toString());}
  catch(Exception e){System.out.println(new JSONObject().put("result","failed").put("error",e.getClass().getSimpleName()).put("message",e.getMessage()).toString());}
 }
}
