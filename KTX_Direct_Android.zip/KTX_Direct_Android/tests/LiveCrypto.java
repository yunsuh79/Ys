package kr.personal.ktxmate;
import org.json.*;import java.util.*;
/** Pre-login metadata only: no login ID, password, or reservation requests. */
public class LiveCrypto {
 public static void main(String[] args)throws Exception{
  LiveSearch.configureProxy();KorailApi api=new KorailApi("0123456789abcdef","16","SM-S926N");
  // Reproduce v0.3 without account data, then exercise the fixed method on the same endpoint.
  LinkedHashMap<String,String> old=KorailApi.common();old.putAll(KorailApi.map("code","['app.login.cphd']","deviceWidth","1080","deviceHeight","2340","OSVersion","36"));
  JSONObject r=api.api("/classes/com.korail.mobile.common.code.do",old,false);
  System.out.println(new JSONObject().put("case","v03_list_literal").put("cryptoPresent",r.optJSONObject("app.login.cphd")!=null).put("result",r.optString("strResult")));
  JSONObject c=api.loginCryptoInfo(1080,2340,36);
  System.out.println(new JSONObject().put("case","fixed_form_field").put("cryptoPresent",true).put("keyBytes",c.getString("key").getBytes("UTF-8").length).put("passwordSent",false));
 }
}
