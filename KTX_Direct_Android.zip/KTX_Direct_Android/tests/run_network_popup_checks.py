from pathlib import Path
import subprocess
p=Path(__file__).resolve().parents[1];out=p/'build/network-popup-tests';out.mkdir(parents=True,exist_ok=True)
subprocess.run(['java','com.sun.tools.javac.Main','--release','8','-d',str(out),str(p/'app/src/main/java/kr/personal/ktxmate/NetworkPopupState.java'),str(p/'tests/NetworkPopupStateTests.java')],check=True)
subprocess.run(['java','-cp',str(out),'kr.personal.ktxmate.NetworkPopupStateTests'],check=True)
