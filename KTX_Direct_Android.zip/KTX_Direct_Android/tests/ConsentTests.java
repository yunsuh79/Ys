package kr.personal.ktxmate;
import android.content.Context;
import java.util.concurrent.atomic.AtomicInteger;
public class ConsentTests {
 static int count;static void check(boolean ok,String label){if(!ok)throw new AssertionError(label);count++;System.out.println("PASS "+label);}
 public static void main(String[] args)throws Exception{
  Context ctx=new Context();NativeController c=new NativeController(ctx);AtomicInteger work=new AtomicInteger();
  try{check(!TermsConsent.accepted(ctx),"fresh install requires explicit consent");c.run("test",()->work.incrementAndGet());check(work.get()==0&&!c.busy,"network work blocked before consent");c.search("서울","부산","20991020","000000");check(!c.busy&&!c.searching,"pre-consent search does not leave spinner stuck");c.tryAutoLogin(1080,2340);check(!c.autoLoginAttempted,"pre-consent auto login neither starts nor consumes attempt");c.addWatch(ControllerSoldOutTests.target(),"1","서울","부산","20991020",false);check(!c.active(),"monitor cannot begin before consent");check(TermsConsent.accept(ctx)&&TermsConsent.accepted(ctx),"explicit consent saved");c.run("test",()->work.incrementAndGet());AutoLoginTests.settle(c);check(work.get()==1,"accepted user can perform work");ctx.getSharedPreferences("terms",0).edit().putInt("accepted",TermsConsent.VERSION-1).commit();check(!TermsConsent.accepted(ctx),"outdated consent version not silently accepted");check(TermsConsent.TEXT.contains("자동 예약 요청")&&TermsConsent.TEXT.contains("Keystore")&&TermsConsent.TEXT.contains("개발자 서버"),"terms describe actual reservation and data flows");}finally{c.io.shutdownNow();}
  System.out.println(count+" consent checks passed");
 }
}
