package kr.personal.ktxmate;
import android.content.Context;
public class RecoveryGuideTests {
 static int n;static void check(boolean ok,String msg){if(!ok)throw new AssertionError(msg);n++;System.out.println("PASS "+msg);}
 public static void main(String[] args)throws Exception{
  KorailApi api=new KorailApi("test","16","Test");boolean expired=false;
  try{api.decodeResponse("{\"strResult\":\"FAIL\",\"h_msg_cd\":\"P058\",\"h_msg_txt\":\"세션 종료\"}",true);}catch(KorailApi.SessionExpired e){expired=true;}
  check(expired,"P058 is a distinct security-stop reason");
  String message=RecoveryGuide.message(new KorailApi.SessionExpired(),false);check(message.contains("P058")&&message.contains("세션이 만료"),"expiry guide names the cause");check(message.contains("코레일 앱에서 확인")&&message.contains("로그인 상태"),"official app button and login check described");check(message.contains("직접 로그인")&&message.contains("자동 반영되지는"),"return path does not promise shared authentication");
  String rate=RecoveryGuide.message(new KorailApi.RateLimited(120),false);check(rate.contains("120초")&&rate.contains("429")&&rate.contains("자동 재개하지"),"429 guide preserves server wait and manual restart");check(RecoveryGuide.message(new KorailApi.AccessCheck("captcha"),true).contains("중복 예약 방지 잠금"),"unknown booking lock kept in guide");
  NativeController c=ControllerSoldOutTests.controller(new Context(),api);
  try{c.accountKey="test";c.recordBlocked(new KorailApi.SessionExpired());check(!api.loggedIn&&!c.manualNotice.isEmpty()&&c.manualNotice.contains("P058"),"controller exposes expiry guidance after session cleanup");long before=c.blockedUntil;c.recordBlocked(new KorailApi.RateLimited(60));check(c.blockedUntil>before&&c.retryWaitSeconds()>0&&c.manualNotice.contains("429"),"rate-limit hold and user guidance both retained");}finally{c.stop("test");c.io.shutdownNow();}
  System.out.println(n+" recovery guide checks passed");
 }
}
