package kr.personal.ktxmate;
import org.json.*;import java.util.*;
public class TrainStopsTests {
 static int count;static void check(boolean ok,String label){if(!ok)throw new AssertionError(label);count++;System.out.println("PASS "+label);}
 static JSONObject train()throws Exception{return new JSONObject().put("h_run_dt","20991019").put("h_dpt_dt","20991020").put("h_trn_no","395").put("h_dpt_rs_stn_cd","0002").put("h_arv_rs_stn_cd","0004").put("h_dpt_rs_stn_nm","동탄").put("h_arv_rs_stn_nm","김천구미").put("h_dpt_stn_run_ordr","002").put("h_arv_stn_run_ordr","004").put("h_dpt_tm","165200").put("h_arv_tm","175700");}
 static JSONObject stop(String name,String code,int order)throws Exception{return new JSONObject().put("stopStnNm",name).put("stopRsStnCd",code).put("runOrdr",String.format("%03d",order));}
 static JSONObject schedule()throws Exception{return new JSONObject().put("strResult","SUCC").put("dlayList",new JSONArray().put(stop("수서","0001",1)).put(stop("동탄","0002",2).put("dptTm","165200")).put(stop("대전","0003",3)).put(stop("김천구미","0004",4).put("arvTm","175700")).put(stop("부산","0005",5)));}
 static boolean reject(JSONObject response,JSONObject train){try{TrainStops.segment(response,train);return false;}catch(Exception e){return true;}}
 public static void main(String[] args)throws Exception{
  JSONObject row=train(),response=schedule();TrainStops.Result result=TrainStops.segment(response,row);
  check(result.path.equals("동탄 → 대전 → 김천구미"),"only selected journey segment shown");check(result.count==1&&result.summary.equals("경유 정차역 1곳"),"endpoints not counted as intermediate stops");
  JSONArray raw=response.getJSONArray("dlayList"),reversed=new JSONArray();for(int i=raw.length()-1;i>=0;i--)reversed.put(raw.get(i));check(TrainStops.segment(new JSONObject().put("dlayList",reversed),row).path.equals(result.path),"unique server run order restores schedule order");
  JSONObject direct=new JSONObject().put("dlayList",new JSONArray().put(raw.getJSONObject(1)).put(raw.getJSONObject(3)));check(TrainStops.segment(direct,row).count==0&&TrainStops.segment(direct,row).summary.equals("중간 정차역 없음"),"verified adjacent endpoints show no intermediate stop");
  check(reject(new JSONObject(),row),"missing schedule is never interpreted as nonstop");check(reject(new JSONObject().put("dlayList",new JSONArray()),row),"empty schedule rejected");
  check(reject(new JSONObject().put("dlayList",new JSONArray().put(raw.getJSONObject(1))),row),"missing destination rejected");
  check(reject(schedule(),new JSONObject(row.toString()).put("h_dpt_stn_run_ordr","099")),"wrong occurrence of station rejected");
  JSONObject incomplete=schedule();incomplete.getJSONArray("dlayList").getJSONObject(2).remove("stopStnNm");check(reject(incomplete,row),"missing intermediate name does not invent route");
  JSONObject wrong=schedule();wrong.getJSONArray("dlayList").getJSONObject(1).put("dptTm","170000");check(reject(wrong,row),"mismatched departure time rejected");
  JSONObject repeated=schedule();repeated.getJSONArray("dlayList").put(stop("동탄","0002",2));check(reject(repeated,row),"ambiguous station occurrence rejected");
  JSONObject numeric=schedule();numeric.getJSONArray("dlayList").getJSONObject(1).put("stopRsStnCd",2).put("runOrdr",2);check(TrainStops.segment(numeric,row).count==1,"numeric scalar codes normalize leading zeros");
  check(!TrainStops.key(row).equals(TrainStops.key(new JSONObject(row.toString()).put("h_dpt_dt","20991021"))),"cache isolates journey dates");check(!TrainStops.key(row).equals(TrainStops.key(new JSONObject(row.toString()).put("h_arv_rs_stn_cd","0005"))),"cache isolates selected segment");
  LinkedHashMap<String,String> form=KorailApi.trainScheduleForm(row);check(form.get("runDt").equals("20991019"),"schedule requests operating date rather than boarding date across midnight");check(form.get("trnNo").equals("00395"),"schedule train number padded to five digits");check(!form.containsKey("Key")&&form.size()==5,"read-only schedule has exact reference form without legacy key");
  final boolean[] sent={false};KorailApi api=new KorailApi("test","16","Test"){@Override JSONObject api(String path,LinkedHashMap<String,String> data,boolean protect)throws Exception{sent[0]=path.equals("/classes/com.korail.mobile.research.actualTrainSchedule.do")&&protect&&data.equals(form);return response;}};check(api.trainSchedule(row)==response&&sent[0],"schedule dispatch uses expected route and existing protected transport");
  boolean invalid=false;try{KorailApi.trainScheduleForm(new JSONObject(row.toString()).put("h_trn_no","395&bad"));}catch(Exception e){invalid=true;}check(invalid,"invalid train number rejected before transport");
  System.out.println(count+" train stops checks passed");
 }
}
