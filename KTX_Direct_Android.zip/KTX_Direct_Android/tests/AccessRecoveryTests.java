package kr.personal.ktxmate;
import android.content.Context;
import org.json.*;
import java.util.concurrent.atomic.AtomicInteger;
public class AccessRecoveryTests {
 static int count;static void check(boolean value,String label){if(!value)throw new AssertionError(label);count++;System.out.println("PASS "+label);}
 static class UI implements NativeController.Listener{String title="",message="";public void update(){}public void alert(String t,String m){title=t;message=m;}}
 static class API extends KorailApi{AtomicInteger queries=new AtomicInteger(),reserves=new AtomicInteger();API(){super("test","16","Test");loggedIn=true;}@Override JSONArray search(String f,String t,String d,String h)throws Exception{queries.incrementAndGet();return new JSONArray().put(ControllerSoldOutTests.target());}@Override JSONObject reserve(JSONObject row,String cabin)throws Exception{reserves.incrementAndGet();throw new AccessCheck("test challenge");}}
 public static void main(String[] args)throws Exception{
  API api=new API();Context ctx=new Context();NativeController c=ControllerSoldOutTests.controller(ctx,api);UI ui=new UI();c.listener=new java.lang.ref.WeakReference<>(ui);
  try{
   c.run("test",()->api.decodeResponse("{\"strResult\":\"FAIL\",\"h_msg_txt\":\"보안문자를 입력하세요\"}",true));AutoLoginTests.settle(c);
   check(!c.busy&&!c.searching&&!api.loggedIn,"captcha clears request state and session without crash");check(ui.title.equals("수동 확인 필요")&&ui.message.contains("코레일 앱"),"captcha exposes manual official-app handoff");check(c.manualNotice.contains("자동 복구되지는 않습니다"),"official authentication never assumed to restore app session");
   c.recordBlocked(new KorailApi.RateLimited(60));check(c.retryWaitSeconds()>0&&c.retryWaitSeconds()<=60,"server retry-after retained");int before=api.queries.get();c.search("서울","부산","20991020","000000");AutoLoginTests.settle(c);check(api.queries.get()==before&&!c.busy&&!c.searching,"manual refresh during hold sends no network request and clears spinner");
   AtomicInteger logins=new AtomicInteger();c.run("test login",()->logins.incrementAndGet());check(logins.get()==0,"login also respects server hold");
   c.blockedUntil=android.os.SystemClock.elapsedRealtime()-1;c.run("test",()->{});AutoLoginTests.settle(c);check(!c.busy,"explicit action allowed after hold expires");
   c.recordBlocked(new KorailApi.RateLimited(Long.MAX_VALUE));check(c.retryWaitSeconds()>0,"extreme retry-after cannot overflow into immediate retry");
  }finally{c.stop("test cleanup");c.io.shutdownNow();}
  API reserved=new API();Context pending=new Context();NativeController b=ControllerSoldOutTests.controller(pending,reserved);UI bookingUI=new UI();b.listener=new java.lang.ref.WeakReference<>(bookingUI);
  try{b.begin(true);ControllerSoldOutTests.waitIdle(b);check(reserved.reserves.get()==1&&!b.active(),"captcha during reservation stops without replay");check(pending.getSharedPreferences("runtime",0).getBoolean("pending",false),"captcha with unknown booking result keeps uncertainty lock");check(b.manualNotice.contains("중복 예약 방지 잠금")&&bookingUI.title.equals("수동 확인 필요"),"manual guidance includes reservation review before recovery");}finally{b.stop("test cleanup");b.io.shutdownNow();}
  System.out.println(count+" access recovery checks passed");
 }
}
