"""JVM regression run after real R8 shrinking/renaming; Android classes are test doubles."""
from pathlib import Path
import os,subprocess,zipfile,concurrent.futures
p=Path(__file__).resolve().parents[1];out=p/'build/obfuscated-tests';out.mkdir(parents=True,exist_ok=True)
jsonjar=Path(os.environ.get('JSON_JAR',p.parent/'android-tools/research/json.jar')).resolve()
r8=Path(os.environ.get('JARIBOM_R8_JAR',p.parent/'android-tools/sdk/cmdline-tools/latest/lib/r8.jar')).resolve()
# Compile and run unmodified controller regression first to ground test classes.
subprocess.run(['python3',str(p/'tests/run_regression.py')],check=True)
compiled=p/'build/v130-tests'
with zipfile.ZipFile(out/'program.jar','w',zipfile.ZIP_DEFLATED) as z:
 for f in compiled.rglob('*.class'):z.write(f,f.relative_to(compiled))
(out/'rules.pro').write_text('''-dontoptimize
-repackageclasses j
-keepattributes Exceptions,InnerClasses,EnclosingMethod,Signature
-keepclasseswithmembers class * { public static void main(java.lang.String[]); }
-keep class android.** { *; }
# The test harness injects a transport double by reflection; production has no such use.
-keepclassmembers class kr.personal.ktxmate.NativeController { final kr.personal.ktxmate.KorailApi api; }
''')
java_home=Path('/usr/lib/jvm/java-17-openjdk-amd64')
subprocess.run(['java','-cp',str(r8),'com.android.tools.r8.R8','--release','--classfile','--lib',str(java_home),'--lib',str(jsonjar),'--pg-conf',str(out/'rules.pro'),'--pg-map-output',str(out/'mapping.txt'),'--output',str(out/'obfuscated.jar'),str(out/'program.jar')],check=True)
names=[f.stem for f in (p/'tests').glob('*.java') if (compiled/('kr/personal/ktxmate/'+f.stem+'.class')).exists() and 'public static void main' in f.read_text()]
def run(name):
 r=subprocess.run(['java','-cp',str(out/'obfuscated.jar')+os.pathsep+str(jsonjar),'kr.personal.ktxmate.'+name],capture_output=True,text=True,timeout=110)
 if r.returncode:raise RuntimeError(name+'\n'+r.stdout+r.stderr)
 return name+': '+r.stdout.strip().splitlines()[-1]
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:
 for result in ex.map(run,names):print('R8 '+result,flush=True)
print(str(len(names))+' regression suites passed after R8 shrinking and renaming')
